#!/usr/bin/env node
/* Launchpad — local one-click app launcher with built-in debugging + editor.
 * Zero dependencies (node built-ins only). Serves the dashboard UI and
 * manages project processes: launch, stream logs, diagnose crashes,
 * apply safe auto-fixes, edit files.
 */
"use strict";
const http = require("http");
const fs = require("fs");
const net = require("net");
const path = require("path");
const os = require("os");
const cp = require("child_process");
const crypto = require("crypto");
const util = require("util");
const { URL } = require("url");
// async subprocess calls — the event loop must NEVER block on a child process
// (a 60s checker run or a hung binary probe would freeze every route and SSE stream)
const execFile = util.promisify(cp.execFile);

const _p = parseInt(process.env.LAUNCHPAD_PORT || "8471", 10);
const PORT = (_p >= 1 && _p <= 65535) ? _p : 8471; // a bad env var must never crash boot // number — portsFromLogs compares with !==
const HOME = os.homedir();
const DATA_DIR = path.join(HOME, ".launchpad");
const PROFILES_FILE = path.join(DATA_DIR, "profiles.json");
const PUBLIC_DIR = path.join(__dirname, "public");
const APP_DIR = __dirname; // the tool's own install dir — self-update applies here
// dist marker: {kind:"launchpad-dist", target:"launchpad", version:"1.1.0", built:"..."}.
// installs shipped before the marker existed report 1.0.0.
function distVersion() {
  try {
    const m = JSON.parse(fs.readFileSync(path.join(APP_DIR, ".launchpad-dist"), "utf8"));
    if (m && typeof m.version === "string") return m.version;
  } catch {}
  return "1.0.0";
}
function compareVersions(a, b) { // -1 / 0 / 1 — numeric per segment, no semver lib needed
  const pa = String(a).split(".").map(x => parseInt(x, 10) || 0);
  const pb = String(b).split(".").map(x => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

/* ---------------- profiles ---------------- */
function loadProfiles() {
  try {
    const v = JSON.parse(fs.readFileSync(PROFILES_FILE, "utf8"));
    if (!Array.isArray(v)) throw new Error("profiles.json is not an array"); // valid JSON, wrong shape — the catch below quarantines it
    // one null/string element would make getProfile's .find throw on EVERY lookup —
    // filter to objects like loadBrain does for signatures
    return v.filter(p => p && typeof p === "object");
  }
  catch {
    // a corrupt file is quarantined, NOT silently replaced — replacing it would let
    // the next save destroy every project the dashboard can no longer see
    try {
      if (fs.existsSync(PROFILES_FILE) && fs.statSync(PROFILES_FILE).size > 0) {
        const bak = PROFILES_FILE + ".corrupt-" + Date.now();
        fs.renameSync(PROFILES_FILE, bak);
        console.error("[launchpad] profiles.json was corrupt — quarantined to " + bak);
      }
    } catch {}
    return [];
  }
}
// atomic write: temp file + rename, so a crash mid-save never leaves a truncated file
function atomicWrite(file, data) {
  const tmp = file + ".tmp";
  fs.writeFileSync(tmp, data);
  fs.renameSync(tmp, file); // POSIX rename is atomic — readers never see a half-write
}
function saveProfiles(p) {
  try { atomicWrite(PROFILES_FILE, JSON.stringify(p, null, 2)); }
  catch (e) { console.error("[launchpad] couldn't save profiles:", e.message); }
}
function getProfile(id) { return loadProfiles().find(p => p.id === id); }

/* ---------------- runners ---------------- */
const runners = new Map(); // id -> {proc, logs:[], status, startedAt, clients:Set, lastDiag}
function runner(id) {
  if (!runners.has(id)) {
    runners.set(id, { proc: null, logs: [], status: "stopped", startedAt: null,
      clients: new Set(), lastDiag: [], phase: "", appUrl: null, ready: false, autopilot: false });
  }
  return runners.get(id);
}
function pushLog(id, line) {
  const r = runner(id);
  // cap line length: a runaway app dumping multi-megabyte lines would otherwise
  // grow the heap without bound (the 3000-entry cap doesn't limit entry SIZE)
  line = String(line).slice(0, 4000);
  r.logs.push(line);
  if (r.logs.length > 3000) r.logs.splice(0, r.logs.length - 3000);
  const msg = "data: " + JSON.stringify({ type: "log", line }) + "\n\n";
  for (const res of r.clients) { try { res.write(msg); } catch {} }
}
function broadcast(id, obj) {
  const msg = "data: " + JSON.stringify(obj) + "\n\n";
  for (const res of runner(id).clients) { try { res.write(msg); } catch {} }
}
/* fix/install subprocesses (npm install, pip install, ollama pull) are tracked on the
   runner so a Stop — or a superseding relaunch — can kill them. without this an
   orphaned install keeps mutating node_modules under the new run for up to 15 min.
   (the ollama-serve daemon is intentionally NOT tracked — it's meant to keep running) */
function trackFixProc(id, child) {
  const r = runner(id);
  r.fixProcs = r.fixProcs || new Set();
  r.fixProcs.add(child);
}
function untrackFixProc(id, child) {
  try { if (runner(id).fixProcs) runner(id).fixProcs.delete(child); } catch {}
}
function killFixProcs(id) {
  const r = runner(id);
  if (!r.fixProcs || !r.fixProcs.size) return 0;
  let n = 0;
  for (const c of [...r.fixProcs]) { try { process.kill(-c.pid, "SIGKILL"); n++; } catch {} } // ESRCH = already gone
  r.fixProcs.clear();
  return n;
}

/* ---------------- diagnostics ---------------- */
const RULES = [
  { id: "eaddrinuse", re: /EADDRINUSE[^0-9]*(\d{2,5})/i,
    title: "Port already in use",
    detail: m => `Something is already listening on port ${m[1]}.`,
    fix: m => ({ label: `Free port ${m[1]}`, action: "kill-port", arg: m[1] }) },
  { id: "modulenotfound", re: /Cannot find module '([^']+)'/,
    title: "Missing node module",
    detail: m => `Node can't find '${m[1]}'. Dependencies probably aren't installed.`,
    fix: () => ({ label: "Run npm install", action: "npm-install" }) },
  { id: "pymodulenotfound", re: /ModuleNotFoundError: No module named '([^']+)'/,
    title: "Missing python module",
    detail: m => `Python can't find '${m[1]}'.`,
    fix: m => ({ label: `pip install ${m[1]}`, action: "pip-install", arg: m[1] }) },
  { id: "ollamarefused", re: /(ECONNREFUSED.*11434|Failed to fetch.*11434|connect.*11434.*refused)/i,
    title: "Ollama isn't running",
    detail: () => "The app tried to reach Ollama at localhost:11434 but nothing answered.",
    fix: () => ({ label: "Start ollama serve", action: "ollama-serve" }) },
  { id: "ollamamodel", re: /model ["']([^"']+)["'] not found/i,
    title: "Ollama model missing",
    detail: m => `Model '${m[1]}' isn't pulled locally.`,
    fix: m => ({ label: `ollama pull ${m[1]}`, action: "ollama-pull", arg: m[1] }) },
  { id: "ollamabin", re: /ollama: (command not found|not found)/i,
    title: "Ollama not installed",
    detail: () => "The 'ollama' binary isn't on PATH.",
    fix: null, hint: "Install from https://ollama.com/download, then pull a model: ollama pull qwen2.5:7b" },
  { id: "eacces", re: /EACCES.*:(\d{2,5})/i,
    title: "Permission denied on port",
    detail: m => `Port ${m[1]} needs root. Use a port ≥ 1024 instead.`,
    fix: null },
  { id: "syntax", re: /SyntaxError: (.+?)(?:\n|$)/,
    title: "Syntax error",
    detail: m => m[1].slice(0, 160),
    fix: null, hint: "Open the file in the built-in editor — the error names the file and line." },
  { id: "pyfilenotfound", re: /FileNotFoundError: \[Errno 2\] No such file or directory: '([^']+)'/,
    title: "File not found",
    detail: m => `The app expected '${m[1]}' but it isn't there.`,
    fix: null },
  { id: "sqlitebusy", re: /SQLITE_BUSY|database is locked/i,
    title: "SQLite database locked",
    detail: () => "Another process has the database open.",
    fix: null, hint: "Stop other copies of the app, or delete a stale -journal/-wal file if the app crashed." },
  { id: "electron-display", re: /Unable to open X display|missing X server/i,
    title: "No display for Electron",
    detail: () => "Electron needs a graphical session.",
    fix: null, hint: "Run from your desktop session (not SSH). If headless, the app needs xvfb." },
  { id: "nodever", re: /EBADENGINE|requires Node/i,
    title: "Wrong Node version",
    detail: m => m[0].slice(0, 160),
    fix: null, hint: "Check 'node -v' in the Environment panel against what package.json wants." },
];
function diagnose(logText) {
  const out = [];
  for (const r of RULES) {
    const m = logText.match(r.re);
    if (m) {
      out.push({
        rule: r.id, title: r.title, detail: r.detail(m),
        fix: r.fix ? r.fix(m) : null, hint: r.hint || null,
      });
      if (out.length >= 4) break;
    }
  }
  return out;
}

/* ---------------- learning brain: remembers crashes, fixes, app health ---------------- */
const BRAIN_FILE = path.join(DATA_DIR, "brain.json");
function loadBrain() {
  try {
    const b = JSON.parse(fs.readFileSync(BRAIN_FILE, "utf8"));
    // shape-guard like loadProfiles: valid JSON with the wrong shape (a top-level array,
    // a string "settings") would otherwise silently drop learned state or throw out of
    // the crash-learn path. quarantine only what's unsalvageable, repair what isn't.
    if (!b || typeof b !== "object" || Array.isArray(b)) throw new Error("brain.json has wrong shape"); // → quarantine path below, like loadProfiles
    if (!Array.isArray(b.signatures)) b.signatures = [];
    else b.signatures = b.signatures.filter(s => s && typeof s === "object"); // one bad element must not nuke the brain
    if (!b.projects || typeof b.projects !== "object" || Array.isArray(b.projects)) b.projects = {};
    // validate the VALUES too — one bad project entry (null, queue:"oops",
    // lastTriple without results) 500s /api/brain and aborts the dashboard render
    for (const k of Object.keys(b.projects)) {
      const pr = b.projects[k];
      if (!pr || typeof pr !== "object" || Array.isArray(pr)) { delete b.projects[k]; continue; }
      if (pr.queue !== undefined && !Array.isArray(pr.queue)) pr.queue = []; // dashboard .filters it
      // one bad ELEMENT (null) 500s /api/brain's queued-count and aborts the
      // dashboard render just as surely as a bad queue itself — scrub elements too
      if (Array.isArray(pr.queue)) pr.queue = pr.queue.filter(x => x && typeof x === "object");
      if (pr.lastTriple && !Array.isArray(pr.lastTriple.results)) delete pr.lastTriple; // dashboard .somes it
      // same for results elements — dashboard .somes/.filters them during render
      else if (pr.lastTriple) pr.lastTriple.results = pr.lastTriple.results.filter(r => r && typeof r === "object");
    }
    if (!b.settings || typeof b.settings !== "object" || Array.isArray(b.settings)) b.settings = {};
    if (typeof b.settings.weeklyScan !== "boolean")
      b.settings.weeklyScan = b.settings.idleVerify !== false; // migrate old toggle
    b.selftests = b.selftests || {};
    if (!Array.isArray(b.unknown)) b.unknown = [];
    else b.unknown = b.unknown.filter(x => x && typeof x === "object");
    if (b.lastWeeklyScan && isNaN(Date.parse(b.lastWeeklyScan))) b.lastWeeklyScan = null; // garbage → throttle would bypass (Date.now()-NaN is never < 3.5d)
    else b.lastWeeklyScan = b.lastWeeklyScan || null;
    if (!b.totals || typeof b.totals !== "object" || Array.isArray(b.totals)) b.totals = { rewards: 0, punishments: 0 };
    // same repair-the-source-fields family as signatures: a string rewards/punishments
    // would string-concatenate forever ("3" → "31" → "311") and never self-heal
    if (typeof b.totals.rewards !== "number" || !Number.isFinite(b.totals.rewards)) b.totals.rewards = 0;
    if (typeof b.totals.punishments !== "number" || !Number.isFinite(b.totals.punishments)) b.totals.punishments = 0;
    // repair the SOURCE fields, not just the derived score — a corrupted ok/fail
    // left in place would re-poison the next scoreRule event (s.ok++ on a string
    // → NaN → serialized as null, erasing the learning signal)
    for (const s of b.signatures) {
      if (typeof s.ok !== "number" || !Number.isFinite(s.ok)) s.ok = 0;
      if (typeof s.fail !== "number" || !Number.isFinite(s.fail)) s.fail = 0;
      if (typeof s.score !== "number") s.score = s.ok - s.fail * 2;
    }
    return b;
  } catch {
    // a corrupt brain is quarantined, NOT silently replaced — replacing it would let
    // the next save destroy every learned rule, quarantine, and per-app memory
    try {
      if (fs.existsSync(BRAIN_FILE) && fs.statSync(BRAIN_FILE).size > 0) {
        const bak = BRAIN_FILE + ".corrupt-" + Date.now();
        fs.renameSync(BRAIN_FILE, bak);
        console.error("[launchpad] brain.json was corrupt — quarantined to " + bak);
      }
    } catch {}
    return { signatures: [], projects: {}, settings: { weeklyScan: true },
             selftests: {}, unknown: [], lastWeeklyScan: null,
             totals: { rewards: 0, punishments: 0 } };
  }
}
function saveBrain(b) {
  try { atomicWrite(BRAIN_FILE, JSON.stringify(b, null, 1)); } catch {}
}
// strip volatile bits so the same crash always looks the same
function normalizeLog(t) {
  return String(t).replace(/\/[^\s:;\"'`,]+/g, "<path>")
    .replace(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g, "<ip>")
    .replace(/:\d{2,5}\b/g, ":<port>").replace(/\b0x[0-9a-f]+\b/gi, "<hex>")
    .replace(/\b\d{4,}\b/g, "<n>").slice(-1200);
}
// reward & punishment: correct calls get rewarded, wrong calls get punished.
// score = rewards − 2×punishments. rules punished down to −4 are quarantined
// (never tried again until something resets them).
function ruleScore(s) { return s.ok - s.fail * 2; }
function scoreRule(ruleId, fix, delta) {
  // delta > 0 rewards, delta < 0 punishes — one helper for both
  if (!ruleId) return;
  const b = loadBrain();
  let s = b.signatures.find(x => x.rule === ruleId);
  if (!s) { s = { rule: ruleId, fix: fix || null, ok: 0, fail: 0, firstSeen: new Date().toISOString() }; b.signatures.push(s); }
  if (fix) s.fix = fix;
  if (delta > 0) { s.ok++; s.lastReward = new Date().toISOString(); b.totals.rewards = (b.totals.rewards || 0) + 1; }
  else { s.fail++; s.lastPunish = new Date().toISOString(); b.totals.punishments = (b.totals.punishments || 0) + 1; }
  s.score = ruleScore(s);
  saveBrain(b);
}
function rewardRule(ruleId, fix) { scoreRule(ruleId, fix, +1); }
function punishRule(ruleId, fix) { scoreRule(ruleId, fix, -1); }
// record that a fix worked (ok=true) or didn't (ok=false) for a diagnosis rule
function learnFix(ruleId, fix, ok) {
  if (ok) rewardRule(ruleId, fix); else punishRule(ruleId, fix);
}
function fixScore(ruleId) {
  const b = loadBrain();
  const s = b.signatures.find(x => x.rule === ruleId);
  return s ? (typeof s.score === "number" ? s.score : s.ok - s.fail * 2) : 0;
}
function quarantined(ruleId) { return fixScore(ruleId) <= -4; } // punished out — not tried again
function rememberUnknown(tail) {
  const sig = normalizeLog(tail).slice(0, 300);
  if (!sig.trim()) return 0;
  const b = loadBrain();
  let u = b.unknown.find(x => x.sig === sig);
  if (u) u.count++;
  else { u = { sig, count: 1, firstSeen: new Date().toISOString() }; b.unknown.push(u); }
  b.unknown = b.unknown.slice(-30);
  saveBrain(b);
  return u.count;
}
function rememberProject(id, patch) {
  const b = loadBrain();
  b.projects[id] = { ...(b.projects[id] || {}), ...patch };
  saveBrain(b);
}
/* change detection: content fingerprint of the app's source files (sha1 per file).
   content-based so a same-size edit is never missed and a mere touch/re-checkout
   never triggers a false "changed". dotfiles ARE included (.env changes count). */
const HASH_SKIP = new Set(["node_modules", ".git", "__pycache__", "dist", ".venv", "venv", "target", ".next"]);
function hashProject(dir) {
  try { // file paths (zip origins): hash the file itself — readdirSync on a file would throw
    if (fs.statSync(dir).isFile()) {
      // stream it — a 154MB zip must not spike the heap on every origin sync/verify/scan
      const hh = crypto.createHash("sha1");
      const fd = fs.openSync(dir, "r");
      try {
        const buf = Buffer.alloc(1024 * 1024);
        let n;
        while ((n = fs.readSync(fd, buf, 0, buf.length)) > 0) hh.update(buf.subarray(0, n));
      } finally { fs.closeSync(fd); }
      return hh.digest("hex").slice(0, 16);
    }
  } catch {}
  const h = crypto.createHash("sha1");
  let files = 0;
  const walk = d => {
    let items;
    try { items = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const it of items) {
      if (it.name === ".DS_Store") continue;
      const full = path.join(d, it.name);
      if (it.isDirectory()) { if (!HASH_SKIP.has(it.name)) walk(full); }
      else if (it.isSymbolicLink()) {
        // symlinks are content too — record the target so a planted/changed link
        // shows up in change detection (readlinkSync never blocks on fifos)
        try { h.update(path.relative(dir, full) + "|link|" + fs.readlinkSync(full) + ";"); files++; } catch {}
      }
      else if (it.isFile() && /\.(js|mjs|cjs|ts|jsx|tsx|py|sh|json|html|css|env|yml|yaml|toml|ini|cfg)$/i.test(it.name)) {
        // isFile() — fifos/sockets/devices report size 0 and would hang readFileSync forever
        try {
          const st = fs.statSync(full);
          // a multi-GB file with a source-ish extension (data.json dump, misnamed .js
          // log) would OOM readFileSync and kill the server — cap content reads at
          // 64 MB and fall back to metadata hashing past it, like the >4000-file cap
          if (files < 4000 && st.size <= 64 * 1024 * 1024) { // full content hash for the first 4000 files
            const data = fs.readFileSync(full);
            h.update(path.relative(dir, full) + "|");
            h.update(data);
            h.update(";");
          } else {
            // past the cap or too big: hash path + size + mtime instead of contents — a new,
            // deleted, renamed, or edited file still changes the fingerprint
            h.update(path.relative(dir, full) + "|" + st.size + "|" + st.mtimeMs + ";");
          }
          files++;
        } catch {}
      }
    }
  };
  walk(dir);
  return files ? h.digest("hex").slice(0, 16) : null;
}
function projectChanged(p) {
  const mem = (loadBrain().projects[p.id] || {});
  if (!mem.contentHash) return false; // never verified — not "changed", just new
  const h = hashProject(p.path);
  return h && h !== mem.contentHash;
}
/* author attribution: hame's code is written by exactly one of these five */
const AUTHORS = {
  muse: "shooter",
  claude: "Claude",
  gemini: "Gemini",
  chatgpt: "ChatGPT",
  copilot: "Base44 CoPilot",
};
/* read a JSON file only if it's a real regular file — a fifo (or a symlink to one)
   at a trusted name like package.json would make readFileSync block forever */
function readJsonFile(fp) {
  try {
    const st = fs.statSync(fp);
    if (!st.isFile()) return null;
    return JSON.parse(fs.readFileSync(fp, "utf8"));
  } catch { return null; }
}
function detectAuthor(p) {
  const scores = { muse: 0, claude: 0, gemini: 0, chatgpt: 0, copilot: 0 };
  try {
    const pkgPath = path.join(p.path, "package.json");
    if (fs.existsSync(pkgPath)) {
      const pkg = readJsonFile(pkgPath);
      const deps = pkg ? Object.keys({ ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) }).join(" ") : "";
      if (/base44/i.test(deps)) scores.copilot += 6;
    }
    let n = 0;
    const walk = d => {
      if (n > 40) return;
      let items;
      try { items = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
      for (const it of items) {
        if (n > 40) return;
        if (it.name.startsWith(".")) continue;
        const full = path.join(d, it.name);
        if (it.isDirectory()) { if (!HASH_SKIP.has(it.name)) walk(full); continue; }
        if (!/\.(js|mjs|ts|jsx|tsx|py|sh|html)$/i.test(it.name)) continue;
        n++;
        let t = "";
        // skip giant files (checked-in bundles, misnamed logs) — reading them whole
        // just to slice 6k would spike the heap on every /api/brain poll.
        // statSync FOLLOWS symlinks, so links-to-fifos are refused too; the isFile()
        // check matters because readFileSync on a fifo BLOCKS forever waiting for a writer
        try { const st = fs.statSync(full); if (!st.isFile() || st.size > 2e6) continue; t = fs.readFileSync(full, "utf8").slice(0, 6000); } catch { continue; }
        if (/from ["']base44|require\(["']base44|@base44/i.test(t)) scores.copilot += 6;
        if (/generated by (base44|copilot)/i.test(t)) scores.copilot += 5;
        if (/generated by chatgpt|written by chatgpt/i.test(t)) scores.chatgpt += 5;
        if (/generated by gemini|written by gemini/i.test(t)) scores.gemini += 5;
        if (/generated by claude|written by claude/i.test(t)) scores.claude += 5;
        if (/generated by muse|muse spark/i.test(t)) scores.muse += 5;
        if (/\bChatGPT\b|\bOpenAI\b/.test(t)) scores.chatgpt += 1;
        if (/\bGemini\b/.test(t)) scores.gemini += 1;
        if (/\bClaude\b|\bAnthropic\b/.test(t)) scores.claude += 1;
      }
    };
    walk(p.path);
  } catch {}
  const best = Object.entries(scores).sort((a, b) => b[1] - a[1])[0];
  if (best[1] <= 0) return null; // 5 fixed keys — best always exists
  // weak evidence (a lone keyword mention) shouldn't claim high confidence
  const confidence = best[1] <= 1 ? 45 : Math.min(99, 40 + best[1] * 8);
  return { author: best[0], confidence };
}
function projectAuthor(p) {
  const mem = (loadBrain().projects[p.id] || {});
  // Object.hasOwn: AUTHORS is a plain literal, so "__proto__"/"constructor" are
  // truthy via Object.prototype — truthiness alone would accept a forged author
  if (mem.authorOverride && Object.hasOwn(AUTHORS, mem.authorOverride))
    return { author: mem.authorOverride, source: "you" };
  if (mem.author && Object.hasOwn(AUTHORS, mem.author))
    return { author: mem.author, source: "detected", confidence: mem.authorConfidence };
  const d = detectAuthor(p);
  if (d) { rememberProject(p.id, { author: d.author, authorConfidence: d.confidence }); return { ...d, source: "detected" }; }
  return { author: null, source: "unknown" };
}
/* per-author profiles: who writes what, and what breaks in their code */
function authorProfiles() {
  const b = loadBrain();
  const out = {};
  for (const key of Object.keys(AUTHORS)) {
    out[key] = { label: AUTHORS[key], apps: [], langs: {}, frameworks: {}, crashes: {}, fixes: 0 };
  }
  for (const p of loadProfiles()) {
    const mem = b.projects[p.id] || {};
    const key = mem.authorOverride || mem.author;
    if (!key || !Object.hasOwn(out, key)) continue; // hasOwn: forged "__proto__" would ride Object.prototype
    const pr = out[key];
    pr.apps.push(p.name);
    const scan = scanProject(p.path);
    if (scan.stack === "node") pr.langs.javascript = (pr.langs.javascript || 0) + 1;
    if (scan.stack === "python") pr.langs.python = (pr.langs.python || 0) + 1;
    for (const dep of (scan.deps || []).slice(0, 40)) {
      if (/^(express|react|vue|electron|flask|django|fastapi|next|vite|axios|sqlite|better-sqlite3)$/.test(dep))
        pr.frameworks[dep] = (pr.frameworks[dep] || 0) + 1;
    }
    for (const [rule, n] of Object.entries(mem.crashRules || {}))
      pr.crashes[rule] = (pr.crashes[rule] || 0) + n;
  }
  return out;
}
/* self-test corpus: does the diagnoser still catch everything it knows? */
const SELFTESTS = [
  ["Error: listen EADDRINUSE: address already in use :::3000", "eaddrinuse"],
  ["Error: Cannot find module 'express'", "modulenotfound"],
  ["ModuleNotFoundError: No module named 'flask'", "pymodulenotfound"],
  ["connect ECONNREFUSED 127.0.0.1:11434", "ollamarefused"],
  ["model \"llama3\" not found", "ollamamodel"],
  ["Error: listen EACCES: permission denied 0.0.0.0:80", "eacces"],
  ["SyntaxError: Unexpected token '}'", "syntax"],
  ["FileNotFoundError: [Errno 2] No such file or directory: 'data.db'", "pyfilenotfound"],
  ["Error: SQLITE_BUSY: database is locked", "sqlitebusy"],
  ["Unable to open X display", "electron-display"],
  ["npm warn EBADENGINE Unsupported engine", "nodever"],
  ["ollama: command not found", "ollamabin"],
];
function runSelfTests() {
  const b = loadBrain();
  let pass = 0;
  const failed = [];
  for (const [snippet, expected] of SELFTESTS) {
    const d = diagnose(snippet);
    if (d.length && d[0].rule === expected) pass++;
    else failed.push(expected);
  }
  b.selftests = { lastRun: new Date().toISOString(), passed: pass, total: SELFTESTS.length, failed };
  saveBrain(b);
  return b.selftests;
}
/* verify a stored app without launching: paths, deps, syntax */
async function verifyProject(p) {
  const issues = [];
  if (!fs.existsSync(p.path)) issues.push("folder gone: " + p.path);
  else {
    const scan = scanProject(p.path);
    if (!scan.ok) issues.push(scan.error);
    else {
      if (scan.stack === "node") {
        try {
          const pkg = readJsonFile(path.join(p.path, "package.json")) || {};
          const missing = Object.keys(pkg.dependencies || {}).filter(d => {
            try { require.resolve(d, { paths: [p.path] }); return false; } catch { return true; }
          });
          if (missing.length) issues.push("missing modules: " + missing.slice(0, 5).join(", "));
        } catch {}
        for (const e of scan.entries.slice(0, 3)) {
          const m = e.command.match(/node\s+(\S+\.(?:js|mjs|cjs))/);
          if (m) try { await execFile("node", ["--check", path.join(p.path, m[1])], { timeout: 15000 }); }
          catch { issues.push("syntax error in " + m[1]); }
        }
      }
      if (scan.stack === "python") {
        for (const e of scan.entries.slice(0, 3)) {
          const m = e.command.match(/python[\d.]*\s+(\S+\.py)/);
          if (m) try { await execFile("python3", ["-m", "py_compile", path.join(p.path, m[1])], { timeout: 15000 }); }
          catch { issues.push("syntax error in " + m[1]); }
        }
      }
    }
  }
  const ch = hashProject(p.path);
  const patch = { lastVerified: new Date().toISOString(), issues,
    lastChangeScan: new Date().toISOString() };
  if (ch) patch.contentHash = ch; // never wipe a good hash with null (unreadable dir)
  rememberProject(p.id, patch);
  return issues;
}
/* pre-flight: fix the cheap stuff BEFORE launching so it runs first time */
async function preflight(p, scan, log) {
  for (const e of scan.entries) { // shell scripts need +x or they die instantly
    const m = e.command.match(/^\.\/(\S+\.sh)/);
    if (m) {
      // jailed: the script must stay inside the project dir (no ../ escapes)
      const fp = path.resolve(p.path, m[1]);
      if (!fp.startsWith(path.resolve(p.path) + path.sep)) { log("pre-flight: refusing chmod outside project: " + m[1]); continue; }
      // chmodSync follows symlinks — a symlink entry would chmod the LINK TARGET (anywhere on disk)
      try { if (fs.lstatSync(fp).isSymbolicLink()) { log("pre-flight: refusing chmod on symlink: " + m[1]); continue; } } catch {}
      try { fs.accessSync(fp, fs.constants.X_OK); }
      catch { try { fs.chmodSync(fp, 0o755); log("pre-flight: made executable " + m[1]); } catch {} }
    }
  }
  if (scan.stack === "node") { // every dep actually resolvable, not just "node_modules exists"
    try {
      const pkg = readJsonFile(path.join(p.path, "package.json")) || {};
      const missing = Object.keys(pkg.dependencies || {}).filter(d => {
        try { require.resolve(d, { paths: [p.path] }); return false; } catch { return true; }
      });
      if (missing.length) { log("pre-flight: missing " + missing.slice(0, 4).join(", ") + " → npm install"); await runFix(p, { action: "npm-install" }); }
    } catch {}
  }
  if (scan.stack === "python") { // compile-check entry files before launch
    for (const e of scan.entries.slice(0, 2)) {
      const m = e.command.match(/python[\d.]*\s+(\S+\.py)/);
      if (m) try { await execFile("python3", ["-m", "py_compile", path.join(p.path, m[1])], { timeout: 20000 }); }
      catch { log("pre-flight: syntax error in " + m[1]); }
    }
  }
}
/* idle smoke test: launch briefly, confirm healthy, stop. proves it runs first time. */
async function smokeTest(p) {
  const r = runner(p.id);
  if (r.proc || !p.command || p.command === "auto") return;
  const res = startProject(p);
  if (!res.ok) { rememberProject(p.id, { lastSmoke: new Date().toISOString(), smokeOk: false, smokeNote: res.error }); return; }
  const t0 = Date.now();
  let state = "alive";
  while (Date.now() - t0 < 12000) {
    await new Promise(r2 => setTimeout(r2, 1000));
    const rr = runner(p.id);
    if (!rr.proc) { state = rr.status === "crashed" ? "crashed" : "exited-ok"; break; }
    for (const port of portsFromLogs(rr.logs.slice(-40))) {
      if (await checkPort(port)) { state = "serving:" + port; break; }
    }
    if (state.startsWith("serving")) break;
  }
  await stopProject(p); // wait for the old process to fully die — or the next scan/app inherits its port
  rememberProject(p.id, { lastSmoke: new Date().toISOString(),
    smokeOk: state !== "crashed", smokeNote: state });
}
/* twice-weekly health scan: only re-tests apps whose code actually changed.
   verify also runs: after a code change (at launch), after a failed launch, or on demand. */
let scanRunning = false;
async function maybeWeeklyScan(force) {
  if (scanRunning) return;
  let ran = false;
  let completed = false; // declared OUTSIDE the try — catch/finally must see it
  try {
    const brain = loadBrain();
    if (!brain.settings.weeklyScan) return;
    const last = brain.lastWeeklyScan ? Date.parse(brain.lastWeeklyScan) : 0;
    if (!force && Date.now() - last < 3.5 * 24 * 60 * 60 * 1000) return; // twice a week
    if ([...runners.values()].some(r => r.autopilot || r.proc)) return; // busy — try at next check
    scanRunning = true; ran = true;
    completed = true; // the stamp below is earned only if the scan actually ran
    runSelfTests(); // drill the diagnoser
    for (const p of loadProfiles()) {
      if ([...runners.values()].some(r => r.autopilot || r.proc)) { completed = false; break; } // user started something — stop
      const mem = (loadBrain().projects[p.id] || {});
      const h = hashProject(p.path);
      if (mem.contentHash && h && h !== mem.contentHash) {
        pushLog(p.id, "[scan] code changed since last check — verifying + smoke-testing");
        await verifyProject(p);
        if (p.command && p.command !== "auto") await smokeTest(p);
      } else if (h) {
        rememberProject(p.id, { contentHash: h, lastChangeScan: new Date().toISOString() });
      }
      // h null (unreadable dir): keep the old hash — never wipe it
    }
  } catch (e) { console.error("[launchpad] weekly scan failed:", e.message); completed = false; }
  finally {
    scanRunning = false;
    // stamp only if the scan actually completed — an aborted scan must NOT push the
    // next check 3.5 days out, or the "twice-weekly" scan can silently do nothing for a week
    if (ran && completed) { const fresh = loadBrain(); fresh.lastWeeklyScan = new Date().toISOString(); saveBrain(fresh); }
  }
}

/* ---------------- process control ---------------- */
function startProject(p) {
  const r = runner(p.id);
  if (r.proc) return { ok: false, error: "already running" };
  if (r.stopping) return { ok: false, error: "stopping — try again in a moment" }; // the old group isn't dead yet
  r.status = "starting";
  r.manualStop = false; // a fresh start is never a "user stop" — belt and suspenders
  r.ready = false; r.appUrl = null; // a fresh launch is not ready until proven — a stale
  // ready would keep offering "Open app" on the previous (dead) URL (round-21 find)
  r.phase = ""; // a fresh launch has no phase yet — a stale "needs you"/"ready" badge
  // from a previous run would lie on the dashboard while the new launch is starting (round-22 find)
  pushLog(p.id, `$ ${p.command}   (cwd: ${p.path})`);
  let proc;
  try {
    proc = cp.spawn(p.command, {
      cwd: p.path, shell: true, detached: true,
      env: { ...process.env, ...(p.env || {}), FORCE_COLOR: "0" },
    });
  } catch (e) {
    r.status = "error";
    pushLog(p.id, "[launchpad] spawn failed: " + e.message);
    return { ok: false, error: e.message };
  }
  r.proc = proc;
  r.startedAt = Date.now();
  r.status = "starting"; // not "running" yet — the 3s warmup below promotes it
  r.lastDiag = [];
  broadcast(p.id, { type: "status", status: "starting" });
  proc.stdout.on("data", d => String(d).split("\n").forEach(l => l && pushLog(p.id, l)));
  proc.stderr.on("data", d => String(d).split("\n").forEach(l => l && pushLog(p.id, "[err] " + l)));
  proc.on("exit", (code, sig) => {
    r.proc = null;
    r.ready = false; r.appUrl = null; // the process is dead — it is not ready and its
    // URL is dead; leaving them set offers "Open app" on a dead port (round-21 find)
    if (r.manualStop) { // user hit stop — not a crash
      r.manualStop = false; r.lastDiag = [];
      r.status = "stopped";
      broadcast(p.id, { type: "status", status: "stopped", phase: r.phase });
      return;
    }
    r.status = code === 0 ? "stopped" : "crashed";
    pushLog(p.id, `[launchpad] exited code=${code} signal=${sig || "-"}`);
    const tail = r.logs.slice(-120).join("\n");
    r.lastDiag = diagnose(tail);
    broadcast(p.id, { type: "status", status: r.status, diagnosis: r.lastDiag });
  });
  proc.on("error", e => {
    // async spawn failure (bad command, ENOENT): the process is dead on arrival —
    // report it as a crash so the watch loop diagnoses it instead of waiting 35s
    // and declaring "still running" on something that never started
    pushLog(p.id, "[launchpad] process error: " + e.message);
    r.proc = null; r.status = "crashed";
    r.ready = false; r.appUrl = null; // never started — not ready, no URL (round-21 find)
    r.lastDiag = diagnose(String(e.message));
    broadcast(p.id, { type: "status", status: "crashed", diagnosis: r.lastDiag });
  });
  // warmup: if THIS process generation is still alive after 3s, mark healthy
  // (capture proc — a later generation's "starting" must not be promoted by this timer)
  const warmupProc = proc;
  setTimeout(() => { if (r.proc === warmupProc && r.status === "starting") { r.status = "running"; broadcast(p.id, { type: "status", status: "running" }); } }, 3000);
  return { ok: true };
}
async function stopProject(p) {
  const r = runner(p.id);
  if (r.stopping) { // a stop is already in flight — wait for it, don't double-kill
    while (r.stopping) await new Promise(r2 => setTimeout(r2, 200));
    return { ok: true };
  }
  r.autopilot = false; r.phase = "";
  // "stop" stops the tool's work on the app, not just the app process — an in-flight
  // npm/pip install would otherwise keep mutating the tree under the next launch
  const killedFixes = killFixProcs(p.id);
  if (killedFixes) pushLog(p.id, `[launchpad] stopped ${killedFixes} in-flight fix/install process(es)`);
  const proc = r.proc;
  const pid = proc ? proc.pid : null; // capture now — proc may be replaced mid-stop
  r.stopping = true;
  try {
    if (!pid) { r.proc = null; r.status = "stopped"; }
    else {
      // only a REAL kill counts — set the flag only when the signal was actually
      // delivered. a stale flag would mask the next genuine crash as a clean stop
      // (e.g. the exit event of an already-dead process is still in flight)
      let killed = false;
      try { process.kill(-pid, "SIGTERM"); killed = true; } catch {} // ESRCH = already dead
      if (killed) r.manualStop = true;
      pushLog(p.id, "[launchpad] stop requested");
      // wait until the process group is actually gone before returning, so a
      // restart can't launch the new instance while the old one still holds the port
      const killer = setTimeout(() => { try { process.kill(-pid, "SIGKILL"); } catch {} }, 4000);
      const t0 = Date.now();
      while (Date.now() - t0 < 8000) {
        try { process.kill(-pid, 0); } catch { break; } // ESRCH — the group is gone
        await new Promise(r2 => setTimeout(r2, 200));
      }
      clearTimeout(killer);
      // clear only once the group is confirmed dead — keeping r.proc set during the
      // wait is what blocks startProject's "already running" guard from launching
      // a duplicate instance while the old one still holds its port
      r.proc = null; r.status = "stopped";
    }
  } finally {
    r.stopping = false;
    broadcast(p.id, { type: "status", status: "stopped" });
  }
  return { ok: true };
}

/* ---------------- fixes (async, streams to the log) ---------------- */
function runFix(p, fix) {
  // async executor: the fix cases below await subprocess probes without blocking
  // the event loop; everything stays inside the try/catch so a throw still settles
  // via done() instead of becoming an unhandled rejection
  return new Promise(async resolve => {
    const log = l => pushLog(p.id, "[fix] " + l);
    let finished = false;
    const done = (ok, msg) => {
      if (finished) return; // node emits both "error" and "close" on spawn failure
      finished = true;
      log((ok ? "done: " : "FAILED: ") + msg); resolve({ ok });
    };
    const sh = (cmd, timeoutMs) => {
      log("$ " + cmd);
      // detached: on timeout we kill the whole process GROUP — killing just the shell
      // orphans npm/pip grandchildren that keep running headless with the cache lock
      const child = cp.spawn(cmd, { cwd: p.path, shell: true, detached: true });
      trackFixProc(p.id, child); // a Stop (or superseding relaunch) kills this
      const timer = timeoutMs ? setTimeout(() => { try { process.kill(-child.pid, "SIGKILL"); } catch {} }, timeoutMs) : null;
      child.stdout.on("data", d => String(d).split("\n").forEach(l => l.trim() && log(l.trim().slice(0, 300))));
      child.stderr.on("data", d => String(d).split("\n").forEach(l => l.trim() && log(l.trim().slice(0, 300))));
      child.on("close", code => { untrackFixProc(p.id, child); if (timer) clearTimeout(timer); done(code === 0, `exited ${code}`); });
      child.on("error", e => { untrackFixProc(p.id, child); if (timer) clearTimeout(timer); done(false, e.message); });
    };
    try {
      switch (fix.action) {
        case "npm-install": sh("npm install", 900000); break;
        case "pip-install": {
          const pkg = String(fix.arg || "").replace(/[^a-zA-Z0-9_.-]/g, "");
          if (!pkg || pkg.startsWith("-")) return done(false, "bad package name"); // no flag injection
          // sandbox: install into the sandbox venv — never system site-packages, which
          // the LIVE python app imports from
          if (String(p.id).endsWith(":sandbox")) {
            const venvPip = path.join(p.path, ".venv", "bin", "pip");
            if (!fs.existsSync(venvPip)) return done(false, "no sandbox venv — refusing to touch system packages");
            sh('"' + venvPip + '" install ' + pkg, 900000);
          } else {
            sh("pip3 install --break-system-packages " + pkg, 900000);
          }
          break;
        }
        case "kill-port": {
          const port = String(fix.arg || "").replace(/\D/g, "");
          if (!port) return done(false, "no port given"); // never run `fuser -k /tcp`
          log("$ fuser -k " + port + "/tcp");
          // check fuser's own exit code — don't report success when it did nothing
          try {
            await execFile("fuser", ["-k", port + "/tcp"], { timeout: 15000, stdio: "ignore" });
            log("done: port " + port + " freed");
            return done(true, "port " + port + " freed");
          } catch (e) {
            log("fuser found nothing on port " + port + " (or failed) — continuing");
            return done(false, "nothing on port " + port);
          }
        }
        case "ollama-serve":
          try { await execFile("pgrep", ["-x", "ollama"], { timeout: 8000, stdio: "ignore" }); return done(true, "ollama already running"); }
          catch {
            // shell:true always spawns /bin/sh fine — check the binary exists first,
            // or we'd "succeed" while the shell silently 127s on a missing ollama
            // (`command` is a shell builtin — probe it through sh, not execFile)
            try { await execFile("sh", ["-c", "command -v ollama"], { timeout: 8000, stdio: "ignore" }); }
            catch { return done(false, "ollama is not installed on this system"); }
            const child = cp.spawn("ollama serve", { shell: true, detached: true, stdio: "ignore" });
            child.unref();
            return done(true, "ollama serve started");
          }
        case "ollama-pull": {
          const model = String(fix.arg || "").replace(/[^a-zA-Z0-9_.:-]/g, "");
          if (!model) return done(false, "bad model name");
          sh("ollama pull " + model, 3600000); break;
        }
        default: return done(false, "unknown fix");
      }
    } catch (e) { done(false, e.message.split("\n")[0]); }
  });
}

/* ---------------- autopilot: add app -> ready, no clicks ---------------- */
function setPhase(id, phase) {
  const r = runner(id);
  r.phase = phase;
  broadcast(id, { type: "status", status: r.status, phase });
}
function checkPort(port) {
  return new Promise(resolve => {
    // total function: net.connect throws ERR_SOCKET_BAD_PORT synchronously on
    // out-of-range/non-integer ports, which would reject this promise and crash
    // the caller's run. memPort comes from brain.json's lastPort, which loadBrain
    // does not validate — a single corrupted value (999999, -5, 3.5, "abc") must
    // probe as closed, not kill the launch (round-21 find).
    const n = typeof port === "number" ? port : Number(String(port).trim());
    if (!Number.isInteger(n) || n < 1 || n > 65535) return resolve(false);
    const s = net.connect(n, "127.0.0.1");
    let done = false;
    const fin = v => { if (!done) { done = true; try { s.destroy(); } catch {} resolve(v); } };
    s.on("connect", () => fin(true));
    s.on("error", () => fin(false));
    setTimeout(() => fin(false), 900);
  });
}
function portsFromLogs(lines) {
  const ports = new Set();
  // localhost:3000 | "port 3000" / "port: 3000" / "port=3000" | "listening on :3000" / "listening on 3000"
  const re = /(?:localhost|127\.0\.0\.1|0\.0\.0\.0):(\d{2,5})|\bport\s*[:=]?\s*(\d{2,5})\b|listening on(?:[^\d:]{0,8}:|\s+)(\d{2,5})\b/gi;
  let m;
  const text = lines.join("\n");
  while ((m = re.exec(text))) {
    const p = parseInt(m[1] || m[2] || m[3], 10);
    if (p >= 1024 && p <= 65535 && p !== PORT) ports.add(p);
  }
  return [...ports];
}
function pickEntry(scan) {
  const scored = scan.entries.map(e => {
    let s = 50;
    if (e.command === "npm start") s = 100;
    else if (/start\.sh|launch\.sh|run\.sh/.test(e.command)) s = 90;
    else if (/server\/index\.js/.test(e.command)) s = 80;
    else if (/(^|\/)index\.js$/.test(e.command)) s = 70;
    else if (/app\.py|main\.py|server\.py/.test(e.command)) s = 70;
    return { ...e, s };
  }).sort((a, b) => b.s - a.s);
  return scored[0] || null;
}
function handleZip(zippath, id) {
  const dest = storeDir(id); // zips always land inside the tool's organized store
  const tmp = dest + ".unzip-" + process.pid;
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.mkdirSync(tmp, { recursive: true });
  try {
    cp.execFileSync("unzip", ["-q", "-o", zippath, "-d", tmp]); // arg array — no shell, no injection
  } catch (e) {
    fs.rmSync(tmp, { recursive: true, force: true });
    throw new Error("couldn't extract zip: " + String(e.message || "").split("\n")[0]);
  }
  // strip zip-planted symlinks FIRST — they can point outside the store and would let
  // reads/writes escape the project jail (ingestApp skips them; unzip restores them)
  const stripLinks = d => {
    for (const it of fs.readdirSync(d, { withFileTypes: true })) {
      const full = path.join(d, it.name);
      if (it.isSymbolicLink()) { try { fs.unlinkSync(full); } catch {} }
      else if (it.isDirectory()) stripLinks(full);
    }
  };
  stripLinks(tmp);
  // only AFTER stripping: the single-item check stats the entry, and a stripped
  // symlink would make statSync throw ENOENT on an app that stored fine
  const items = fs.readdirSync(tmp).filter(n => !n.startsWith(".") && !n.startsWith("__MACOSX"));
  fs.rmSync(dest, { recursive: true, force: true });
  fs.renameSync(tmp, dest); // atomic swap — a failed extract never destroys the stored copy
  // zips that wrap everything in one folder: the app root is that inner folder
  if (items.length === 1 && fs.statSync(path.join(dest, items[0])).isDirectory())
    return path.join(dest, items[0]);
  return dest;
}
async function autopilot(id) {
  const p0 = getProfile(id);
  if (!p0) return;
  const r = runner(id);
  if (r.autopilot) return;
  // a stop takes up to 8s to kill the process group — launching into that window
  // makes startProject refuse ("already running", ignored) and the new loop ends up
  // watching the old dying process, so the launch silently dies. wait it out first.
  let p = p0;
  if (r.stopping) {
    pushLog(id, "[auto] waiting for the stop to finish ...");
    while (runner(id).stopping) await new Promise(r2 => setTimeout(r2, 200));
    if (runner(id).autopilot) return; // something else claimed it while we waited
    p = getProfile(id); // the app may have been deleted during the wait — don't launch a ghost
    if (!p) return;
  }
  r.autopilot = true; // claim synchronously — autopilotRun starts on next tick
  setImmediate(() => autopilotRun(p, { persist: true }));
}
/* core autopilot: works on any profile-like {id, path, command, env}.
   opts: persist (save chosen entry to profiles), sandbox (no browser open, no destructive fixes),
   livePort (sandbox: never kill this port — it's the live app). */
async function autopilotRun(p, opts) {
  const id = p.id;
  opts = opts || {};
  const r = runner(id);
  r.autopilot = true; // (re)claim — caller guards against double-start
  // generation counter: a stop+relaunch starts a NEW run while the old loop may still
  // be stuck in a long await (npm install, runFix, preflight...). the old loop is
  // SUPERSEDED — it must exit quietly, never finish() (which would set autopilot=false
  // and clobber the new run) and never apply fixes or learn (double-punish).
  const myGen = (r.runSeq = (r.runSeq || 0) + 1);
  const superseded = () => runner(id).runSeq !== myGen;
  r.ready = false; r.appUrl = null;
  const log = l => pushLog(id, "[auto] " + l);
  // a previous run may have left fix/install children alive (stop mid-install, or the
  // old loop is still stuck inside await runFix) — two installs on one tree corrupt it
  const leftovers = killFixProcs(id);
  if (leftovers) log(`killed ${leftovers} leftover fix/install process(es) from the previous run`);
  // sandbox runs prove things — they must never teach the brain or write junk
  // memory keys (no rewards, no punishments, no "p-xxx:sandbox" entries)
  const learning = !opts.sandbox;
  const mem = obj => { if (learning) rememberProject(id, obj); };
  const learn = (rule, fix, ok) => { if (learning) learnFix(rule, fix, ok); };
  const finish = (status, phase) => {
    r.autopilot = false; r.status = status; setPhase(id, phase);
    broadcast(id, { type: "status", status, phase, appUrl: r.appUrl });
  };
  try {
    r.status = "working";
    if (!opts.sandbox && p.origin) {
      // never pull files from under a live app — wiping the store dir mid-run cripples
      // the running process and violates "never replace a working app"; the originHash
      // is untouched so the sync fires on the next launch after a stop
      if (runner(id).proc) log("origin changed but the app is running — skipping sync until you stop it");
      else syncStoreFromOrigin(p, log);
    }
    const scan = scanProject(p.path);
    if (!scan.ok) { log(scan.error); return finish("stopped", "needs you"); }

    // verify-after-change: code changed since last check → verify before launch
    if (projectChanged(p)) {
      log("code changed since last check — verifying before launch");
      const vissues = await verifyProject(p);
      if (superseded()) return; // restarted during verify — the new run owns it; never install on its behalf
      if (!runner(id).autopilot) return finish("stopped", ""); // stopped during verify — honor it; never continue a dead run
      if (vissues.length) log("verify found: " + vissues.slice(0, 3).join("; "));
      else log("verify clean");
    } else {
      const h2 = hashProject(p.path);
      if (h2) mem({ contentHash: h2 }); // never wipe a known hash with null (unreadable dir, emptied sources)
    }

    // 1. dependencies, automatically
    if (scan.stack === "node" && !fs.existsSync(path.join(p.path, "node_modules"))) {
      setPhase(id, "installing dependencies");
      log("node_modules missing → npm install ...");
      const res = await runFix(p, { action: "npm-install" });
      if (!res.ok) log("npm install had issues, continuing anyway");
      if (superseded()) return; // restarted during npm install — the new run owns it
      if (!runner(id).autopilot) return finish("stopped", ""); // user stopped — never install on a dead run
    }
    if (scan.stack === "python" && fs.existsSync(path.join(p.path, "requirements.txt"))) {
      const reqFile = path.join(p.path, "requirements.txt");
      let reqHash = null;
      // type-checked read: a fifo at this path would make readFileSync block forever
      try { const rst = fs.statSync(reqFile); if (rst.isFile()) reqHash = crypto.createHash("sha1").update(fs.readFileSync(reqFile)).digest("hex").slice(0, 16); } catch {}
      const knownPip = (loadBrain().projects[id] || {}).pipHash;
      if (reqHash && knownPip === reqHash) {
        log("requirements.txt unchanged — skipping pip install");
      } else {
        setPhase(id, "installing python dependencies");
        // sandbox: install into the sandbox venv — NEVER system site-packages, which
        // the live python app imports from (a sandbox pip install would break it)
        const venvPip = opts.sandbox ? path.join(p.path, ".venv", "bin", "pip") : null;
        const useVenv = !!(venvPip && fs.existsSync(venvPip));
        // hoisted to THIS block: the trailing mem({pipHash}) gate below reads it, and
        // the inner else's declaration used to shadow-nothing — it was block-scoped
        // there, so the gate threw ReferenceError after every pip run (round-16 find)
        let pipOk = false; // a killed/failed install must NOT record the hash — the next
                           // launch would "requirements unchanged" skip a half-written tree
        if (opts.sandbox && !useVenv) {
          log("sandbox python: no isolated venv — refusing pip install into system packages");
        } else {
          const pipCmd = useVenv ? `"${venvPip}" install -r requirements.txt`
                                 : "pip3 install --break-system-packages -r requirements.txt";
          log((useVenv ? "venv pip" : "pip") + " install -r requirements.txt ...");
          await new Promise(res2 => {
            const child = cp.spawn(pipCmd,
              { cwd: p.path, shell: true, detached: true }); // detached: the timeout kills the whole group, not just the shell
            trackFixProc(id, child); // a Stop (or superseding relaunch) kills this
            const timer = setTimeout(() => { // a hung pip must never hang the run forever
              try { process.kill(-child.pid, "SIGKILL"); } catch {}
              log("pip install timed out after 15 minutes");
            }, 900000);
            child.stdout.on("data", d => String(d).split("\n").forEach(l => l.trim() && log("[pip] " + l.trim().slice(0, 200))));
            child.stderr.on("data", d => String(d).split("\n").forEach(l => l.trim() && log("[pip] " + l.trim().slice(0, 200))));
            child.on("close", code => { untrackFixProc(id, child); clearTimeout(timer); pipOk = code === 0; log("pip install exited " + code); res2(); });
            child.on("error", e => { untrackFixProc(id, child); clearTimeout(timer); pipOk = false; log("pip install error: " + e.message); res2(); });
          });
        }
        log("python deps done");
        if (reqHash && pipOk) mem({ pipHash: reqHash });
      }
    }

    // 2. pre-flight: fix the cheap stuff before launching so it runs first time
    setPhase(id, "pre-flight checks");
    await preflight(p, scan, log);

    // 3. entry point, automatically
    if (!p.command || p.command === "auto") {
      if (superseded()) return; // never finish() on a superseded run — the new run owns the app
      const best = pickEntry(scan);
      if (!best) {
        log("couldn't figure out the entry point — open the app and pick it manually");
        return finish("stopped", "needs you");
      }
      p.command = best.command;
      if (opts.persist) {
        const ps = loadProfiles();
        const ix = ps.findIndex(x => x.id === id);
        if (ix >= 0) { ps[ix].command = best.command; saveProfiles(ps); }
      }
      log("entry point: " + best.command);
    }

    // 4. launch → watch → auto-fix → retry
    let lastAppliedFix = null;
    const memPort = (loadBrain().projects[id] || {}).lastPort; // learned from last healthy run
    // only trust the remembered port if it was CLOSED before launch — if something
    // else already holds it, claiming "ready" on it would point at the wrong service
    const memPortWasOpen = memPort ? await checkPort(memPort) : false;
    if (memPort) log("remembered port from last run: " + memPort + (memPortWasOpen ? " (already in use — not trusting it)" : ""));
    for (let attempt = 1; attempt <= 5; attempt++) {
      if (superseded()) return; // a newer run owns this app now — exit quietly, never finish()
      if (!runner(id).autopilot) return finish("stopped", ""); // stopped with no successor — clear the phase
      setPhase(id, attempt === 1 ? "launching" : `re-launching (attempt ${attempt}/5)`);
      log("launching: " + p.command);
      r.ready = false; r.appUrl = null; r.quarantineLogged = null;
      startProject(p);
      const t0 = Date.now();
      let outcome = "timeout", readyPort = null;
      while (Date.now() - t0 < 35000) {
        await new Promise(r2 => setTimeout(r2, 1000));
        if (superseded()) return; // a newer run owns this app now — exit quietly, never finish()
        if (!runner(id).autopilot) return finish("stopped", ""); // user hit stop — stopProject already broadcast
        const rr = runner(id);
        if (!rr.proc && !["starting", "running", "working"].includes(rr.status)) {
          outcome = rr.status === "stopped" ? "exited-clean" : "crashed"; // code 0 ≠ crash
          break;
        }
        let candidates = portsFromLogs(rr.logs.slice(-40));
        // a port that was open BEFORE launch can't be trusted even if the app's own logs
        // mention it ("port 8080 in use, trying 8081") — checkPort can't tell the squatter from the app
        if (memPort && memPortWasOpen) candidates = candidates.filter(pt => String(pt) !== String(memPort));
        if (memPort && !memPortWasOpen) candidates.unshift(memPort);
        if (opts.sandbox && opts.livePort) // never declare the sandbox "ready" on the LIVE app's port
          candidates = candidates.filter(pt => String(pt) !== String(opts.livePort));
        for (const port of candidates) {
          if (await checkPort(port)) { readyPort = port; outcome = "ready"; break; }
        }
        if (outcome === "ready") break;
      }
      if (outcome === "ready") {
        // restarted/stopped during the final port probe — the new run owns it now;
        // without this re-check a stale run would open a browser tab at a dying app
        if (superseded()) return;
        if (!runner(id).autopilot) return finish("stopped", "");
        r.ready = true; r.appUrl = `http://localhost:${readyPort}`;
        log(`READY → ${r.appUrl}`);
        if (!opts.sandbox) { try { cp.spawn("xdg-open", [r.appUrl], { detached: true, stdio: "ignore" }).on("error", () => {}).unref(); } catch {} }
        mem({ lastPort: readyPort, workingCommand: p.command,
          startupMs: Date.now() - t0, lastHealthy: new Date().toISOString() });
        if (lastAppliedFix && !opts.sandbox) {
          // the fix worked once — now prove it 3× before it earns trust (reward/punish inside)
          const laf = lastAppliedFix;
          log("fix held — running triple-check (3× verify) before trusting it");
          if (claimTriple(id)) setImmediate(() => tripleCheck(id, {
            rule: laf.rule, label: "post-fix: " + (laf.fix.label || laf.rule), restoreOnFail: false
          }).then(() => {}).catch(e => pushLog(id, "[3x] error: " + e.message)));
          else log("triple-check already running — skipping duplicate post-fix check");
        }
        return finish("running", "ready");
      }
      if (outcome === "crashed") {
        const rawDiags = runner(id).lastDiag;
        // prefer diagnoses whose fixes have the best track record — this is the learning.
        // scores are read once, not per comparison (fixScore hits the disk)
        const scoreCache = {};
        for (const d of rawDiags) if (!(d.rule in scoreCache)) scoreCache[d.rule] = fixScore(d.rule);
        const diags = rawDiags.slice().sort((a, b) => scoreCache[b.rule] - scoreCache[a.rule]);
        const d0 = diags[0];
        if (d0 && d0 !== rawDiags[0]) log(`learned preference: trying "${d0.title}" first (worked before)`);
        log(`crashed: ${d0 ? d0.title + " — " + d0.detail : "unknown error"}`);
        if (!d0) {
          // sandbox runs prove things — they must never teach the brain
          if (learning) {
            const seen = rememberUnknown(runner(id).logs.slice(-60).join("\n"));
            log(seen > 1 ? `seen this exact crash ${seen}x before — no known fix yet` : "new crash signature recorded for next time");
          } else log("unknown crash in sandbox — signature not recorded (sandbox runs never teach the brain)");
        } else { // track what breaks per app — feeds the author profiles
          const bmem = (loadBrain().projects[id] || {});
          const cr = { ...(bmem.crashRules || {}) };
          cr[d0.rule] = (cr[d0.rule] || 0) + 1;
          mem({ crashRules: cr });
        }
        const fixable = diags.find(d => {
          if (!d.fix) return false;
          if (quarantined(d.rule)) {
            if (!r.quarantineLogged) r.quarantineLogged = new Set();
            if (!r.quarantineLogged.has(d.rule)) { // say it once per run, not per crash
              r.quarantineLogged.add(d.rule);
              log(`skipping "${d.title}" — punished out of trust (score ${scoreCache[d.rule]})`);
            }
            return false;
          }
          // sandbox copies must NEVER kill anything outside themselves: the assigned port
          // comes from a bind-read-close race, so an unrelated process could own it by
          // launch time. refusing kill-port wholesale (live-port exclusion is subsumed)
          if (opts.sandbox && d.fix.action === "kill-port") {
            log(`sandbox: refusing to kill port ${d.fix.arg} — a sandbox must never touch outside processes`);
            return false;
          }
          return true;
        });
        if (fixable && attempt < 5) {
          setPhase(id, `auto-fixing: ${fixable.title}`);
          log("applying fix: " + fixable.fix.label);
          const res = await runFix(p, fixable.fix);
          if (superseded()) return; // stopped+relaunched during the fix — the new run owns it; don't touch anything
          // a plain Stop SIGKILLs the fix child, forcing res.ok=false — never punish a
          // rule for a user interruption; exit quietly instead
          if (!runner(id).autopilot) return finish("stopped", "");
          lastAppliedFix = { rule: fixable.rule, fix: fixable.fix, fixOk: res.ok };
          if (!res.ok) learn(fixable.rule, fixable.fix, false); // the fix command itself failed
          await new Promise(r2 => setTimeout(r2, 2000));
          continue;
        }
        // terminal punish ONLY if the fix ran fine but the app still never got ready —
        // a failed fix command was already punished above (punishing twice = instant quarantine)
        if (lastAppliedFix && lastAppliedFix.fixOk) learn(lastAppliedFix.rule, lastAppliedFix.fix, false);
        if (d0 && d0.hint) log("hint: " + d0.hint);
        if (!opts.sandbox) { // verify-after-failed-launch: record what's wrong
          const vissues = await verifyProject(p);
          if (vissues.length) log("verify found: " + vissues.slice(0, 3).join("; "));
        }
        // relaunched during the verify above — the new run owns it now; finish() would
        // clobber the new run (sets r.autopilot=false and misreports "crashed")
        if (superseded()) return;
        // user hit Stop during the verify — honor it (the app did crash, but the
        // user asked to stop; misreporting "crashed" overrides their stop)
        if (!runner(id).autopilot) return finish("stopped", "");
        log("tried everything I safely can — open the Console, the details are there");
        return finish("crashed", "needs you");
      }
      if (outcome === "exited-clean") {
        log("app exited on its own (code 0) — it's a script, not a server. nothing to fix.");
        return finish("stopped", "exited");
      }
      // alive after 35s but no web port found — accept it
      log("still running, no web port detected — calling it good");
      return finish("running", "running");
    }
  } catch (e) {
    pushLog(id, "[auto] error: " + e.message);
    // a superseded run throwing must not clobber the new run that replaced it
    if (!superseded()) finish("crashed", "needs you");
  }
}

/* ---------------- sandbox: prove 100% launch WITHOUT touching the live app ---------------- */
// sandbox copies must be runtime-faithful: dist/.next/target are compiled output the
// app actually RUNS from — skipping them (as snapshots do) would test a broken app
// and fail triple-checks for perfectly good fixes. only skip what the sandbox
// rebuilds itself (node_modules via hardlink, .venv fresh) or what's never needed
// at runtime (.git history, __pycache__)
const SANDBOX_SKIP = new Set(["node_modules", ".git", "__pycache__", ".venv", "venv"]);
function copyTree(src, dst, skip) {
  fs.mkdirSync(dst, { recursive: true });
  let items;
  try { items = fs.readdirSync(src, { withFileTypes: true }); } catch { return 1; }
  let failures = 0;
  for (const it of items) {
    if (it.name === ".DS_Store" || it.isSymbolicLink()) continue;
    if (skip && skip.has(it.name)) continue;
    const s = path.join(src, it.name), d = path.join(dst, it.name);
    if (it.isDirectory()) failures += copyTree(s, d, skip);
    else if (it.isFile()) { try { fs.copyFileSync(s, d); } catch { failures++; } }
  }
  return failures;
}
/* ---------------- in-place updates: never delete-and-redownload ----------------
   An update applies INCREMENTALLY onto the live tree: only new/changed files are
   copied, files removed upstream are deleted, and installed dependencies plus live
   secrets are NEVER wiped. Every update is verified in the sandbox BEFORE the live
   app is touched — a working app is never replaced by a broken one.
   Patch packages (update.json at the root: {kind:"launchpad-patch", target, files,
   removed}) carry only the changed files, so updates download in KBs, not GBs. */
function fileHashSync(f) {
  try {
    const sum = crypto.createHash("sha1");
    const fd = fs.openSync(f, "r");
    try {
      const buf = Buffer.alloc(65536);
      let n;
      while ((n = fs.readSync(fd, buf, 0, buf.length, null)) > 0) sum.update(buf.subarray(0, n));
    } finally { fs.closeSync(fd); }
    return sum.digest("hex");
  } catch { return null; }
}
// protected: an update may never delete or overwrite these in the live tree
function isProtectedRel(rel) {
  const top = rel.split("/")[0];
  if (HASH_SKIP.has(top)) return true; // node_modules, .venv, dist, ... — refreshed by installers, never by file copy
  if (rel === ".env" || rel.endsWith("/.env")) return true; // live secrets — a shipped .env must not wipe hame's keys
  return false;
}
function stripSymlinksDeep(d) { // zip-planted links can point outside the tree — same threat handleZip guards
  for (const it of fs.readdirSync(d, { withFileTypes: true })) {
    const full = path.join(d, it.name);
    if (it.isSymbolicLink()) { try { fs.unlinkSync(full); } catch {} }
    else if (it.isDirectory()) stripSymlinksDeep(full);
  }
}
// resolve an update source (folder path or .zip path) to a readable root dir.
// folders are used read-only (never touched); zips extract to a temp dir the
// caller must release via the returned cleanup().
function extractUpdate(pkgPath) {
  let st;
  try { st = fs.statSync(pkgPath); } catch { throw new Error("update source not found: " + pkgPath); }
  let root, tmp = null;
  const cleanup = () => { if (tmp) { try { fs.rmSync(tmp, { recursive: true, force: true }); } catch {} } };
  if (st.isFile() && /\.zip$/i.test(pkgPath)) {
    tmp = path.join(os.tmpdir(), "lp-upd-" + process.pid + "-" + Date.now().toString(36));
    fs.mkdirSync(tmp, { recursive: true });
    try { cp.execFileSync("unzip", ["-q", "-o", pkgPath, "-d", tmp]); } // arg array — no shell
    catch (e) { cleanup(); throw new Error("couldn't extract update zip: " + String(e.message || "").split("\n")[0]); }
    stripSymlinksDeep(tmp);
    root = tmp;
  } else if (st.isDirectory()) {
    root = pkgPath;
  } else throw new Error("update source must be a folder or a .zip file");
  // patch packages carry update.json at the root — never wrapper-collapse those
  let patch = null;
  try {
    const m = JSON.parse(fs.readFileSync(path.join(root, "update.json"), "utf8"));
    if (m && m.kind === "launchpad-patch") patch = m;
  } catch {}
  if (!patch) { // zips that wrap everything in one folder: the content root is the inner folder
    const items = fs.readdirSync(root).filter(n => !n.startsWith(".") && !n.startsWith("__MACOSX"));
    if (items.length === 1) {
      const inner = path.join(root, items[0]);
      try { if (fs.statSync(inner).isDirectory()) root = inner; } catch {}
    }
  }
  return { root, patch, cleanup };
}
// copy only what changed from updRoot onto liveDir. returns the diff summary.
function applyTreeUpdate(liveDir, updRoot, patch) {
  const changed = [], added = [], removed = [], skipped = [];
  const updFiles = new Map(); // rel -> abs
  if (patch) {
    for (const rel of Object.keys(patch.files || {})) {
      const clean = String(rel).replace(/^\/+/, "");
      if (!clean || clean.includes("..")) continue;
      updFiles.set(clean, path.join(updRoot, clean));
    }
  } else {
    const walk = (dir, base) => {
      for (const it of fs.readdirSync(dir, { withFileTypes: true })) {
        if (it.name === ".DS_Store" || it.name === ".git" || it.isSymbolicLink()) continue;
        const rel = base ? base + "/" + it.name : it.name;
        const abs = path.join(dir, it.name);
        if (it.isDirectory()) walk(abs, rel);
        else if (it.isFile()) updFiles.set(rel, abs);
      }
    };
    walk(updRoot, "");
  }
  for (const [rel, abs] of updFiles) {
    if (rel === "update.json") continue; // manifest — not app content
    if (isProtectedRel(rel)) { skipped.push(rel); continue; } // check BEFORE hashing — node_modules trees are huge
    let st; try { st = fs.lstatSync(abs); } catch { continue; } // lstat — never follow a symlink out of the package
    if (!st.isFile() || st.isSymbolicLink()) continue;
    const liveF = path.join(liveDir, rel);
    const liveExists = fs.existsSync(liveF);
    if (liveExists && fileHashSync(abs) === fileHashSync(liveF)) continue; // unchanged
    fs.mkdirSync(path.dirname(liveF), { recursive: true });
    fs.copyFileSync(abs, liveF);
    if (patch && patch.files && patch.files[rel] && fileHashSync(liveF) !== patch.files[rel])
      throw new Error("patch file failed verification: " + rel); // corrupt patch must not half-apply
    (liveExists ? changed : added).push(rel);
  }
  // removals: gone upstream. patch → explicit list; full tree → set difference
  const doomed = [];
  if (patch) {
    for (const rel of (patch.removed || [])) {
      const clean = String(rel).replace(/^\/+/, "");
      if (clean && !clean.includes("..")) doomed.push(clean);
    }
  } else {
    const liveFiles = [];
    const walk = (dir, base) => {
      for (const it of fs.readdirSync(dir, { withFileTypes: true })) {
        if (it.name === ".DS_Store" || it.isSymbolicLink()) continue;
        const rel = base ? base + "/" + it.name : it.name;
        if (it.isDirectory()) walk(path.join(dir, it.name), rel);
        else if (it.isFile()) liveFiles.push(rel);
      }
    };
    walk(liveDir, "");
    for (const rel of liveFiles) if (!updFiles.has(rel)) doomed.push(rel);
  }
  for (const rel of doomed) {
    if (isProtectedRel(rel)) { skipped.push(rel + " (kept)"); continue; }
    try { fs.rmSync(path.join(liveDir, rel), { force: true }); removed.push(rel); }
    catch {}
  }
  return { changed, added, removed, skipped };
}
// after an update: refresh deps incrementally when their manifests changed.
// node_modules itself is never wiped — npm only adds/updates what moved.
async function depsRefresh(dir, changed, log) {
  const has = n => changed.some(f => f === n || f.endsWith("/" + n));
  try {
    if ((has("package.json") || has("package-lock.json")) && fs.existsSync(path.join(dir, "package.json"))) {
      log("dependencies changed — refreshing with npm install (incremental, nothing wiped) …");
      await execFile("npm", ["install"], { cwd: dir, timeout: 10 * 60 * 1000 });
      log("npm install done");
    }
  } catch (e) {
    // not fatal: the autopilot's own fixer installs missing modules on launch
    log("npm install had trouble: " + String(e.message).split("\n")[0] + " — files are updated, the launcher will fix deps on start");
  }
}
// full update flow for one app: candidate → checker → sandbox → live apply → relaunch.
// runs in the background; progress goes to the app's log stream.
async function updateApp(id, pkgPath) {
  const p = getProfile(id);
  const log = l => pushLog(id, "[update] " + l);
  if (!p) return;
  if (tripleBusy(id)) { log("triple-check is running — wait for it to finish, then update again"); return; }
  const sbr = runner(id + ":sandbox");
  if (sandboxClaimed.has(id) || sbr.autopilot || sbr.proc) { log("sandbox is running — wait for it to finish, then update again"); return; }
  if (runner(id).autopilot) { log("app is still launching — wait for it to finish, then update again"); return; }
  let upd, cand = null, wasRunning = false;
  try { upd = extractUpdate(pkgPath); }
  catch (e) { log("couldn't read the update package: " + e.message); return; }
  try {
    if (upd.patch && upd.patch.target && upd.patch.target !== "app")
      throw new Error("this patch targets '" + upd.patch.target + "', not an app");
    log("building the updated app in a test copy — the live app is untouched …");
    cand = path.join(DATA_DIR, "sandbox", id + "-update-" + Date.now().toString(36));
    fs.rmSync(cand, { recursive: true, force: true });
    const cf = copyTree(p.path, cand, SANDBOX_SKIP); // node_modules hardlinks in from live at sandbox time
    if (cf) throw new Error("couldn't copy the live app for testing (" + cf + " file(s) failed)");
    const diff = applyTreeUpdate(cand, upd.root, upd.patch);
    const total = diff.changed.length + diff.added.length + diff.removed.length;
    if (!total) { log("already up to date — nothing to change"); return; }
    log(`candidate ready: ${diff.changed.length} changed, ${diff.added.length} added, ${diff.removed.length} removed` +
        (diff.skipped.length ? ` (${diff.skipped.length} protected files kept)` : ""));
    // refresh deps on the CANDIDATE first — if the update adds a dependency, the
    // sandbox must test with it installed, not fail on a missing module the real
    // update would have provided
    await depsRefresh(cand, [...diff.changed, ...diff.added], log);
    const chk = await runChecker(cand, [...diff.changed, ...diff.added].slice(0, 200));
    if (chk.summary && (chk.summary.syntaxFails || chk.summary.capabilityFails)) {
      log(`❌ update REJECTED — the checker found ${chk.summary.syntaxFails} syntax / ${chk.summary.capabilityFails} capability failures. live app untouched.`);
      return;
    }
    log("checker clean — verifying the updated app launches in the sandbox …");
    const sb = await sandboxLaunchCopy(id, "update", cand);
    if (!sb.ok) { log(`❌ update FAILED sandbox (${sb.note}) — live app untouched, nothing was replaced`); return; }
    log(`✅ sandbox passed (${sb.note}) — applying to the live app …`);
    wasRunning = !!(runner(id).proc || runner(id).autopilot); // relaunch on failure — never leave a stopped app behind
    await stopProject(p);
    const snap = takeSnapshot(id);
    log("restore point taken (" + snap + ") — one click brings the old version back");
    const live = applyTreeUpdate(p.path, upd.root, upd.patch);
    await depsRefresh(p.path, [...live.changed, ...live.added], log);
    const m = loadManifest(id) || {};
    saveManifest(id, { ...m, id, storeHash: hashProject(p.path), updatedAt: new Date().toISOString() });
    rememberProject(id, { contentHash: hashProject(p.path) });
    log(`✅ UPDATE APPLIED — ${live.changed.length} changed, ${live.added.length} added, ${live.removed.length} removed. dependencies + secrets were never wiped. relaunching …`);
    setImmediate(() => autopilot(id));
  } catch (e) {
    log("❌ update failed: " + e.message + " — live app untouched");
    if (wasRunning) { log("restarting the app as it was …"); setImmediate(() => autopilot(id)); }
  } finally {
    try { upd.cleanup(); } catch {}
    if (cand) { try { fs.rmSync(cand, { recursive: true, force: true }); } catch {} }
  }
}
/* ---------------- self-update + AUTO-UPDATE: the tool updates ITSELF, in place ----------------
   hame's rule, verbatim: he does nothing, ever. Three ways in:
   - AUTO (the point of all this): the poller reads the feed — a JSON doc at feedUrl,
     published by me: {version, kind:"full"|"patch", url, sha1, notes} — and when a
     newer version exists it downloads, hash-verifies, STAGES, checker-verifies,
     boot-verifies, applies, and supervised-restarts. he never clicks anything.
   - he tells the TOOL: dashboard → "⟳ Update Launchpad" → browse/paste a path or URL.
   - he tells ME: I hand him the package and he drops it in.
   Every path funnels into applySelfUpdatePkg: stage → checker → boot-verify → backup →
   apply → supervised restart with automatic rollback. A bad update can never leave him
   broken: the live tree is only touched after the new code proves it runs, and if the
   restarted server doesn't come up the backup is swapped back into place. */
const selfState = { phase: "idle", note: "", version: distVersion() };
const autoState = { busy: false, lastCheck: null, lastResult: "never checked" };
function downloadFile(u, dest) {
  return new Promise((resolve, reject) => {
    // cache-buster: same GitHub CDN issue as the feed — stale packages fail SHA checks
    try { if (u instanceof URL) u.searchParams.set("_t", String(Date.now())); } catch {}
    const mod = u.protocol === "https:" ? require("https") : require("http");
    const req = mod.get(u, { timeout: 60000 }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
        return downloadFile(new URL(res.headers.location, u), dest).then(resolve, reject); // one redirect hop
      if (res.statusCode !== 200) { res.resume(); return reject(new Error("download failed: HTTP " + res.statusCode)); }
      const ws = fs.createWriteStream(dest);
      res.pipe(ws);
      ws.on("finish", () => ws.close(resolve));
      ws.on("error", reject);
    });
    req.on("error", reject);
    req.on("timeout", () => { req.destroy(); reject(new Error("download timed out")); });
  });
}
/* ---------- auto-update settings + state (brain.settings.autoUpdate) ---------- */
// Built-in update feed — hame never configures this. Set at build time.
const DEFAULT_FEED_URL = "https://raw.githubusercontent.com/hame-launchpad/launchpad-updates/main/feed.json";
function autoSettings() {
  let s = {};
  try { const b = loadBrain(); if (b.settings && typeof b.settings.autoUpdate === "object") s = b.settings.autoUpdate; } catch {}
  if (!s || typeof s !== "object" || Array.isArray(s)) s = {};
  const cfgUrl = typeof s.feedUrl === "string" ? s.feedUrl.trim() : "";
  return {
    feedUrl: cfgUrl || (DEFAULT_FEED_URL.startsWith("http") ? DEFAULT_FEED_URL : ""),
    enabled: s.enabled !== false, // on by default — a launcher that can't update itself is the old failure
    intervalHrs: Math.min(72, Math.max(1, Number(s.intervalHrs) || 6)),
  };
}
function saveAutoSettings(patch) {
  const b = loadBrain();
  if (!b.settings || typeof b.settings !== "object" || Array.isArray(b.settings)) b.settings = {};
  const cur = b.settings.autoUpdate;
  const next = (cur && typeof cur === "object" && !Array.isArray(cur)) ? { ...cur } : {};
  if (patch.feedUrl !== undefined) next.feedUrl = String(patch.feedUrl || "").trim();
  if (patch.enabled !== undefined) next.enabled = !!patch.enabled;
  if (patch.intervalHrs !== undefined) next.intervalHrs = Math.min(72, Math.max(1, Number(patch.intervalHrs) || 6));
  b.settings.autoUpdate = next;
  saveBrain(b);
  return autoSettings();
}
function getBadVersions() {
  try {
    const b = loadBrain();
    const arr = b && b.autoUpdate && b.autoUpdate.badVersions;
    return Array.isArray(arr) ? arr.filter(v => typeof v === "string") : [];
  } catch { return []; }
}
// a version that applied but then failed to start gets marked: the updater will
// never auto-retry it (no flap loop). a manual check can still retry it, and a
// version that boots fine clears its own mark.
function markBadVersion(v) {
  try {
    const b = loadBrain();
    if (!b.autoUpdate || typeof b.autoUpdate !== "object" || Array.isArray(b.autoUpdate)) b.autoUpdate = {};
    const arr = Array.isArray(b.autoUpdate.badVersions) ? b.autoUpdate.badVersions.filter(x => typeof x === "string") : [];
    if (v && !arr.includes(v)) arr.push(v);
    b.autoUpdate.badVersions = arr.slice(-20);
    saveBrain(b);
  } catch {}
}
function clearBadVersion(v) {
  try {
    const b = loadBrain();
    if (b && b.autoUpdate && Array.isArray(b.autoUpdate.badVersions) && v) {
      b.autoUpdate.badVersions = b.autoUpdate.badVersions.filter(x => x !== v);
      saveBrain(b);
    }
  } catch {}
}
function recordAutoResult(text) {
  autoState.lastCheck = new Date().toISOString();
  autoState.lastResult = String(text).slice(0, 300);
  try {
    const b = loadBrain();
    const prevBad = (b.autoUpdate && Array.isArray(b.autoUpdate.badVersions)) ? b.autoUpdate.badVersions : [];
    b.autoUpdate = { lastCheck: autoState.lastCheck, lastResult: autoState.lastResult, badVersions: prevBad };
    saveBrain(b);
  } catch {}
  console.log("[launchpad] auto-update: " + autoState.lastResult);
}
function loopbackOk(u) { return /^(127\.0\.0\.1|localhost|\[::1\])$/.test(u.hostname); }
function fetchJsonFeed(feedUrl) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(String(feedUrl)); } catch { return reject(new Error("bad feed URL")); }
    // cache-buster: GitHub raw CDN caches aggressively; without this new
    // versions can take minutes to appear and the updater sees stale data
    u.searchParams.set("_t", String(Date.now()));
    // https everywhere; http only for loopback (local testing) — never for a real feed
    if (u.protocol !== "https:" && !(u.protocol === "http:" && loopbackOk(u)))
      return reject(new Error("feed must be https"));
    const mod = u.protocol === "https:" ? require("https") : require("http");
    const req = mod.get(u, { timeout: 20000 }, res => {
      if (res.statusCode !== 200) { res.resume(); return reject(new Error("feed HTTP " + res.statusCode)); }
      let body = "";
      res.on("data", c => { body += c; if (body.length > 65536) { req.destroy(); reject(new Error("feed too large")); } });
      res.on("end", () => {
        try {
          const f = JSON.parse(body);
          if (!f || typeof f !== "object" || Array.isArray(f)) throw 0;
          resolve(f);
        } catch { reject(new Error("feed is not valid JSON")); }
      });
    });
    req.on("error", e => reject(new Error("feed unreachable: " + (e.message || e))));
    req.on("timeout", () => { req.destroy(); reject(new Error("feed timed out")); });
  });
}
function httpGetJson(urlStr, timeoutMs) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(urlStr); } catch { return reject(new Error("bad url")); }
    const mod = u.protocol === "https:" ? require("https") : require("http");
    const req = mod.get(u, { timeout: timeoutMs || 5000 }, res => {
      if (res.statusCode !== 200) { res.resume(); return reject(new Error("HTTP " + res.statusCode)); }
      let body = "";
      res.on("data", c => { body += c; });
      res.on("end", () => { try { resolve(JSON.parse(body)); } catch { reject(new Error("bad JSON")); } });
    });
    req.on("error", reject);
    req.on("timeout", () => { req.destroy(); reject(new Error("timeout")); });
  });
}
async function waitForVersion(port, version, ms) {
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
    try {
      const b = await httpGetJson("http://127.0.0.1:" + port + "/api/brain", 4000);
      if (b && b.lpVersion === version) return true;
    } catch {}
    await new Promise(r => setTimeout(r, 750));
  }
  return false;
}
async function waitPortFree(port, ms) {
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
    const free = await new Promise(res => {
      const s = net.createConnection({ host: "127.0.0.1", port }, () => { s.destroy(); res(false); });
      s.on("error", () => res(true));
      setTimeout(() => { try { s.destroy(); } catch {} res(true); }, 1500);
    });
    if (free) return true;
    await new Promise(r => setTimeout(r, 500));
  }
  return false;
}
/* ---------- staged verification: the new code must PROVE it runs before the live tree is touched ---------- */
function stagedVersion(dir) {
  try {
    const v = String(JSON.parse(fs.readFileSync(path.join(dir, ".launchpad-dist"), "utf8")).version || "");
    if (!v) throw 0;
    return v;
  } catch { throw new Error("package has no readable .launchpad-dist version — refusing"); }
}
async function verifyStagedTree(stagedDir, nv) {
  if (!fs.existsSync(path.join(stagedDir, "server.js")))
    throw new Error("staged tree has no server.js — refusing");
  const sv = stagedVersion(stagedDir);
  if (sv !== nv) throw new Error("staged tree is v" + sv + ", expected v" + nv + " — refusing");
  let meta = {};
  try { meta = JSON.parse(fs.readFileSync(path.join(stagedDir, ".launchpad-dist"), "utf8")); } catch {}
  if (meta.target && meta.target !== "launchpad")
    throw new Error("staged tree targets '" + meta.target + "' — refusing");
  // the LIVE checker vets the new tree — never let the new tree's own checker pass itself
  const rep = await runChecker(stagedDir);
  if (rep.inconclusive) throw new Error("staged checker was inconclusive — refusing an unverified update");
  const fails = (rep.summary.syntaxFails || 0) + (rep.summary.capabilityFails || 0);
  if (fails > 0) throw new Error("staged checker found " + fails + " failure(s) — refusing");
  // the new code must BOOT and report the new version — temp port, temp HOME, live untouched
  const port = await getFreePort();
  const tmpHome = fs.mkdtempSync(path.join(os.tmpdir(), "lp-stage-home-"));
  const child = cp.spawn(process.execPath, [path.join(stagedDir, "server.js")], {
    cwd: stagedDir, stdio: "ignore",
    env: { ...process.env, HOME: tmpHome, LAUNCHPAD_PORT: String(port) },
  });
  try {
    const deadline = Date.now() + 25000;
    while (Date.now() < deadline) {
      if (child.exitCode !== null && child.exitCode !== undefined)
        throw new Error("staged server died on boot (exit " + child.exitCode + ") — refusing");
      try {
        const b = await httpGetJson("http://127.0.0.1:" + port + "/api/brain", 4000);
        if (b && b.lpVersion === nv) return true; // the new code proves it runs
      } catch {}
      await new Promise(r => setTimeout(r, 750));
    }
    throw new Error("staged server never reported v" + nv + " — refusing");
  } finally {
    try { child.kill("SIGKILL"); } catch {}
    try { fs.rmSync(tmpHome, { recursive: true, force: true }); } catch {}
  }
}
/* ---------- supervised restart: the old process watches the new one come up, rolls back on failure ---------- */
async function supervisedRestart(expectedVersion, bakDir, oldVersion) {
  selfState.phase = "restarting";
  selfState.note = "restarting into v" + expectedVersion + " …";
  const spawnServer = () => {
    const c = cp.spawn(process.execPath, [path.join(APP_DIR, "server.js")], {
      cwd: APP_DIR, detached: true, stdio: "ignore",
      env: { ...process.env, LAUNCHPAD_PORT: String(PORT) },
    });
    c.unref();
    return c;
  };
  try {
    // stop accepting and free the port — lingering dashboard polls are destroyed,
    // otherwise close() would wait on them and the new server could never bind
    await new Promise(res => { try { server.close(res); } catch { res(); } setTimeout(res, 2500); });
    for (const s of Array.from(openSockets)) { try { s.destroy(); } catch {} }
    await waitPortFree(PORT, 8000);
    const child = spawnServer();
    if (await waitForVersion(PORT, expectedVersion, 30000)) process.exit(0); // the new server owns the port now
    try { child.kill("SIGKILL"); } catch {}
    await waitPortFree(PORT, 10000);
    // ROLLBACK: atomic renames swap the backup back into place — no half-state on disk
    const badDir = APP_DIR + ".bad-" + Date.now().toString(36);
    fs.renameSync(APP_DIR, badDir);
    fs.renameSync(bakDir, APP_DIR);
    const rb = spawnServer(); // APP_DIR now points at the backup — this relaunches the OLD code
    const back = await waitForVersion(PORT, oldVersion, 20000);
    try { fs.rmSync(badDir, { recursive: true, force: true }); } catch {}
    if (back) {
      markBadVersion(expectedVersion); // never auto-retry a version that died on start
      recordAutoResult("v" + expectedVersion + " failed to start — rolled back to v" + oldVersion + " (won't be retried automatically)");
      process.exit(0);
    }
    // total failure: the rollback didn't come up either. if something is already
    // serving on the port (e.g. the restored server reporting an unexpected version),
    // leave it alone — fighting over the port crashes this process. only re-listen
    // from memory when the port is actually free, so he is never left dark.
    if (await waitPortFree(PORT, 3000)) {
      recordAutoResult("CRITICAL: v" + expectedVersion + " failed and rollback failed — serving v" + oldVersion + " from memory");
      server.on("error", () => {});
      server.listen(PORT, "127.0.0.1", () => console.log("[launchpad] re-listening old code after failed update"));
    } else {
      recordAutoResult("CRITICAL: v" + expectedVersion + " failed; port held by another server — leaving it alone, check the install");
      process.exit(0);
    }
  } catch (e) {
    try { recordAutoResult("restart failed: " + (e.message || e)); } catch {}
  }
}
/* ---------- the one funnel: every self-update path verifies, backs up, applies; the restart is supervised ---------- */
async function applySelfUpdatePkg(pkgPath, via, feedNv) {
  if (selfState.phase === "applying" || selfState.phase === "restarting")
    throw new Error("an update is already in progress");
  selfState.phase = "applying"; selfState.note = "reading the update package …";
  const prevV = distVersion(); // captured BEFORE anything is applied — the rollback target
  const upd = extractUpdate(pkgPath);
  let stagedTmp = null;
  try {
    let staged, nv;
    if (upd.patch) {
      if (upd.patch.target && upd.patch.target !== "launchpad")
        throw new Error("patch targets '" + upd.patch.target + "', not Launchpad — refusing");
      stagedTmp = fs.mkdtempSync(path.join(os.tmpdir(), "lp-stage-"));
      if (copyTree(APP_DIR, stagedTmp, null)) throw new Error("staging copy incomplete — refusing");
      applyTreeUpdate(stagedTmp, upd.root, upd.patch); // throws on hash mismatch
      staged = stagedTmp;
      nv = stagedVersion(staged);
    } else {
      if (!fs.existsSync(path.join(upd.root, "server.js")) ||
          !fs.existsSync(path.join(upd.root, ".launchpad-dist")))
        throw new Error("not a Launchpad package (missing server.js / .launchpad-dist) — refusing");
      staged = upd.root;
      nv = stagedVersion(staged);
    }
    if (feedNv && nv !== feedNv)
      throw new Error("feed says v" + feedNv + " but the package is v" + nv + " — refusing");
    if (compareVersions(nv, distVersion()) <= 0)
      throw new Error("already on v" + distVersion() + " — refusing v" + nv);
    selfState.note = "verifying v" + nv + " …";
    await verifyStagedTree(staged, nv); // checker + test boot — throws on ANY failure, live untouched
    // backup the live install, keep the last 3
    selfState.note = "backing up the current install …";
    const bak = path.join(DATA_DIR, "self-backup", Date.now().toString(36));
    fs.mkdirSync(bak, { recursive: true });
    if (copyTree(APP_DIR, bak, null)) throw new Error("backup incomplete — refusing to apply");
    try {
      const bs = fs.readdirSync(path.join(DATA_DIR, "self-backup")).sort();
      while (bs.length > 3) fs.rmSync(path.join(DATA_DIR, "self-backup", bs.shift()), { recursive: true, force: true });
    } catch {}
    // apply incrementally — changed/new files only, protected paths never wiped
    selfState.note = "applying v" + nv + " …";
    const r = applyTreeUpdate(APP_DIR, upd.root, upd.patch);
    selfState.version = nv;
    // stop running apps, remember them for relaunch after the restart
    const running = [];
    for (const p of loadProfiles()) { const rn = runner(p.id); if (rn.proc || rn.autopilot) running.push(p.id); }
    for (const pid of running) { try { await stopProject(getProfile(pid) || { id: pid }); } catch {} }
    if (running.length)
      fs.writeFileSync(path.join(DATA_DIR, "restart-after-update.json"), JSON.stringify(running));
    const summary = r.changed.length + " changed, " + r.added.length + " added, " + r.removed.length + " removed";
    recordAutoResult((via === "auto" ? "auto-update" : "manual update") + " to v" + nv +
      " applied (" + summary + ") — restarting …");
    return { bakDir: bak, nv, summary, prevV };
  } catch (e) {
    // a failed update must never wedge the updater — reset the phase so the next
    // check (auto or manual) can run. without this, one refusal bricks updating forever.
    selfState.phase = "failed"; selfState.note = e.message;
    throw e;
  } finally {
    try { upd.cleanup(); } catch {}
    if (stagedTmp) { try { fs.rmSync(stagedTmp, { recursive: true, force: true }); } catch {} }
  }
}
async function selfUpdate(src) {
  let tmpDl = null;
  try {
    let pkgPath = src.path;
    if (src.url) {
      const u = new URL(String(src.url));
      if (!/^https?:$/.test(u.protocol)) throw new Error("only http(s) URLs are accepted");
      tmpDl = path.join(os.tmpdir(), "lp-self-" + Date.now().toString(36) + ".zip");
      selfState.note = "downloading the update …";
      await downloadFile(u, tmpDl);
      pkgPath = tmpDl;
    }
    if (!pkgPath) throw new Error("no package given");
    const r = await applySelfUpdatePkg(pkgPath, "manual"); // verify+backup+apply; throws on any problem
    selfState.phase = "restarting";
    selfState.note = "restarting into v" + r.nv + " …";
    // respond FIRST (the endpoint sends the result), restart after — the dashboard reconnects on its own
    setImmediate(() => supervisedRestart(r.nv, r.bakDir, r.prevV).catch(e => {
      try { recordAutoResult("restart failed: " + (e.message || e)); } catch {}
    }));
    return { ok: true, restarted: true, version: r.nv, summary: r.summary };
  } catch (e) {
    selfState.phase = "failed"; selfState.note = e.message;
    return { ok: false, error: e.message };
  } finally {
    if (tmpDl) { try { fs.unlinkSync(tmpDl); } catch {} }
  }
}
/* ---------- the poller: he does nothing, the tool checks the feed and installs fixes itself ---------- */
async function autoUpdateTick(manual) {
  if (autoState.busy)
    return { ok: false, error: manual ? "a check is already running" : "skipped: busy" };
  const s = autoSettings();
  if (!s.feedUrl) {
    if (manual) return { ok: false, error: "no feed URL set — open the auto-update settings and paste the feed URL" };
    return { ok: false, skipped: true };
  }
  if (!manual && !s.enabled) return { ok: false, skipped: true };
  autoState.busy = true;
  let tmpPkg = null;
  try {
    recordAutoResult("checking the update feed …");
    const f = await fetchJsonFeed(s.feedUrl);
    const nv = String(f.version || "").trim();
    const purl = String(f.url || "").trim();
    const sha1 = String(f.sha1 || "").trim().toLowerCase();
    if (!nv) throw new Error("the feed has no version");
    if (!/^https:\/\//.test(purl) && !(purl.startsWith("http://127.0.0.1") || purl.startsWith("http://localhost")))
      throw new Error("the feed's package URL must be https");
    if (!/^[0-9a-f]{40}$/.test(sha1)) throw new Error("the feed has no valid sha1 for the package");
    if (compareVersions(nv, distVersion()) <= 0) {
      recordAutoResult("up to date (v" + distVersion() + ")");
      return { ok: true, upToDate: true, version: distVersion() };
    }
    if (!manual && getBadVersions().includes(nv)) {
      recordAutoResult("v" + nv + " failed to start last time — skipping it automatically (retry it manually if the coast is clear)");
      return { ok: true, skipped: true, version: nv, reason: "bad-version" };
    }
    recordAutoResult("v" + nv + " found — downloading …");
    tmpPkg = path.join(os.tmpdir(), "lp-auto-" + Date.now().toString(36) + ".zip");
    await downloadFile(new URL(purl), tmpPkg);
    if ((fileHashSync(tmpPkg) || "").toLowerCase() !== sha1)
      throw new Error("downloaded package failed its hash check — refusing a corrupt download");
    recordAutoResult("v" + nv + " downloaded — verifying …");
    const r = await applySelfUpdatePkg(tmpPkg, "auto", nv);
    setImmediate(() => supervisedRestart(r.nv, r.bakDir, r.prevV).catch(e => {
      try { recordAutoResult("restart failed: " + (e.message || e)); } catch {}
    }));
    return { ok: true, updating: true, version: r.nv };
  } catch (e) {
    recordAutoResult("failed: " + (e.message || e));
    return { ok: false, error: e.message || String(e) };
  } finally {
    autoState.busy = false;
    if (tmpPkg) { try { fs.unlinkSync(tmpPkg); } catch {} }
  }
}
/* ---- app file store: every app's files live INSIDE the tool, organized by app ----
   ~/.launchpad/apps/<id>/ is the canonical home for an app's files. the user's
   original folder is never touched after ingest — nothing the tool runs, edits
   or fixes can mess it up, and if the original goes missing the tool still has
   everything. */
function storeDir(id) { return path.join(DATA_DIR, "apps", id); }
function manifestFile(id) { return path.join(DATA_DIR, "manifests", id + ".json"); }
function loadManifest(id) {
  try { return JSON.parse(fs.readFileSync(manifestFile(id), "utf8")); }
  catch {
    // quarantine corrupt manifests like profiles/brain — a silent null here would
    // make syncStoreFromOrigin re-ingest apps that never changed
    try {
      const f = manifestFile(id);
      if (fs.existsSync(f) && fs.statSync(f).size > 0) {
        const bak = f + ".corrupt-" + Date.now();
        fs.renameSync(f, bak);
        console.error("[launchpad] manifest " + id + " was corrupt — quarantined to " + bak);
      }
    } catch {}
    return null;
  }
}
function saveManifest(id, m) {
  try { fs.mkdirSync(path.dirname(manifestFile(id)), { recursive: true }); atomicWrite(manifestFile(id), JSON.stringify(m, null, 1)); } catch {}
}
// ingest: copy the app's files into the tool's own organized store
function ingestApp(id, srcDir, origin) {
  // read the source FIRST — if it vanishes, the stored copy must stay intact
  let items;
  try { items = fs.readdirSync(srcDir, { withFileTypes: true }); }
  catch (e) { throw new Error("can't read source folder: " + e.message); }
  const dst = storeDir(id);
  const tmp = dst + ".ingest-" + process.pid;
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.mkdirSync(tmp, { recursive: true });
  // copy everything except .git (regenerable, often huge) — node_modules IS kept:
  // the store must be runnable even if the origin disappears
  let copyFails = 0;
  for (const it of items) {
    if (it.name === ".git" || it.name === ".DS_Store") continue;
    const s = path.join(srcDir, it.name), d = path.join(tmp, it.name);
    if (it.isDirectory()) copyFails += copyTree(s, d, null);
    else if (it.isFile()) { try { fs.copyFileSync(s, d); } catch { copyFails++; } }
  }
  if (copyFails) { fs.rmSync(tmp, { recursive: true, force: true }); throw new Error(`ingest incomplete — ${copyFails} file(s) failed to copy`); }
  fs.rmSync(dst, { recursive: true, force: true });
  fs.renameSync(tmp, dst); // atomic swap — the store is never half-written
  const m = { id, origin: origin || null, ingestedAt: new Date().toISOString(),
              originHash: origin && fs.existsSync(origin) ? hashProject(origin) : null, // hashProject hashes files too (zip origins)
              storeHash: hashProject(dst) };
  saveManifest(id, m);
  return dst;
}
// before launch: if the origin folder changed and the tool hasn't modified the
// stored copy since ingest, pull the fresh files in automatically — no manual step
function syncStoreFromOrigin(p, log) {
  // defense in depth: even if a future caller forgets the route guard, a live launch
  // must never swap files under a running triple-check (sandbox checks skip the sync)
  if (tripleBusy(p.id)) { log("triple-check in progress — skipping origin sync"); return; }
  // same for a manual sandbox: sandboxLaunchCopy reads p.path for seconds (copyTree +
  // node_modules hardlink) — wiping/swapping the store mid-copy tears it
  const sbr = runner(p.id + ":sandbox");
  if (sandboxClaimed.has(p.id) || sbr.autopilot || sbr.proc) { log("sandbox in flight — skipping origin sync until it finishes"); return; }
  const m = loadManifest(p.id);
  if (!m || !m.origin) return;
  if (!fs.existsSync(m.origin)) { log("origin folder gone (" + m.origin + ") — running from the tool's stored copy, nothing lost"); return; }
  let oh = null;
  try { oh = hashProject(m.origin); } catch {}
  if (!oh) return; // origin unreadable — can't compare, leave the stored copy alone
  if (oh === m.originHash) return; // origin unchanged
  if (m.originHash == null) {
    // never recorded — the store was just built from this origin, so record instead of re-ingesting
    saveManifest(p.id, { ...m, originHash: oh });
    return;
  }
  let sh = null;
  try { sh = hashProject(p.path); } catch {} // canonical app root — right even for zip wrapper-dir layouts
  if (sh !== m.storeHash) { log("both origin and the stored copy changed — keeping the tool's tested version"); return; }
  log("origin changed — pulling fresh files into the tool's store (in place, nothing wiped)");
  try {
    const upd = extractUpdate(m.origin); // folders read directly, zips to temp — origin never touched
    try {
      const r = applyTreeUpdate(p.path, upd.root, upd.patch);
      log(`origin sync: ${r.changed.length} changed, ${r.added.length} added, ${r.removed.length} removed` +
          (r.skipped.length ? ` (${r.skipped.length} protected files kept)` : ""));
    } finally { upd.cleanup(); }
    saveManifest(p.id, { id: p.id, origin: m.origin, ingestedAt: new Date().toISOString(),
      originHash: oh, storeHash: hashProject(p.path) }); // fresh hashes — or we'd re-sync every launch
    const ps = loadProfiles().map(x => x.id === p.id ? { ...x, path: p.path } : x);
    saveProfiles(ps);
  } catch (e) { log("origin sync failed — keeping the stored copy: " + e.message); }
}
// one-time adoption: profiles created before the store existed get ingested
function adoptUnstoredProfiles() {
  for (const p of loadProfiles()) {
    if (p.path === storeDir(p.id) || loadManifest(p.id)) continue;
    if (!fs.existsSync(p.path)) continue;
    try {
      if (fs.statSync(p.path).isDirectory()) {
        p.origin = p.path;
        p.path = ingestApp(p.id, p.origin, p.origin);
      } else if (/\.zip$/i.test(p.path)) {
        p.origin = p.path;
        p.path = handleZip(p.path, p.id);
        saveManifest(p.id, { id: p.id, origin: p.origin, ingestedAt: new Date().toISOString(), originHash: hashProject(p.origin), storeHash: hashProject(p.path) });
      } else continue;
      p.stored = true;
      const ps = loadProfiles().map(x => x.id === p.id ? p : x);
      saveProfiles(ps);
      console.log("[launchpad] adopted profile into store:", p.name);
    } catch (e) { console.log("[launchpad] couldn't adopt", p.name, e.message); }
  }
}
function getFreePort() {
  return new Promise(resolve => {
    const s = net.createServer();
    s.listen(0, "127.0.0.1", () => { const p = s.address().port; s.close(() => resolve(p)); });
    s.on("error", () => resolve(18080 + Math.floor(Math.random() * 4000)));
  });
}
/* snapshot the live app, launch an isolated copy, demand a full ready.
   the live app keeps running the whole time — you never stand still. */
function takeSnapshot(id) {
  const p = getProfile(id);
  if (!p) return null;
  const snapBase = path.join(DATA_DIR, "snapshots", id);
  // unique name: two snapshots in the same millisecond must never merge
  const snapDir = path.join(snapBase, Date.now() + "-" + Math.random().toString(36).slice(2, 8));
  const copyFails = copyTree(p.path, snapDir, HASH_SKIP);
  if (copyFails) pushLog(id, `[launchpad] snapshot warning: ${copyFails} file(s) failed to copy`);
  try { // keep the last 3 snapshots
    const snaps = fs.readdirSync(snapBase).sort();
    while (snaps.length > 3) {
      const old = snaps.shift();
      fs.rmSync(path.join(snapBase, old), { recursive: true, force: true });
    }
  } catch {}
  return path.basename(snapDir);
}
function latestSnapshot(id) {
  try {
    const snaps = fs.readdirSync(path.join(DATA_DIR, "snapshots", id)).sort();
    return snaps.length ? snaps[snaps.length - 1] : null;
  } catch { return null; }
}
/* isolated launch core: copy the live app, launch the copy on a free port,
   wait for ready, stop it, clean up. the live app is never touched.
   srcDir override: update verification tests a CANDIDATE tree instead of the live app. */
async function sandboxLaunchCopy(id, tag, srcDir) {
  const p = getProfile(id);
  if (!p) return { ok: false, note: "no such project" };
  const sbId = id + ":sandbox";
  const sbr = runner(sbId);
  if (sbr.autopilot || sbr.proc) return { ok: false, note: "sandbox already running" };
  sbr.autopilot = true; // claim synchronously
  const log = l => pushLog(id, "[" + (tag || "sandbox") + "] " + l);
  const sbDir = path.join(DATA_DIR, "sandbox", id);
  try {
    fs.rmSync(sbDir, { recursive: true, force: true });
    const src = srcDir || p.path; // update checks test the candidate tree, not the live app
    const copyFails = copyTree(src, sbDir, SANDBOX_SKIP);
    if (copyFails) return { ok: false, note: `sandbox copy incomplete (${copyFails} file(s) failed to copy)` };
    const nmLive = path.join(p.path, "node_modules");
    if (fs.existsSync(nmLive) && !fs.existsSync(path.join(sbDir, "node_modules"))) {
      // hardlink copy: as fast as a symlink, but sandbox writes can NEVER reach
      // the live app's dependencies (a symlink would write straight through)
      try { await execFile("cp", ["-al", nmLive, path.join(sbDir, "node_modules")], { timeout: 60000 }); }
      catch { log("note: couldn't hardlink node_modules — sandbox will npm install fresh"); }
    }
    // python isolation: the live app imports from system site-packages — a sandbox
    // `pip install` would upgrade/downgrade the LIVE app's dependencies. the sandbox
    // gets its own venv (.venv is in HASH_SKIP, so snapshots/diffs ignore it)
    let venvBin = null;
    try {
      const sbScan = scanProject(sbDir);
      if (sbScan.ok && sbScan.stack === "python" && fs.existsSync(path.join(sbDir, "requirements.txt"))) {
        const venvDir = path.join(sbDir, ".venv");
        log("sandbox python: creating isolated venv ...");
        await execFile("python3", ["-m", "venv", venvDir], { timeout: 180000 });
        venvBin = path.join(venvDir, "bin");
        log("sandbox python: isolated venv ready — system packages untouched");
      }
    } catch (e) {
      return { ok: false, note: "couldn't create an isolated python venv (" + String(e.message).split("\n")[0] + ") — refusing to share system packages with the live app" };
    }
    const freePort = await getFreePort();
    // the live app's port, from memory or from what it's actually serving right now —
    // a hardcoded-port app ignores our injected PORT, so we must recognize that collision
    let livePort = (loadBrain().projects[id] || {}).lastPort || null;
    const liveUrl = runner(id).appUrl;
    if (!livePort && liveUrl) { const lm = liveUrl.match(/:(\d+)$/); if (lm) livePort = lm[1]; }
    const sp = { id: sbId, name: p.name + " (sandbox)", path: sbDir,
                 command: p.command && p.command !== "auto" ? p.command : "auto",
                 env: { ...(p.env || {}), PORT: String(freePort), LAUNCHPAD_SANDBOX: "1",
                        // venv first on PATH so `python`/`pip` resolve inside the sandbox venv
                        ...(venvBin ? { PATH: venvBin + path.delimiter + process.env.PATH,
                                        VIRTUAL_ENV: path.join(sbDir, ".venv") } : {}) } };
    log(`launching isolated copy on port ${freePort} — live app untouched${livePort ? " (live is on " + livePort + ")" : ""} ...`);
    await autopilotRun(sp, { sandbox: true, livePort });
    const r2 = runner(sbId);
    // autopilotRun's verdict IS the verdict: "ready" (HTTP port found), "running"
    // (alive 35s with no detectable port — called good), or "exited" (script ran
    // clean). demanding r.ready alone false-failed every app that doesn't print its
    // port — and the triple-check then unjustly punished the rule for it.
    const ok = r2.ready === true || r2.status === "running" || r2.phase === "exited";
    // inconclusive, not failure: the app hardcodes its port, so the sandbox copy
    // collided with the LIVE app. punishing a rule for this would be unjust.
    const diedOnLivePort = livePort && (r2.lastDiag || [])
      .some(d => d.rule === "eaddrinuse" && String(d.fix && d.fix.arg) === String(livePort));
    if (!ok && diedOnLivePort)
      return { ok: false, inconclusive: true,
               note: "sandbox couldn't bind: the LIVE app holds this hardcoded port — test inconclusive, not a failure" };
    const note = ok ? ("sandbox ok" + (r2.appUrl ? " — ready " + r2.appUrl : " (" + (r2.phase || r2.status) + ")"))
                      : ("failed: " + (r2.phase || r2.status));
    return { ok, note };
  } catch (e) {
    log((tag || "sandbox") + " error: " + e.message);
    return { ok: false, note: e.message };
  } finally {
    try { await stopProject({ id: sbId }); } catch {} // the old sandbox process must be fully dead before the dir is reused
    try { fs.rmSync(sbDir, { recursive: true, force: true }); } catch {}
    runner(sbId).autopilot = false; // release the claim
  }
}
async function sandboxTest(id) {
  const p = getProfile(id);
  if (!p) return { ok: false, error: "no such project" };
  const log = l => pushLog(id, "[sandbox] " + l);
  // never snapshot/copy while the live app is mid-launch — npm/pip/preflight writes
  // would race the copy and a half-written package-lock could become a "restore point"
  if (runner(id).autopilot) { log("app is still launching — wait for it to finish"); return { ok: false, error: "app is still launching — wait for it to finish" }; }
  log("snapshotting live app (restore point) ...");
  takeSnapshot(id);
  const r = await sandboxLaunchCopy(id, "sandbox");
  // the project may have been deleted mid-sandbox — don't resurrect brain state for it
  if (getProfile(id)) rememberProject(id, { lastSandbox: { at: new Date().toISOString(), ok: r.ok, inconclusive: !!r.inconclusive, note: r.note } });
  else log("project was deleted mid-sandbox — not recording results");
  log(r.ok ? `✅ SANDBOX PASSED — full launch, ${r.note}. safe to go live.`
           : r.inconclusive ? `❓ SANDBOX INCONCLUSIVE (${r.note}) — live app untouched, no verdict.`
           : `❌ SANDBOX FAILED (${r.note}) — live app untouched, use restore if you edited it.`);
  return r;
}
/* run the custom syntax + capability checker (tools/check.js) on a directory.
   async — the checker can take up to 60s on a big app; blocking the event loop
   that long would freeze the dashboard, SSE logs, and every other route */
async function runChecker(dir, files) {
  // async: the checker can take up to 60s on a big app — execFileSync here used to
  // freeze the whole server (dashboards, SSE, every app's log stream). maxBuffer is
  // raised so a huge report can't throw ERR_CHILD_PROCESS_STDIO_MAXBUFFER and
  // fabricate a phantom syntax failure that would unjustly punish a rule.
  try {
    const out = await execFile("node", [path.join(__dirname, "tools", "check.js"), dir, ...(files || [])],
      { timeout: 60000, maxBuffer: 16 * 1024 * 1024 });
    return JSON.parse(String(out.stdout));
  } catch (e) {
    const so = ((e.stdout || "")).toString();
    try { return JSON.parse(so); }
    catch {
      // the CHECKER itself crashed or timed out (huge apps can exceed the 60s
      // budget) — that is not a syntax failure in the app. reporting syntaxFails:1
      // here would false-fail the triple-check and unjustly punish the rule
      // (at -4 it gets quarantined as "punished out of trust"). inconclusive instead.
      return { dir, files: [], summary: { files: 0, syntaxFails: 0, capabilityFails: 0 },
               inconclusive: true, error: e.message };
    }
  }
}
/* TRIPLE-CHECK: a fix or change isn't trusted until it passes three times.
   each run: (1) syntax + capability checker clean, (2) isolated copy launches to ready.
   after:    (3) diff vs pre-change snapshot — nothing outside `scope` may have changed.
   pass → the rule is REWARDED. fail → the rule is PUNISHED (+ snapshot restored if asked). */
const tripleRunning = new Set(); // per-app: one triple-check per app at a time
function tripleBusy(id) { return tripleRunning.has(id); }
// route-level sandbox claim: two rapid POSTs in the same tick both see
// sbr.autopilot===false, so the guard below can't stop the second one. this set is
// claimed SYNCHRONOUSLY in the route (sandboxLaunchCopy's own guard still does the
// real claim later — we must NOT set sbr.autopilot here, that wedged the button).
const sandboxClaimed = new Set();
// claim the slot SYNCHRONOUSLY at the call site — tripleCheck itself is deferred via
// setImmediate, so checking-then-claiming inside it would let two rapid callers
// both start (the second gets "started:true" while its check silently bails)
function claimTriple(id) { if (tripleRunning.has(id)) return false; tripleRunning.add(id); return true; }
async function tripleCheck(id, opts) {
  opts = opts || {};
  if (!tripleRunning.has(id)) tripleRunning.add(id); // defensive — callers claim first via claimTriple()
  try {
    const p = getProfile(id);
    if (!p) return { ok: false, error: "no such project" };
    const log = l => pushLog(id, "[3x] " + l);
    const snapBefore = latestSnapshot(id);
    const results = [];
    for (let run = 1; run <= 3; run++) {
      const r = { run };
      const chk = await runChecker(p.path);
      r.checkerFails = chk.summary.syntaxFails + chk.summary.capabilityFails;
      // a checker infrastructure failure (timeout/crash) is neither pass nor fail —
      // never launch an un-checked tree, never record it as a failure
      r.syntax = r.checkerFails === 0 && !chk.inconclusive;
      const sb = r.syntax ? await sandboxLaunchCopy(id, "3x")
        : { ok: false, note: chk.inconclusive ? "checker errored (" + String(chk.error || "unknown").split("\n")[0] + ") — no verdict"
                                             : "skipped — checker failed" };
      r.launch = sb.ok; r.launchNote = sb.note;
      // "sandbox already running" is a scheduling collision (manual sandbox vs check),
      // not a launch failure — recording it as FAIL would unjustly punish the rule
      r.inconclusive = !!sb.inconclusive || /sandbox already running/.test(sb.note || "") || !!chk.inconclusive;
      r.ok = r.syntax && r.launch;
      results.push(r);
      log(`run ${run}/3: checker ${r.syntax ? "PASS" : "FAIL"} · launch ${r.launch ? "PASS" : r.inconclusive ? "INCONCLUSIVE" : "FAIL"}${r.launchNote ? " (" + r.launchNote + ")" : ""}`);
      if (!r.ok) break;
    }
    let collateral = { checked: false };
    if (opts.scope && snapBefore) {
      const d = diffSnapshot(id, snapBefore); // diff against the PRE-CHANGE baseline
      const changed = [...(d.changed || []), ...(d.added || []), ...(d.removed || [])];
      const outside = changed.filter(f => !opts.scope.includes(f));
      collateral = { checked: true, ok: outside.length === 0, outside, changed };
      log(collateral.ok ? `collateral PASS — only scoped files changed (${changed.join(", ") || "none"})`
                        : `collateral FAIL — outside scope: ${outside.join(", ")}`);
    }
    const ok = results.length === 3 && results.every(r => r.ok) && (!collateral.checked || collateral.ok);
    // an inconclusive run (sandbox couldn't bind a hardcoded port the live app holds)
    // is neither a pass nor a failure — no reward, no punishment
    const inconclusive = !ok && results.some(r => r.inconclusive);
    if (ok) {
      if (opts.rule) rewardRule(opts.rule);
      log("✅ TRIPLE-CHECK PASSED 3/3" + (opts.rule ? " — rule rewarded 🏆" : ""));
    } else {
      if (opts.rule && !inconclusive) punishRule(opts.rule);
      let restored = false;
      // roll back to the PRE-CHANGE baseline we captured — never "whatever is newest now"
      if (opts.restoreOnFail && snapBefore) restored = !!(await restoreSnapshot(id, snapBefore)).ok;
      log(`❌ TRIPLE-CHECK ${inconclusive ? "INCONCLUSIVE — no verdict, no reward, no punishment" : "FAILED"}${opts.rule && !inconclusive ? " — rule punished ⚖️" : ""}${restored ? " — snapshot restored" : ""}`);
    }
    // don't resurrect brain state for a project deleted mid-check
    if (getProfile(id)) rememberProject(id, { lastTriple: { at: new Date().toISOString(), ok, results, collateral, label: opts.label || null } });
    return { ok, results, collateral };
  } finally { tripleRunning.delete(id); }
}
async function restoreSnapshot(id, snapName) {
  try {
    const p = getProfile(id);
    if (!p) return { ok: false, error: "no such project" };
    const dir = path.join(DATA_DIR, "snapshots", id);
    let snaps = [];
    try { snaps = fs.readdirSync(dir).sort(); } catch {}
    if (!snaps.length) return { ok: false, error: "no snapshots yet — run a sandbox test first" };
    // restore the requested snapshot (e.g. the pre-change baseline), else the newest
    const name = (snapName && snaps.includes(snapName)) ? snapName : snaps[snaps.length - 1];
    const snap = path.join(dir, name);
    // confirm the snapshot is real BEFORE deleting a single live file
    if (!fs.statSync(snap).isDirectory()) return { ok: false, error: "snapshot missing or corrupt" };
    await stopProject(p); // wait for the old process to fully die before touching files
    for (const it of fs.readdirSync(p.path, { withFileTypes: true })) {
      if (HASH_SKIP.has(it.name)) continue; // keep installed deps — they're not in snapshots
      fs.rmSync(path.join(p.path, it.name), { recursive: true, force: true });
    }
    const restoreFails = copyTree(snap, p.path, HASH_SKIP);
    if (restoreFails) return { ok: false, error: `restore incomplete — ${restoreFails} file(s) failed to copy` };
    // if the live node_modules is gone but the app needs deps, reinstall in the
    // background — a blocking npm install would freeze the whole dashboard
    if (fs.existsSync(path.join(p.path, "package.json")) && !fs.existsSync(path.join(p.path, "node_modules"))) {
      pushLog(id, "[launchpad] node_modules missing after restore — reinstalling in the background…");
      // detached: killFixProcs kills the whole process GROUP (kill(-pid)) — without
      // detached the child shares the server's group and the group kill would miss
      const ni = cp.spawn("npm", ["install"], { cwd: p.path, stdio: "ignore", detached: true });
      trackFixProc(id, ni); // a Stop or relaunch must kill this — two npm installs on one tree corrupt it
      ni.on("close", c => { untrackFixProc(id, ni); pushLog(id, "[launchpad] background npm install exited " + c); });
      ni.on("error", e => { untrackFixProc(id, ni); pushLog(id, "[launchpad] background npm install error: " + e.message); });
    }
    pushLog(id, "[launchpad] restored snapshot " + name);
    const rch = hashProject(p.path);
    if (rch) rememberProject(id, { contentHash: rch });
    return { ok: true };
  } catch (e) { return { ok: false, error: e.message }; }
}

/* diff live app vs a snapshot — proves a change touched ONLY what it should.
   pass snapName to diff against a specific snapshot (e.g. the pre-change baseline). */
function diffSnapshot(id, snapName) {
  const p = getProfile(id);
  if (!p) return { ok: false, error: "no such project" };
  const dir = path.join(DATA_DIR, "snapshots", id);
  let snaps = [];
  try { snaps = fs.readdirSync(dir).sort(); } catch {}
  if (!snaps.length) return { ok: false, error: "no snapshots yet — run a sandbox test first" };
  const snapId = (snapName && snaps.includes(snapName)) ? snapName : snaps[snaps.length - 1];
  const snap = path.join(dir, snapId);
  const list = d => {
    const out = new Map();
    const walk = rel => {
      let items;
      try { items = fs.readdirSync(path.join(d, rel), { withFileTypes: true }); } catch { return; }
      for (const it of items) {
        if (it.name === ".DS_Store" || HASH_SKIP.has(it.name)) continue;
        const r = rel ? rel + "/" + it.name : it.name;
        if (it.isDirectory()) walk(r);
        else if (it.isSymbolicLink()) {
          // symlinks are invisible to isFile() — without this, a planted link (or a
          // changed target) outside the declared scope would pass the collateral check
          try { out.set(r, "link→" + fs.readlinkSync(path.join(d, r))); } catch {}
        }
        else if (it.isFile()) {
          try {
            // stream the hash — even huge assets are compared honestly, no "big" blind spot
            const sum = crypto.createHash("sha1");
            const fd = fs.openSync(path.join(d, r), "r");
            try {
              const buf = Buffer.alloc(65536);
              let n;
              while ((n = fs.readSync(fd, buf, 0, buf.length, null)) > 0) sum.update(buf.subarray(0, n));
            } finally { fs.closeSync(fd); } // a read error must not leak the descriptor
            out.set(r, sum.digest("hex").slice(0, 12));
          } catch {}
        }
      }
    };
    walk("");
    return out;
  };
  const a = list(snap), b = list(p.path);
  const changed = [], added = [], removed = [];
  for (const [f, v] of b) { if (!a.has(f)) added.push(f); else if (a.get(f) !== v) changed.push(f); }
  for (const f of a.keys()) if (!b.has(f)) removed.push(f);
  return { ok: true, snapshot: snapId, changed, added, removed };
}

/* ---------------- project scanning ---------------- */
function scanProject(dir) {
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory())
    return { ok: false, error: "not a directory: " + dir };
  const has = f => fs.existsSync(path.join(dir, f));
  // type-checked read: a fifo at a trusted name would make readFileSync block forever
  const read = f => { try { const fp = path.join(dir, f); if (!fs.statSync(fp).isFile()) return ""; return fs.readFileSync(fp, "utf8"); } catch { return ""; } };
  const result = { ok: true, path: dir, stack: "unknown", entries: [], scripts: {}, notes: [] };

  // a malformed package.json must not kill the scanner — autopilot gets a real,
  // diagnosable npm parse failure instead of dying in the scan; /api/brain never 500s
  let pkg = null;
  if (has("package.json")) { try { pkg = JSON.parse(read("package.json") || "{}"); } catch { pkg = {}; } }
  if (pkg) {
    result.stack = "node";
    result.scripts = pkg.scripts || {};
    result.deps = Object.keys({ ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) });
    if (result.deps.includes("electron")) result.notes.push("Electron app detected");
    if (pkg.scripts && pkg.scripts.start) result.entries.push({ label: "npm start", command: "npm start" });
  }
  const pyFiles = ["app.py", "main.py", "server.py", "wsgi.py", "manage.py"];
  const hasPy = has("requirements.txt") || has("pyproject.toml") || has("setup.py") || pyFiles.some(has);
  if (hasPy && result.stack === "unknown") result.stack = "python";
  if (hasPy) result.notes.push("Python project detected");
  for (const f of ["server/index.js", "index.js", "src/index.js", "main.js", "app.js", "server.js", "index.mjs"]) {
    if (has(f)) result.entries.push({ label: f, command: "node " + f });
  }
  for (const f of pyFiles) {
    if (has(f)) {
      const venv = has("venv/bin/python") ? "venv/bin/python" : "python3";
      result.entries.push({ label: f, command: `${venv} ${f}` });
    }
  }
  for (const f of ["start.sh", "launch.sh", "run.sh"]) {
    if (has(f)) result.entries.push({ label: f + " (shell)", command: "./" + f });
  }
  if (!has("node_modules") && result.stack === "node") result.notes.push("node_modules missing — you'll want npm install");
  return result;
}

let envCache = null, envCacheAt = 0;
async function envCheck() {
  // six binary probes run CONCURRENTLY and off the event loop — the old sequential
  // execSync version could freeze the whole server ~48s on a first dashboard load
  if (envCache && Date.now() - envCacheAt < 5 * 60 * 1000) return envCache;
  const out = {};
  const bins = { node: ["node", ["-v"]], npm: ["npm", ["-v"]], python3: ["python3", ["--version"]],
                 pip3: ["pip3", ["--version"]], ollama: ["ollama", ["--version"]], git: ["git", ["--version"]] };
  await Promise.all(Object.entries(bins).map(async ([k, [bin, args]]) => {
    // promisified execFile resolves {stdout,stderr} — NOT a string like execSync
    try { out[k] = String((await execFile(bin, args, { timeout: 8000 })).stdout).trim().split("\n")[0]; }
    catch { out[k] = null; }
  }));
  envCache = out; envCacheAt = Date.now();
  return out;
}

/* file API, jailed to project root */
function jail(p, rel) {
  const abs = path.resolve(p.path, "." + path.sep + (rel || ""));
  if (abs !== p.path && !abs.startsWith(p.path + path.sep)) throw new Error("outside project");
  // symlinks can point outside the project (a crafted zip can plant them via unzip) —
  // reject any symlink component so reads AND writes can never escape through one
  let cur = abs;
  while (cur !== p.path && cur.startsWith(p.path)) {
    let st = null;
    try { st = fs.lstatSync(cur); } catch {} // lstat never follows the link
    if (st && st.isSymbolicLink()) throw new Error("outside project (symlink)");
    cur = path.dirname(cur);
  }
  return abs;
}

/* ---------------- http helpers ---------------- */
function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(body) });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let b = "", settled = false;
    const done = (fn, v) => { if (!settled) { settled = true; fn(v); } };
    req.on("data", c => { b += c; if (b.length > 5e6) req.destroy(); }); // oversize → destroy → "close" rejects below
    req.on("end", () => { try { done(resolve, b ? JSON.parse(b) : {}); } catch (e) { done(reject, e); } });
    req.on("close", () => done(reject, new Error("request closed")));
    req.on("error", e => done(reject, e));
  });
}
const MIME = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".json": "application/json", ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon" };
function serveStatic(req, res) {
  let p = new URL(req.url, "http://x").pathname;
  if (p === "/") p = "/index.html";
  const f = path.join(PUBLIC_DIR, path.normalize(p).replace(/^\/+/, ""));
  if (!f.startsWith(PUBLIC_DIR) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) {
    res.writeHead(404); res.end("not found"); return;
  }
  res.writeHead(200, { "Content-Type": MIME[path.extname(f)] || "application/octet-stream" });
  fs.createReadStream(f).pipe(res);
}

/* ---------------- routes ---------------- */
const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, "http://x");
    const q = Object.fromEntries(u.searchParams.entries());

    if (req.method === "GET" && u.pathname === "/api/brain") {
      const b = loadBrain();
      return send(res, 200, { learned: b.signatures.filter(s => s.ok > 0).length,
        signatures: b.signatures, selftests: b.selftests,
        lastWeeklyScan: b.lastWeeklyScan, weeklyScan: b.settings.weeklyScan,
        rewards: (b.totals || {}).rewards || 0, punishments: (b.totals || {}).punishments || 0,
        projects: b.projects, unknown: b.unknown.length,
        authors: authorProfiles(), lpVersion: distVersion(),
        queued: Object.values(b.projects).reduce((n, pr) =>
          n + ((pr.queue || []).filter(x => x.status !== "done").length), 0) });
    }
    if (req.method === "POST" && u.pathname === "/api/rules/reset") {
      // lift quarantines: clear all rule scores so punished-out rules get another chance
      const b = loadBrain();
      b.signatures = [];
      saveBrain(b);
      return send(res, 200, { ok: true });
    }
    if (req.method === "POST" && u.pathname === "/api/settings") {
      const bd = await readBody(req);
      const b = loadBrain();
      if (typeof bd.weeklyScan === "boolean") b.settings.weeklyScan = bd.weeklyScan;
      if (typeof bd.idleVerify === "boolean") b.settings.weeklyScan = bd.idleVerify; // old toggle name
      saveBrain(b);
      return send(res, 200, { ok: true, settings: b.settings });
    }
    if (req.method === "POST" && u.pathname === "/api/scan-now") {
      setImmediate(() => maybeWeeklyScan(true).then(() => {}));
      return send(res, 200, { ok: true, started: true });
    }
    // self-update: the tool updates ITSELF in place — from a pasted path/URL
    // (he tells the tool) or a package I hand him (he tells me). verified as a
    // real Launchpad dist, current install backed up, running apps relaunched.
    if (req.method === "POST" && u.pathname === "/api/self-update") {
      const b = await readBody(req).catch(() => ({}));
      if (!b.path && !b.url) return send(res, 400, { ok: false, error: "path or url required" });
      const r = await selfUpdate(b); // returns BEFORE the restart fires — the response flushes first
      return send(res, r.ok ? 200 : 400, r);
    }
    if (req.method === "GET" && u.pathname === "/api/self-update/status")
      return send(res, 200, { ok: true, phase: selfState.phase, note: selfState.note, version: selfState.version });
    if (req.method === "GET" && u.pathname === "/api/self-update/check") {
      // check a published manifest {version, url, sha256} for a newer release
      const url = q.url;
      if (!url) return send(res, 400, { ok: false, error: "url required" });
      try {
        const u2 = new URL(String(url));
        if (!/^https?:$/.test(u2.protocol)) throw new Error("only http(s) URLs");
        const tmp = path.join(os.tmpdir(), "lp-manifest-" + Date.now().toString(36) + ".json");
        await downloadFile(u2, tmp);
        const m = JSON.parse(fs.readFileSync(tmp, "utf8"));
        fs.unlinkSync(tmp);
        const nv = m.version || "0.0.0";
        return send(res, 200, { ok: true, current: distVersion(), latest: nv,
          updateAvailable: compareVersions(nv, distVersion()) > 0, url: m.url || null });
      } catch (e) { return send(res, 200, { ok: false, error: e.message }); }
    }
    if (req.method === "GET" && u.pathname === "/api/autoupdate/status") {
      let persisted = {};
      try { persisted = loadBrain().autoUpdate || {}; } catch {}
      return send(res, 200, { ok: true, current: distVersion(), busy: autoState.busy,
        lastCheck: autoState.lastCheck || persisted.lastCheck || null,
        lastResult: autoState.lastCheck ? autoState.lastResult : (persisted.lastResult || autoState.lastResult),
        badVersions: getBadVersions(),
        settings: autoSettings() });
    }
    if (req.method === "POST" && u.pathname === "/api/autoupdate/settings") {
      const bd = await readBody(req).catch(() => ({}));
      return send(res, 200, { ok: true, settings: saveAutoSettings(bd || {}) });
    }
    if (req.method === "POST" && u.pathname === "/api/autoupdate/check") {
      const r = await autoUpdateTick(true);
      return send(res, r.ok ? 200 : 400, r);
    }
    if (req.method === "GET" && u.pathname === "/api/projects") {
      const ps = loadProfiles().map(p => {
        const r = runner(p.id);
        const mem = (loadBrain().projects[p.id] || {});
        return { ...p, status: r.status, startedAt: r.startedAt, lastDiagnosis: r.lastDiag,
                 phase: r.phase, appUrl: r.appUrl, ready: r.ready,
                 queue: mem.queue || [], author: projectAuthor(p),
                 changed: projectChanged(p), lastSandbox: mem.lastSandbox || null,
                 lastTriple: mem.lastTriple || null,
                 verified: mem.lastVerified || null, issues: mem.issues || [],
                 smokeNote: mem.smokeNote || null };
      });
      return send(res, 200, ps);
    }
    if (req.method === "POST" && u.pathname === "/api/scan") {
      const b = await readBody(req);
      return send(res, 200, scanProject(b.path || ""));
    }
    // file/folder picker for the dashboard — the browser can't show a native
    // dialog with a real path, so the local server lists the real filesystem.
    // localhost-only app on the user's own machine: any readable dir is fair game.
    if (req.method === "GET" && u.pathname === "/api/browse") {
      let p = (u.searchParams.get("path") || "").trim() || HOME;
      try {
        p = path.resolve(p);
        const st = fs.statSync(p);
        if (!st.isDirectory()) p = path.dirname(p); // a file path → browse its folder
        const entries = [];
        for (const n of fs.readdirSync(p)) {
          if (n === "." || n === "..") continue;
          const fp = path.join(p, n);
          let dir = false;
          try { dir = fs.statSync(fp).isDirectory(); } catch { continue; } // unreadable → skip, don't die
          entries.push({ name: n, path: fp, dir });
        }
        entries.sort((a, b) => ((b.dir ? 1 : 0) - (a.dir ? 1 : 0)) || a.name.localeCompare(b.name));
        return send(res, 200, { ok: true, path: p, parent: path.dirname(p), home: HOME, entries });
      } catch (e) {
        return send(res, 200, { ok: false, error: "can't read that folder: " + e.message });
      }
    }
    if (req.method === "GET" && u.pathname === "/api/env") {
      return send(res, 200, await envCheck());
    }
    if (req.method === "POST" && u.pathname === "/api/projects") {
      const b = await readBody(req);
      if (!b.name || !b.path) return send(res, 400, { ok: false, error: "name and path required" });
      const srcPath = b.path;
      const isZip = /\.zip$/i.test(srcPath) && fs.existsSync(srcPath) && fs.statSync(srcPath).isFile();
      if (!isZip && (!fs.existsSync(srcPath) || !fs.statSync(srcPath).isDirectory()))
        return send(res, 400, { ok: false, error: "folder not found: " + srcPath });
      const id = "p-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8); // unique — two adds in the same ms must never share an id
      let appPath, origin = srcPath;
      try {
        // everything the tool runs lives inside its own organized store — the
        // original folder/zip is never touched after ingest
        appPath = isZip ? handleZip(srcPath, id) : ingestApp(id, srcPath, srcPath);
        if (isZip) saveManifest(id, { id, origin, ingestedAt: new Date().toISOString(),
          originHash: hashProject(srcPath), storeHash: hashProject(appPath) });
      } catch (e) {
        // a failed add must not leave a half-stored app with no profile pointing at it —
        // ingestApp/handleZip self-clean their temp dirs, this catches anything left over
        try { fs.rmSync(storeDir(id), { recursive: true, force: true }); } catch {}
        try { fs.rmSync(storeDir(id) + ".ingest-" + process.pid, { recursive: true, force: true }); } catch {}
        try { fs.rmSync(storeDir(id) + ".unzip-" + process.pid, { recursive: true, force: true }); } catch {}
        return send(res, 400, { ok: false, error: "couldn't store the app: " + e.message });
      }
      const p = { id, name: b.name, path: appPath, origin,
                  command: b.command || "auto", env: b.env || {}, created: new Date().toISOString() };
      // fresh read right before the push — the list was loaded before the ingest;
      // two concurrent adds would otherwise clobber each other's profile
      const fresh = loadProfiles(); fresh.push(p); saveProfiles(fresh);
      if ((b.command || "auto") === "auto") setImmediate(() => autopilot(p.id));
      return send(res, 200, { ok: true, project: p, autopilot: (b.command || "auto") === "auto" });
    }
    // anchored: only /api/projects/<id> deletes a project — never /sandbox, /diff, etc.
    if (req.method === "DELETE" && /^\/api\/projects\/[^/]+$/.test(u.pathname)) {
      const id = u.pathname.split("/")[3];
      // never delete under a running triple-check — it would fail the check and
      // unjustly punish the fix rule for a user action it had nothing to do with
      if (tripleBusy(id)) return send(res, 200, { ok: false, error: "triple-check is running — wait for it to finish" });
      await stopProject({ id }); // await BEFORE runners.delete — or the stop's trailing broadcast re-creates a zombie entry
      await stopProject({ id: id + ":sandbox" }); // a manual sandbox in flight uses its own runner — stop it too, or it keeps running headless in an unlinked dir
      saveProfiles(loadProfiles().filter(p => p.id !== id));
      runners.delete(id);
      runners.delete(id + ":sandbox"); // drop the sandbox runner entry — no zombie logs/broadcasts
      // remove the tool's stored copy — the user's ORIGINAL folder is never touched
      try { fs.rmSync(storeDir(id), { recursive: true, force: true }); } catch {}
      try { fs.unlinkSync(manifestFile(id)); } catch {}
      try { fs.rmSync(path.join(DATA_DIR, "snapshots", id), { recursive: true, force: true }); } catch {}
      try { fs.rmSync(path.join(DATA_DIR, "sandbox", id), { recursive: true, force: true }); } catch {}
      // drop orphaned brain state (queue, crash rules, last checks) so a re-add starts clean
      // (sandbox runs write under the real id — there is no ":sandbox" brain key to clean)
      try {
        const b = loadBrain();
        delete b.projects[id];
        saveBrain(b);
      } catch {}
      return send(res, 200, { ok: true });
    }
    // change queue, sandbox test, restore, author override
    const pq = u.pathname.match(/^\/api\/projects\/([^/]+)\/(sandbox|restore|queue|author|diff|triplecheck)(?:\/([^/]+))?$/);
    if (pq) {
      const [, id, act, sub] = pq;
      const p = getProfile(id);
      if (!p) return send(res, 404, { ok: false, error: "no such project" });
      const mem = (loadBrain().projects[id] || {});
      if (act === "sandbox" && req.method === "POST") {
        // a manual sandbox mid-triple-check would make sandboxLaunchCopy bail with
        // "sandbox already running", which triple-check would record as a false launch FAIL
        if (tripleBusy(id)) return send(res, 200, { ok: false, error: "triple-check is running — wait for it to finish" });
        if (sandboxClaimed.has(id)) return send(res, 200, { ok: false, error: "sandbox already running" });
        const sbr = runner(id + ":sandbox");
        if (sbr.autopilot || sbr.proc) return send(res, 200, { ok: false, error: "sandbox already running" });
        // answer honestly now — the old code said "started" then silently refused inside
        if (runner(id).autopilot) return send(res, 200, { ok: false, error: "app is still launching — wait for it to finish" });
        // claim synchronously so a double-click can't start two runs; released when
        // sandboxTest settles (success, failure, or throw)
        sandboxClaimed.add(id);
        setImmediate(() => sandboxTest(id).then(() => {}).catch(e => pushLog(id, "[sandbox] error: " + e.message)).finally(() => sandboxClaimed.delete(id)));
        return send(res, 200, { ok: true, started: true });
      }
      if (act === "restore" && req.method === "POST") {
        // a restore mid-triple-check would swap p.path under a running sandbox copy
        // → false FAIL (unjust punish) or false PASS (unjust reward)
        if (tripleBusy(id)) return send(res, 200, { ok: false, error: "triple-check is running — wait for it to finish" });
        // a restore mid-sandbox would tear p.path out from under sandboxLaunchCopy's
        // copyTree → ENOENT → "sandbox copy incomplete" false-failure badge
        const sbr = runner(id + ":sandbox");
        if (sbr.autopilot || sbr.proc) return send(res, 200, { ok: false, error: "sandbox is running — wait for it to finish" });
        return send(res, 200, await restoreSnapshot(id));
      }
      if (act === "diff" && req.method === "GET") return send(res, 200, diffSnapshot(id));
      if (act === "triplecheck" && req.method === "POST") {
        const bd = await readBody(req).catch(() => ({}));
        // claim synchronously AFTER the body await — two rapid POSTs must not both start
        if (!claimTriple(id)) return send(res, 200, { ok: false, error: "triple-check already running for this app" });
        setImmediate(() => tripleCheck(id, {
          // scope must be an array — a string would turn the collateral filter into
          // substring matching and could false-pass an out-of-scope change
          scope: Array.isArray(bd.scope) ? bd.scope : undefined, rule: bd.rule, label: bd.label,
          restoreOnFail: bd.restoreOnFail === true // default off — only roll back when asked
        }).then(() => {}).catch(e => pushLog(id, "[3x] error: " + e.message)));
        return send(res, 200, { ok: true, started: true });
      }
      if (act === "author" && req.method === "POST") {
        const bd = await readBody(req);
        if (!Object.hasOwn(AUTHORS, bd.author)) return send(res, 400, { ok: false, error: "unknown author" }); // hasOwn — AUTHORS["__proto__"] is truthy via the prototype chain on a plain object
        rememberProject(id, { authorOverride: bd.author });
        return send(res, 200, { ok: true, author: bd.author, label: AUTHORS[bd.author] });
      }
      if (act === "queue" && req.method === "POST" && !sub) {
        const bd = await readBody(req);
        if (!bd.text || !String(bd.text).trim()) return send(res, 400, { ok: false, error: "text required" });
        // fresh read AFTER the await — mem.queue was snapshotted before the body arrived;
        // two concurrent queue ops would otherwise clobber each other's items
        const q = ((loadBrain().projects[id] || {}).queue || []);
        const item = { id: "q-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8), text: String(bd.text).slice(0, 500),
                       at: new Date().toISOString(), status: "queued" };
        q.push(item);
        rememberProject(id, { queue: q });
        pushLog(id, "[launchpad] change queued: " + item.text.slice(0, 120));
        return send(res, 200, { ok: true, item });
      }
      if (act === "queue" && sub) {
        const q = ((loadBrain().projects[id] || {}).queue || []); // fresh — never mutate a stale snapshot
        if (req.method === "DELETE") {
          rememberProject(id, { queue: q.filter(x => x.id !== sub) });
          return send(res, 200, { ok: true });
        }
        if (req.method === "POST") {
          const bd = await readBody(req);
          // fresh read AFTER the await — the pre-await snapshot is stale; saving it
          // back would silently drop queue items added by a concurrent request
          const q2 = ((loadBrain().projects[id] || {}).queue || []);
          const it = q2.find(x => x.id === sub);
          if (!it) return send(res, 404, { ok: false });
          if (!["queued", "doing", "done"].includes(bd.status)) return send(res, 400, { ok: false });
          it.status = bd.status;
          // scope lock: the ONLY files this change is allowed to touch
          if (Array.isArray(bd.scope))
            it.scope = bd.scope.map(s => String(s).slice(0, 200)).slice(0, 20);
          rememberProject(id, { queue: q2 });
          return send(res, 200, { ok: true, item: it });
        }
      }
      return send(res, 404, { ok: false });
    }
    const m = u.pathname.match(/^\/api\/projects\/([^/]+)\/(start|stop|restart|logs|status|fix|autopilot|verify|update)$/);
    if (m) {
      const [, id, act] = m;
      const p = getProfile(id);
      if (!p) return send(res, 404, { ok: false, error: "no such project" });
      if (act === "start") return send(res, 200, startProject(p));
      if (act === "autopilot") {
        // a launch mid-triple-check would sync the origin + rewrite package-lock under
        // the check → false FAIL and an unjust punish. wait for it to finish.
        if (tripleBusy(id)) return send(res, 200, { ok: false, error: "triple-check is running — wait for it to finish" });
        setImmediate(() => autopilot(id)); return send(res, 200, { ok: true, started: true });
      }
      if (act === "verify") {
        const issues = await verifyProject(p);
        pushLog(id, "[launchpad] verify: " + (issues.length ? issues.slice(0, 3).join("; ") : "clean ✓"));
        return send(res, 200, { ok: true, issues });
      }
      if (act === "update" && req.method === "POST") {
        // in-place app update: new/changed files only, sandbox-verified before the
        // live app is touched, snapshot restore point, deps refreshed incrementally.
        // never delete-and-redownload — node_modules and .env are never wiped.
        const bd = await readBody(req).catch(() => ({}));
        if (!bd.path) return send(res, 400, { ok: false, error: "path required — paste the new version's folder or .zip path" });
        setImmediate(() => updateApp(id, String(bd.path)).catch(e => pushLog(id, "[update] error: " + e.message)));
        return send(res, 200, { ok: true, started: true });
      }
      if (act === "stop") return send(res, 200, await stopProject(p));
      if (act === "restart") {
        await stopProject(p);
        // a fresh launch supersedes any in-flight autopilot loop — without the bump,
        // the old loop wakes up, sees !autopilot and finish("stopped")s, marking the
        // just-started app as stopped while it's actually running
        runner(id).runSeq = (runner(id).runSeq || 0) + 1;
        setPhase(id, ""); // the old loop exits quietly now — don't leave its stale phase up
        return send(res, 200, startProject(p));
      }
      if (act === "status") {
        const r = runner(id);
        return send(res, 200, { status: r.status, startedAt: r.startedAt, lastDiagnosis: r.lastDiag, logTail: r.logs.slice(-200), phase: r.phase, appUrl: r.appUrl, ready: r.ready });
      }
      if (act === "logs") {
        const r = runner(id);
        res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" });
        res.write("data: " + JSON.stringify({ type: "history", lines: r.logs.slice(-300) }) + "\n\n");
        r.clients.add(res);
        req.on("close", () => r.clients.delete(res));
        return;
      }
      if (act === "fix") {
        const b = await readBody(req);
        if (!b.fix) return send(res, 400, { ok: false, error: "fix required" });
        runFix(p, b.fix).then(() => {}).catch(e => pushLog(p.id, "[fix] error: " + e.message));
        return send(res, 200, { ok: true, started: true });
      }
    }
    if (req.method === "GET" && u.pathname === "/api/tree") {
      const p = getProfile(q.id); if (!p) return send(res, 404, { ok: false });
      const dir = jail(p, q.rel || "");
      const items = fs.readdirSync(dir, { withFileTypes: true })
        .filter(d => !["node_modules", ".git", "__pycache__", ".venv", "dist"].includes(d.name))
        .map(d => ({ name: d.name, dir: d.isDirectory() }))
        .sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name));
      return send(res, 200, { items });
    }
    if (req.method === "GET" && u.pathname === "/api/file") {
      const p = getProfile(q.id); if (!p) return send(res, 404, { ok: false });
      const f = jail(p, q.rel || "");
      if (!fs.existsSync(f)) return send(res, 404, { ok: false, error: "not a file" });
      const st = fs.statSync(f);
      // regular files only — a fifo/socket/device would hang readFileSync forever
      // (fifos report size 0, so the 1MB cap below can't catch them)
      if (!st.isFile()) return send(res, 400, { ok: false, error: "not a regular file" });
      if (st.size > 1e6) return send(res, 400, { ok: false, error: "file too big" });
      // refuse binary files: decoding them as UTF-8 would corrupt the bytes on save
      const buf = fs.readFileSync(f);
      if (buf.includes(0)) return send(res, 400, { ok: false, error: "binary file — can't edit as text" });
      return send(res, 200, { ok: true, content: buf.toString("utf8") });
    }
    if (req.method === "POST" && u.pathname === "/api/file") {
      const b = await readBody(req);
      const p = getProfile(b.id); if (!p) return send(res, 404, { ok: false });
      // a save mid-triple-check would make the three runs verify three different trees —
      // and a half-typed edit would false-fail the check and unjustly punish the fix rule
      if (tripleBusy(b.id)) return send(res, 200, { ok: false, error: "triple-check is running — wait for it to finish" });
      const f = jail(p, b.rel || "");
      // refuse to write through a fifo/socket/device — writeFileSync would hang forever
      if (fs.existsSync(f) && !fs.statSync(f).isFile())
        return send(res, 400, { ok: false, error: "not a regular file" });
      // manual edits bypass the change queue — still keep the safety net:
      // snapshot first so there's always a restore point, then refresh the hash
      takeSnapshot(b.id);
      fs.mkdirSync(path.dirname(f), { recursive: true });
      fs.writeFileSync(f, String(b.content ?? "")); // String() — a non-string content can't 500 the save
      const fch = hashProject(p.path);
      if (fch) rememberProject(b.id, { contentHash: fch }); // unreadable dir must not wipe the known hash
      pushLog(b.id, `[launchpad] saved ${b.rel} (snapshot taken) — restart the app to apply`);
      return send(res, 200, { ok: true });
    }
    return serveStatic(req, res);
  } catch (e) {
    try { send(res, 500, { ok: false, error: e.message }); } catch {}
  }
});

// NOTE: this IIFE must stay AFTER all top-level consts (it reaches hashProject →
// HASH_SKIP via ingestApp). it ran at module top in an earlier revision and died in
// the TDZ every boot, silently orphaning a full app copy per boot.
// seed: if ~/offline-base44 exists with a start.sh, offer it as a project
(function seed() {
  try {
    const dir = path.join(HOME, "offline-base44");
    const start = path.join(dir, "start.sh");
    if (fs.existsSync(start)) {
      const ps = loadProfiles();
      if (!ps.some(p => p.origin === dir || p.path === dir)) {
        const id = "p-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8); // unique — two adds in the same ms must never share an id
        console.log("[launchpad] ingesting Offline Base44 into the app store…");
        const stored = ingestApp(id, dir, dir);
        ps.push({
          id,
          name: "Offline Base44",
          path: stored,
          origin: dir,
          command: "./start.sh",
          env: {},
          created: new Date().toISOString(),
        });
        saveProfiles(ps);
        console.log("[launchpad] seeded Offline Base44 project into the store");
      }
    }
    // adopt profiles created before the store existed — runs every boot, idempotent
    adoptUnstoredProfiles();
    // after a self-update: relaunch the apps that were running when it applied
    try {
      const rf = path.join(DATA_DIR, "restart-after-update.json");
      if (fs.existsSync(rf)) {
        const ids = JSON.parse(fs.readFileSync(rf, "utf8"));
        fs.unlinkSync(rf);
        if (Array.isArray(ids) && ids.length) {
          console.log("[launchpad] self-update: relaunching", ids.length, "app(s) …");
          setTimeout(() => { for (const pid of ids) { try { if (getProfile(pid)) autopilot(pid); } catch {} } }, 3000);
        }
      }
    } catch (e) { console.error("[launchpad] relaunch-after-update failed:", e.message); }
  } catch (e) { console.error("[launchpad] seed failed (server still starting):", e.message); }
})();

// socket tracking so a supervised restart can free the port even with lingering dashboard polls
const openSockets = new Set();
server.on("connection", s => { openSockets.add(s); s.on("close", () => openSockets.delete(s)); });
server.listen(PORT, "127.0.0.1", () => {
  console.log(`[launchpad] dashboard at http://127.0.0.1:${PORT}`);
  // warm the env cache in the background so the first dashboard load is instant
  setImmediate(() => envCheck().catch(() => {}));
});
// twice-weekly health scan: check every 6h whether a scan is due, first check 1 min after boot
setInterval(maybeWeeklyScan, 6 * 60 * 60 * 1000);
setTimeout(maybeWeeklyScan, 60 * 1000);
// AUTO-UPDATE poller: he does nothing, ever. every hour, check whether a check is due
// (first check 90s after boot). the tick no-ops when disabled or when no feed URL is set.
try {
  const persisted = JSON.parse(fs.readFileSync(BRAIN_FILE, "utf8")).autoUpdate || {};
  autoState.lastCheck = persisted.lastCheck || null;
  autoState.lastResult = persisted.lastResult || autoState.lastResult;
} catch {}
clearBadVersion(distVersion()); // this version booted fine — it's no longer suspect
setInterval(() => {
  try {
    const s = autoSettings();
    if (!s.enabled || !s.feedUrl || autoState.busy) return;
    const last = autoState.lastCheck;
    if (!last || Date.now() - Date.parse(last) > s.intervalHrs * 3600 * 1000)
      autoUpdateTick(false).catch(() => {});
  } catch {}
}, 60 * 60 * 1000);
setTimeout(() => { autoUpdateTick(false).catch(() => {}); }, 90 * 1000);
