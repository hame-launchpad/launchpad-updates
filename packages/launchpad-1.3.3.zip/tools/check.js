#!/usr/bin/env node
/* Launchpad system checker — custom-built syntax + capability checker for this Linux box.
   It's part of the main codebase: run it by hand, or the server runs it during
   pre-flight, sandbox tests and the triple-check.

   SYNTAX:  js → node --check | py → py_compile (batched, one process) | sh → bash -n | json → JSON.parse
   CAPABILITY (can it actually run HERE):
     - every non-relative require() in js must resolve (node_modules present)
     - every import in py must be findable (importlib find_spec — never executes code)
     - package.json deps must exist under node_modules/
     - shell scripts should have a shebang (warning, not a failure)

   Every external command runs via execFileSync with an argument array — filenames
   are NEVER interpolated into a shell string (a zip could contain `$(...).js`).

   Usage: node tools/check.js <project-dir> [relative-file ...]
   Prints a JSON report on stdout. Exit 0 = clean, 1 = failures, 2 = usage error.
*/
const fs = require("fs");
const path = require("path");
const cp = require("child_process");

const SKIP_DIRS = new Set(["node_modules", ".git", "dist", ".next", "venv", ".venv", "target", "__pycache__"]);
// never node --check these — they're not plain JS and would false-fail
const CHECKABLE = /\.(m?js|cjs|py|sh|json)$/;

function run(bin, args, opts) {
  try { return { ok: true, out: cp.execFileSync(bin, args, { stdio: ["ignore", "pipe", "pipe"], timeout: 15000, ...(opts || {}) }).toString() }; }
  catch (e) { return { ok: false, out: ((e.stdout || "") + "\n" + (e.stderr || "")).toString().trim().slice(0, 800) }; }
}
function listFiles(dir) {
  const out = [];
  const walk = rel => {
    let items;
    try { items = fs.readdirSync(path.join(dir, rel), { withFileTypes: true }); } catch { return; }
    for (const it of items) {
      if (it.name === ".DS_Store") continue;
      const r = rel ? rel + "/" + it.name : it.name;
      if (it.isDirectory()) { if (!SKIP_DIRS.has(it.name)) walk(r); }
      else if (it.isFile() && CHECKABLE.test(it.name)) out.push(r);
    }
  };
  walk("");
  return out;
}
const BUILTIN_JS = new Set(["fs","path","os","http","https","net","url","util","events","child_process","crypto","stream","querystring","assert","buffer","zlib","readline","process","timers","string_decoder","cluster","dgram","dns","domain","punycode","tty","v8","vm","worker_threads","perf_hooks","async_hooks","inspector","module","repl","trace_events"]);

/* strip comments so import/require scans don't flag commented-out code or doc prose */
function stripComments(src) {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/(^|[^:"'\/])\/\/.*$/gm, "$1"); // not after : ' " / — avoids mangling http:// and regex slashes
}
/* inside string literals, blank the words require/import/from (whole-word) so the
   import/require scans don't flag prose inside strings (SQL like 'select * from
   "users"', error messages, docs in template literals). the string CONTENT —
   including module names — is kept: real imports are code, not strings, so their
   keywords survive and still match. template ${...} interpolations are real code:
   scanned, not blanked. */
function blankKeywordsInStrings(src) {
  const defuse = s => s.replace(/\b(require|import|from)\b/g, m => " ".repeat(m.length));
  let out = "", i = 0;
  const n = src.length;
  // a "/" in code position starts a regex literal (not division) when the previous
  // significant token cannot end an expression. without this, a quote inside a
  // regex like /["']/ opens a phantom string and desyncs the whole parse.
  // scan back from a closing bracket to its opener, skipping strings; -1 if unmatched
  function matchBack(pos, openCh, closeCh) {
    let depth = 1, j = pos - 1;
    while (j >= 0 && depth > 0) {
      const c = src[j];
      if (c === '"' || c === "'" || c === "`") {
        const q = c; j--;
        while (j >= 0) {
          // single-step backwards: a \ escapes the char we just left (already
          // consumed), so it needs no extra skip — the old double j-- could
          // jump clean over the opening quote when the string starts with an
          // escape (foo("\"") / 2), desyncing the scan into a false positive
          if (src[j] !== q) { j--; continue; }
          // landed on a quote — it only ends the string if not escaped
          // (an odd run of backslashes before it means \" — keep scanning)
          let bs = 0, k = j - 1;
          while (k >= 0 && src[k] === "\\") { bs++; k--; }
          if (bs % 2 === 1) { j--; continue; }
          break;
        }
        j--; // past the opening quote
        continue;
      }
      if (c === closeCh) depth++;
      else if (c === openCh) depth--;
      j--;
    }
    return depth === 0 ? j + 1 : -1;
  }
  function wordBefore(pos) { // identifier-ish word ending at pos (inclusive), "" if none
    let j = pos;
    while (j >= 0 && /\s/.test(src[j])) j--;
    const end = j;
    while (j >= 0 && /[A-Za-z0-9_$]/.test(src[j])) j--;
    return src.slice(j + 1, end + 1);
  }
  function isRegexStart(pos) {
    let j = pos - 1;
    while (j >= 0 && (src[j] === " " || src[j] === "\t" || src[j] === "\n" || src[j] === "\r")) j--;
    if (j < 0) return true;
    const c = src[j];
    if (c === ")") {
      // statement condition → regex (if (x) /re/.test(y)); call/paren expr → division
      const open = matchBack(j, "(", ")");
      if (open === -1) return true; // unbalanced — err toward regex (emitted verbatim, nothing blanked)
      return /^(?:if|while|for|with|catch|switch)$/.test(wordBefore(open - 1));
    }
    if (c === "]") return false; // a regex after ] at statement position is a syntax error — always division
    if (c === "}") {
      const open = matchBack(j, "{", "}");
      if (open === -1) return true;
      let k = open - 1;
      while (k >= 0 && /\s/.test(src[k])) k--;
      const bc = k >= 0 ? src[k] : "";
      if (bc === ")") {
        // what does the ) close? a block header (if/while/...) → statement
        // position → regex. a class heritage clause (`class [Name] extends (expr)`)
        // closes with ) too — but the brace is a CLASS body, so it falls through
        // to the class declaration/expression check below (the backward walk
        // skips the paren group and finds the `class` keyword). otherwise it must
        // be a function's parameter list (a call can't be followed by {): a
        // declaration → statement position → regex; an expression → division.
        // locate the `function` keyword by stepping back over the optional name,
        // then check its position.
        const pOpen = matchBack(k, "(", ")");
        if (pOpen === -1) return true;
        if (/^(?:if|while|for|with|catch|switch)$/.test(wordBefore(pOpen - 1))) return true;
        // `extends` is a reserved word — in syntax-validated code it can only sit
        // in a class heritage clause, so this ) closes heritage, not parameters.
        if (wordBefore(pOpen - 1) !== "extends") {
        // locate the `function` keyword: the word right before `(` is the name
        // (or `function` itself when anonymous); the keyword is that word, or
        // the word before the name.
        let f = pOpen - 1;
        while (f >= 0 && /\s/.test(src[f])) f--;
        const w1End = f;
        while (f >= 0 && /[A-Za-z0-9_$]/.test(src[f])) f--;
        const w1Start = f + 1;
        const w1 = src.slice(w1Start, w1End + 1);
        let funcPos = -1;
        if (w1 === "function") funcPos = w1Start; // anonymous
        else {
          let g2 = w1Start - 1;
          while (g2 >= 0 && /\s/.test(src[g2])) g2--;
          const w2End = g2;
          while (g2 >= 0 && /[A-Za-z0-9_$]/.test(src[g2])) g2--;
          const w2Start = g2 + 1;
          if (src.slice(w2Start, w2End + 1) === "function") funcPos = w2Start;
        }
        if (funcPos !== -1) {
        let g = funcPos - 1;
        while (g >= 0 && /\s/.test(src[g])) g--;
        if (g < 0) return true;
        const bch = src[g];
        if (bch === ";" || bch === "{" || bch === "}") return true; // declaration
        const bw = wordBefore(g);
        // `async function f() {}`, `export function f() {}` and
        // `export default function() {}` are declarations → the / after the
        // body is at statement position → regex. (a quote inside that regex,
        // e.g. /["']/, would otherwise open a phantom string and desync into
        // a false "missing module")
        if (bw === "async" || bw === "export" || bw === "default") return true;
        return false; // expression position → division
        }
        // funcPos === -1: not function params — either a call in a class heritage
        // clause (`x = class A extends mixin(B) {}` — the / after it is DIVISION,
        // and erring toward regex opened a phantom string that swallowed a real
        // later require(), a missed "missing module") or a method body
        // (`{ m(a) {} }`). fall through to the class check below: the backward
        // walk finds `class` through the heritage (its position then decides
        // regex vs division), or breaks at the enclosing `{` and returns the
        // statement-position default (regex) — the same answer as before.
        }
        // extends-heritage or unrecognized paren: fall through to the class check below
      }
      if (bc === "=" || bc === "," || bc === "(" || bc === "[" || bc === ":") return false; // object literal → division
      if (src.slice(k - 1, k + 1) === "=>") return false; // arrow function body → division
      // word + its start index ending at pos (inclusive) — for the class check below
      const wpos = pos => {
        let j = pos;
        while (j >= 0 && /\s/.test(src[j])) j--;
        const end = j;
        while (j >= 0 && /[A-Za-z0-9_$]/.test(src[j])) j--;
        return { word: src.slice(j + 1, end + 1), start: j + 1 };
      };
      const w1 = wpos(k);
      // return/throw/yield/await/typeof/void/delete {…} → the {} is an object
      // literal in expression position → the / after it is division. (round 21:
      // `throw {} / 2` was misread as regex, opening a phantom string that
      // swallowed a real require() — a missed "missing module".)
      if (/^(?:return|throw|yield|await|typeof|void|delete)$/.test(w1.word)) return false;
      // class bodies: a declaration (`class A {}`) leaves the / at statement
      // position (regex), but a class expression (`x = class {}` /
      // `x = class A {}` / `x = class A extends B {}`) is division — misreading
      // it opens a phantom string that can swallow a real require() (missed
      // "missing module") or desync into a false one. locate the `class`
      // keyword, then check its position. the heritage clause (`extends …`) can
      // sit between the name and the body and hold arbitrary expressions, so
      // walk back over words, dotted names and balanced bracket groups
      // (matchBack skips strings, so a paren inside one can't desync it).
      let clsStart = -1;
      {
        let p = k;
        for (;;) {
          while (p >= 0 && /\s/.test(src[p])) p--;
          if (p < 0) break;
          const c = src[p];
          if (c === ")" || c === "]") {
            const o = matchBack(p, c === ")" ? "(" : "[", c);
            if (o === -1) break;
            p = o - 1;
            continue;
          }
          if (c === ".") { p--; continue; } // dotted heritage: extends B.C
          if (/[A-Za-z0-9_$]/.test(c)) {
            const e = p;
            while (p >= 0 && /[A-Za-z0-9_$]/.test(src[p])) p--;
            if (src.slice(p + 1, e + 1) === "class") {
              // the keyword — not a method literally named `class` (`{ class() {} }`)
              let a = e + 1;
              while (a < n && /\s/.test(src[a])) a++;
              if (src[a] !== "(") clsStart = p + 1;
              break;
            }
            continue; // class name, `extends`, heritage identifiers — keep walking
          }
          break; // `;` `=` `,` … — this brace never belonged to a class
        }
      }
      if (clsStart !== -1) {
        let g = clsStart - 1;
        while (g >= 0 && /\s/.test(src[g])) g--;
        if (g < 0) return true; // `class A {}` at file start → declaration
        const bch = src[g];
        if (bch === ";" || bch === "{" || bch === "}") return true; // declaration
        const bw = wordBefore(g);
        // `export [default] class` is a declaration → regex; anything else
        // (`= class`, `new class`, `(class`…) is an expression → division
        return bw === "default" || bw === "export";
      }
      return true; // try/catch/else/do/bare blocks → statement position → regex
    }
    if (c === '"' || c === "'" || c === "`") return false; // a string just ended → division
    if (/[A-Za-z0-9_$]/.test(c)) { // identifier, keyword, or number tail
      const word = wordBefore(j);
      // only these keywords can be followed by a regex instead of division
      return /^(?:return|throw|case|do|else|default|in|of|new|delete|typeof|void|yield|await|instanceof|break|continue)$/.test(word);
    }
    // postfix ++/-- → division (x++ / 2), not regex — a / can never start a regex
    // directly after ++/--. BUT `+++`/`---` before / is `(a++) + (/re/)`: the /
    // follows a BINARY operator, so it DOES start a regex (in valid code a /
    // directly after binary +/- is always a regex — division needs a left operand).
    if ((c === "+" || c === "-") && src[j - 1] === c && src[j - 2] !== c) return false;
    return true; // ( , = : [ ! & | ? ; + - * % < > ^ ~ { and friends → regex position
  }
  function regexEnd(pos) { // src[pos] === "/" — returns index past flags, or -1
    let j = pos + 1, inClass = false;
    while (j < n) {
      const c = src[j];
      if (c === "\\") { j += 2; continue; }
      if (c === "[") inClass = true;
      else if (c === "]") inClass = false;
      else if (c === "/" && !inClass) {
        j++;
        while (j < n && /[a-z]/i.test(src[j])) j++;
        return j;
      }
      else if (c === "\n") return -1;
      j++;
    }
    return -1;
  }
  function codeChar() { // one code-position unit: string, regex, or plain char
    const c = src[i];
    if (c === "'" || c === '"' || c === "`") { str(); return; }
    if (c === "/") {
      if (isRegexStart(i)) {
        const e = regexEnd(i);
        if (e !== -1) { out += src.slice(i, e); i = e; return; } // emit the regex untouched
      }
      out += c; i++; return; // division (or unparseable) — plain char
    }
    out += c; i++;
  }
  function interp() { // past "${" — scan the interpolation as code until the matching }
    let depth = 1;
    while (i < n && depth > 0) {
      const c = src[i];
      if (c === "{") { depth++; out += c; i++; continue; }
      if (c === "}") { depth--; out += c; i++; continue; }
      codeChar();
    }
  }
  function str() { // src[i] is the opening quote
    const q = src[i];
    out += q;
    i++;
    if (q !== "`") {
      const start = i;
      while (i < n && src[i] !== q && src[i] !== "\n") { if (src[i] === "\\") i++; i++; }
      out += defuse(src.slice(start, i));
      if (i < n && src[i] === q) { out += q; i++; }
      return; // unterminated: the newline stays as code
    }
    let chunk = i;
    while (i < n) {
      const c = src[i];
      if (c === "\\") { i += 2; continue; }
      if (c === "`") { out += defuse(src.slice(chunk, i)) + "`"; i++; return; }
      if (c === "$" && src[i + 1] === "{") {
        out += defuse(src.slice(chunk, i)) + "${"; i += 2;
        interp();
        chunk = i;
        continue;
      }
      i++;
    }
    out += defuse(src.slice(chunk, i)); // unterminated template — defuse what we saw
  }
  while (i < n) codeChar();
  return out;
}

function checkJS(abs, dir) {
  const rep = { syntax: { ok: true }, capability: { ok: true, issues: [] }, warnings: [] };
  const s = run("node", ["--check", abs]);
  if (!s.ok) { rep.syntax = { ok: false, msg: s.out }; return rep; }
  let src = "";
  try { src = fs.readFileSync(abs, "utf8"); } catch {}
  const code = blankKeywordsInStrings(stripComments(src)); // scans run on code only — comments and string prose must never fail a check
  const reqs = new Set();
  for (const m of code.matchAll(/require\(\s*["']([^"'./][^"']*)["']\s*\)/g)) reqs.add(m[1]);
  for (const m of code.matchAll(/from\s+["']([^"'./][^"']*)["']/g)) reqs.add(m[1]);
  // bare side-effect import: import "pkg" — matches nothing above, but a missing
  // side-effect package crashes the app just the same. anchored to line start (like
  // the python import scan): the word "import" inside a string literal — e.g. an
  // error message reading `relative import "x"` — must never match
  for (const m of code.matchAll(/^\s*import\s+["']([^"'./][^"']*)["']/gm)) reqs.add(m[1]);
  for (const r of reqs) {
    if (!r.trim()) continue; // whitespace-only name — can't be a real module
    if (BUILTIN_JS.has(r.split("/")[0])) continue;
    try { require.resolve(r, { paths: [dir, path.dirname(abs)] }); }
    catch (e) {
      // an installed ESM-only package (e.g. chalk v5) throws ERR_REQUIRE_ESM —
      // it IS installed, just not require()-able. never report it "missing"
      if (e.code === "ERR_REQUIRE_ESM") continue;
      rep.capability.ok = false; rep.capability.issues.push(`missing module "${r}" — not installed for this system`);
    }
  }
  for (const m of code.matchAll(/require\(\s*["'](\.[^"']*)["']\s*\)/g)) {
    // use the real resolver (never executes code) — a hand-rolled existsSync misses
    // .cjs/.mjs/.json, index.mjs/index.cjs and package.json "main" entries
    try { require.resolve(m[1], { paths: [path.dirname(abs)] }); }
    catch { rep.capability.ok = false; rep.capability.issues.push(`relative require "${m[1]}" points at nothing`); }
  }
  // ESM imports resolve the same way — static `from "./x"` and dynamic `import("./x")`
  for (const m of code.matchAll(/from\s+["'](\.[^"']*)["']/g)) {
    try { require.resolve(m[1], { paths: [path.dirname(abs)] }); }
    catch { rep.capability.ok = false; rep.capability.issues.push(`relative import "${m[1]}" points at nothing`); }
  }
  for (const m of code.matchAll(/import\(\s*["'](\.[^"']*)["']\s*\)/g)) {
    try { require.resolve(m[1], { paths: [path.dirname(abs)] }); }
    catch { rep.capability.ok = false; rep.capability.issues.push(`relative import "${m[1]}" points at nothing`); }
  }
  return rep;
}
let stdlibCache = null;
function getStdlib() {
  // ask the interpreter itself — a hardcoded list always misses something
  if (!stdlibCache) {
    const r = run("python3", ["-c", "import sys, json; print(json.dumps(sorted(sys.stdlib_module_names)))"]);
    try { stdlibCache = new Set(JSON.parse(r.out)); } catch { stdlibCache = new Set(); }
  }
  return stdlibCache;
}
function checkPY(abs, syntaxMsg) {
  const rep = { syntax: { ok: true }, capability: { ok: true, issues: [] }, warnings: [] };
  if (syntaxMsg !== null) { rep.syntax = { ok: false, msg: syntaxMsg }; return rep; }
  let src = "";
  try { src = fs.readFileSync(abs, "utf8"); } catch {}
  // docstrings can contain example imports — never scan them (same bug class as the JS comment-strip fix)
  const code = src.replace(/("""|''')[\s\S]*?\1/g, "");
  const mods = new Set();
  // every name in the list must resolve — `import a, b` and `import a as x, b as y`
  // used to check only the first name and let a missing second one slip through
  for (const m of code.matchAll(/^\s*import\s+([a-zA-Z_][\w.]*(?:\s+as\s+[a-zA-Z_]\w*)?(?:\s*,\s*[a-zA-Z_][\w.]*(?:\s+as\s+[a-zA-Z_]\w*)?)*)/gm))
    for (const part of m[1].split(",")) mods.add(part.trim().split(/\s+/)[0].split(".")[0]);
  for (const m of code.matchAll(/^\s*from\s+([a-zA-Z_][\w.]*)\s+import/gm)) mods.add(m[1].split(".")[0]);
  const STDLIB = getStdlib();
  for (const m of mods) {
    if (STDLIB.has(m) || m.startsWith("_")) continue;
    const f = run("python3", ["-c", "import importlib.util,sys; sys.exit(0 if importlib.util.find_spec(sys.argv[1]) else 1)", m]);
    if (!f.ok) { rep.capability.ok = false; rep.capability.issues.push(`missing python package "${m}" — pip install it on this system`); }
  }
  return rep;
}
function checkSH(abs) {
  const rep = { syntax: { ok: true }, capability: { ok: true, issues: [] }, warnings: [] };
  const s = run("bash", ["-n", abs]);
  if (!s.ok) { rep.syntax = { ok: false, msg: s.out }; return rep; }
  let head = "";
  try { head = fs.readFileSync(abs, "utf8").slice(0, 120); } catch {}
  // warning only — a missing shebang doesn't fail the gate
  if (!head.startsWith("#!")) rep.warnings.push("no shebang line — may not execute directly on this system");
  return rep;
}
function checkJSON(abs) {
  const rep = { syntax: { ok: true }, capability: { ok: true, issues: [] }, warnings: [] };
  try { JSON.parse(fs.readFileSync(abs, "utf8")); }
  catch (e) { rep.syntax = { ok: false, msg: e.message }; }
  return rep;
}
function checkPackages(dir) {
  const issues = [];
  const pj = path.join(dir, "package.json");
  if (fs.existsSync(pj)) {
    let deps = {};
    try { const j = JSON.parse(fs.readFileSync(pj, "utf8")); deps = { ...(j.dependencies || {}), ...(j.optionalDependencies || {}) }; } catch {}
    for (const d of Object.keys(deps))
      if (!fs.existsSync(path.join(dir, "node_modules", d)))
        issues.push(`package.json needs "${d}" but node_modules/${d} is missing`);
  }
  return issues;
}

function main() {
  const dir = process.argv[2];
  if (!dir || !fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) { console.error("usage: node tools/check.js <project-dir> [file ...]"); process.exit(2); }
  const root = path.resolve(dir);
  // explicit file args are validated: must stay inside the project, must be a known type.
  // "asked" vs "only": args that name nothing checkable check NOTHING — silently
  // falling back to a full project scan would make scoped checks theater.
  const asked = process.argv.slice(3);
  const only = asked.map(f => {
    const abs = path.resolve(root, f);
    if (abs !== root && !abs.startsWith(root + path.sep)) { console.error("file outside project: " + f); process.exit(2); }
    return path.relative(root, abs);
  }).filter(f => CHECKABLE.test(f) && fs.existsSync(path.join(root, f)) && fs.statSync(path.join(root, f)).isFile());
  const files = asked.length ? only : listFiles(root);
  const report = { dir: root, files: [], summary: { files: 0, syntaxFails: 0, capabilityFails: 0, warnings: 0 } };
  // batch python syntax: one py_compile process for all .py files, then per-file
  // only to identify the culprits when the batch fails
  const pyAbs = files.filter(f => /\.py$/.test(f)).map(f => path.join(root, f)).filter(a => fs.existsSync(a));
  const pyMsgs = new Map(); // abs -> failure message (absent = syntax ok)
  if (pyAbs.length) {
    const batch = run("python3", ["-m", "py_compile", ...pyAbs], { timeout: 30000 });
    if (!batch.ok) for (const a of pyAbs) {
      const one = run("python3", ["-m", "py_compile", a]);
      if (!one.ok) pyMsgs.set(a, one.out);
    }
  }
  for (const f of files) {
    const abs = path.join(root, f);
    if (!fs.existsSync(abs)) continue;
    let rep;
    if (/\.m?js$|\.cjs$/.test(f)) rep = checkJS(abs, root);
    else if (/\.py$/.test(f)) rep = checkPY(abs, pyMsgs.has(abs) ? pyMsgs.get(abs) : null);
    else if (/\.sh$/.test(f)) rep = checkSH(abs);
    else rep = checkJSON(abs);
    report.files.push({ file: f, syntax: rep.syntax, capability: rep.capability, warnings: rep.warnings });
    report.summary.files++;
    if (!rep.syntax.ok) report.summary.syntaxFails++;
    if (!rep.capability.ok) report.summary.capabilityFails++;
    report.summary.warnings += rep.warnings.length;
  }
  if (!asked.length) { // no scope args = full scan; explicit args that matched nothing check NOTHING (never a full scan)
    // merge dependency issues into the package.json entry (no duplicate rows)
    for (const i of checkPackages(root)) {
      let e = report.files.find(x => x.file === "package.json");
      if (!e) { e = { file: "package.json", syntax: { ok: true }, capability: { ok: true, issues: [] }, warnings: [] }; report.files.push(e); }
      e.capability.ok = false;
      e.capability.issues.push(i);
      report.summary.capabilityFails++;
    }
  }
  console.log(JSON.stringify(report));
  process.exit(report.summary.syntaxFails || report.summary.capabilityFails ? 1 : 0);
}
main();
