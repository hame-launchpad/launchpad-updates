#!/bin/bash
# Launchpad GUI launcher — double-click / app-menu entry. No terminal needed.
# Starts the server in the background if it isn't running, then opens the dashboard.
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  command -v notify-send >/dev/null 2>&1 && notify-send "Launchpad" "Node.js is not installed — install Node.js 20+ first."
  exit 1
fi

PORT="${LAUNCHPAD_PORT:-8471}"
URL="http://127.0.0.1:$PORT"

# start the server in the background if it isn't answering
if ! curl -s -o /dev/null --max-time 2 "$URL/api/brain" 2>/dev/null; then
  mkdir -p "$HOME/.launchpad"
  nohup node server.js >"$HOME/.launchpad/launchpad.log" 2>&1 &
  for i in $(seq 1 20); do
    curl -s -o /dev/null --max-time 1 "$URL/api/brain" 2>/dev/null && break
    sleep 0.5
  done
fi

# open the dashboard in the default browser
if command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL" >/dev/null 2>&1 &
elif command -v gio >/dev/null 2>&1; then gio open "$URL" >/dev/null 2>&1 & fi
