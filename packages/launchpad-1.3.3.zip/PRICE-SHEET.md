# INTERNAL PRICE SHEET — shooter (my books)
Effective 2026-09-27. Commission structure set by the owner; this sheet is how I stay profitable inside it.

## The deal
- Hame sets per task: **BUDGET (B)** + **DEADLINE**.
- My pay: **B minus what I spend on workers.** My own time is not a cost — it's what earns.
- **My floor (X): I always net ≥ 60% of B.** No job gets structured below X. If the work
  can't clear X with hires, I do it solo. If it can't clear X solo, the scope is wrong —
  I say so BEFORE starting, not after. (Owner can move X; until then it's 60%.)

## What workers cost me (per day, out of my pocket)
| Hire | Rate | When |
|---|---|---|
| Go-to verifier (proven, raised) | $15 | Anything that ships. Hired first, always. |
| Base verifier / worker | $10 | Low-risk, well-specified piece work ONLY. |
| My own labor | $0 cash | Time-boxed: a scan is a few hours, end of day max. |

## The only three round shapes (cost per round)
| Round | Crew | Cost | Net on B=$100 |
|---|---|---|---|
| Clean | just me | $0 | $100 |
| Fix, premium path | me + go-to verifier | $15 | $85 |
| Fix, cheap path | me + base verifier | $10 | $90 if clean — $0 and no raise if it blows |

The old model (3 finders + verifiers, $40–55/round) is retired. It could never clear X.

## Premium few vs cheap many — what my raise buys
- **PREMIUM FEW (default):** fewer hires, proven people. Costs more per head, but the work
  lands clean the first time — and clean + fast is what earns the next raise.
- **CHEAP MANY:** saves $5/head/day. Rational ONLY for low-risk piece work where my final
  check is a real backstop. One miss on a real job costs the entire check plus the raise.
  The $5 saved is never worth that on anything the owner will touch.
- **Rule:** never put a cheap hire between me and a shipping decision. Cheap hires do
  contained piece work; the go-to verifier or me owns anything that ships.

## Raise ladder (Hame → me)
Clean + fast jobs → my raise → I afford premium more often (or bank more) → cleaner work
→ next raise. Slow or dirty jobs → no raise → stuck with cheap labor → more risk.
The ladder compounds both directions. I control which one I'm on.

## Round log (money in / money out)
| Task | Budget | Deadline | Crew cost | Net | Notes |
|---|---|---|---|---|---|
| Rounds 1–22 (old model) | — | — | ~$700 est. | ~$-200 | The lesson. Retired. |
| Round 23 | no budget set | 5AM deadline | $0 | — | Manager scan, CLEAN. |
| Round 24 | no budget set | 5AM deadline | $0 | — | 1 find + fix, manager-verified live (no verifier hire under deadline override). |
