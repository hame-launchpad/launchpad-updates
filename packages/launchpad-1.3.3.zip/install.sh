#!/bin/bash
# Launchpad desktop install — run once. Adds Launchpad to the app menu.
# After this, launch it from the menu like any desktop app. No terminal needed.
cd "$(dirname "$0")"
APP_DIR="$PWD"
DESKTOP_DIR="$HOME/.local/share/applications"
mkdir -p "$DESKTOP_DIR"
cat > "$DESKTOP_DIR/launchpad.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Launchpad
Comment=One-click app launcher — add a folder or zip, it handles install, launch and fixes
Exec=$APP_DIR/launch-gui.sh
Icon=$APP_DIR/icon.png
Terminal=false
Categories=Development;
StartupNotify=false
EOF
chmod +x "$DESKTOP_DIR/launchpad.desktop" "$APP_DIR/launch-gui.sh"
echo "Done — open your app menu and launch Launchpad."
echo "(If the icon doesn't show yet, log out and back in once.)"
