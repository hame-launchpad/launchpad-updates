# Lessons learned — Launchpad review loop

This file is the system's memory. Every bug found during the release-gate review becomes a lesson here.
**Any agent writing or debugging code must read this file first and check every lesson against its work.**
New findings are appended as lessons with the round number. Never remove a lesson.

---

## L1 — Block scope kills: a `let` inside an inner block is invisible outside it (round 16)
`let pipOk = false` was declared inside the inner sandbox-venv else-branch, but the trailing gate
`if (reqHash && pipOk)` sat one block outside → `ReferenceError` after EVERY python pip run.
Every python autopilot launch ended "crashed / needs you" and pipHash was never recorded — a permanent loop.
**Rule:** any variable read after a block must be declared at (or above) the block level of its last read.
Trace every `let` from declaration to its last read; if the read is outside the declaring block, hoist.

## L2 — Generation guards on every post-await path (rounds 5, 6, 7)
A stale autopilot generation surviving a long await can duplicate fixes, double-punish a rule,
publish terminal status for a dead run, or open a browser tab for an app being stopped.
**Rule:** every `await` in a long-running loop is followed by a `superseded()`/generation check AND a
Stop check before doing anything with side effects (finish, mem, learn, browser-open, launch).

## L3 — User Stop is sacred (rounds 2, 6, 14)
Stop during npm install must not start pip; stop during post-crash verification must stay "stopped",
never be overwritten to "crashed"; a stopped fix must never be punished.
**Rule:** once the user hits Stop, the run's only legal outcome is "stopped". No fix, no learning, no relaunch.

## L4 — Never learn from inconclusive outcomes (rounds 7, 8)
Checker crashes/timeouts, scheduling collisions (manual sandbox vs triple-check), live-port collisions,
and user-interrupted fixes are INCONCLUSIVE — not pass, not fail.
**Rule:** reward/punish only on real outcomes. Terminal punish only when the fix command itself succeeded.
Score = ok − 2×fail; quarantine at −4.

## L5 — Sandbox isolation is absolute (rounds 2, 5, 7)
Sandbox never kills outside ports (kill-port refused wholesale); python gets its own venv — never system
site-packages, which the live app imports from; a hardcoded-port collision with the live app is
inconclusive, not failure; never snapshot or copy while the live app is mid-launch.
**Rule:** the sandbox must be unable to affect the live app by construction, not by luck.

## L6 — Atomic persistence; quarantine, don't replace (rounds 3, 4, 8)
Writes are temp-file + rename. Corrupt profiles/brain/manifests are QUARANTINED (renamed with timestamp),
never silently replaced with defaults — replacing destroys learned state on the next save.
**Rule:** repair-on-read is idempotent; unsalvageable state is quarantined, never deleted.

## L7 — FIFO / symlink / device safety (rounds 4, 5)
A FIFO can block a read forever; a symlink can point a chmod/read outside the app.
**Rule:** `statSync` + `isFile()` before every read; `lstatSync` refuses symlink chmod; chmod is jailed with
`startsWith(resolved + sep)`; symlinks are recorded (readlink), never descended; hashing and editor refuse
fifos/sockets/devices.

## L8 — Cap both count AND size (rounds 4, 5, 11)
A 3,000-entry log cap didn't stop multi-megabyte single lines; an uncapped file read could eat gigabytes.
**Rule:** cap entry count AND per-entry size (4000-char lines); cap content reads (64 MiB) with
path/size/mtime metadata fallback; cap file counts; stream big files in chunks.

## L9 — Claim synchronously (rounds 6, 7)
An async check-then-claim lets two rapid callers both start (double sandbox, double triple-check).
**Rule:** claim the slot (Set.add) synchronously at the call site, before any await.

## L10 — Regex vs division: declarations vs expressions (rounds 9, 11, 15–20)
JS `/` is ambiguous. The checker must distinguish statement-position regex from division:
- `export default function() {}` is a declaration → regex after the body (round 16).
- Function EXPRESSIONS are division: `const f = function() {} / 2` (rounds 15–16).
- Class DECLARATIONS are regex; class EXPRESSIONS are division: `const B = class {} / 2` (round 17).
- `extends` heritage hides the class keyword: plain (`extends B`), dotted (`extends B.C`),
  parenthesized (`extends (Object)`), calls (`extends mixin(Base)`), nested, string args (rounds 18–19).
  A `)` before `{` may close heritage, not parameters — check for `extends` first.
- Misreading opens phantom strings that either fabricate "missing module" (false positive → unjust punish)
  or swallow a real `require` (FALSE NEGATIVE → missing dep passes the gate).
**Rule:** when the keyword hunt fails, fall through to the class check rather than guessing regex.
Every new shape gets a fixture: the missing module must be detected AND the clean shape must stay clean.

## L11 — String-aware scanning (rounds 8, 9)
Docstrings, template docs, SQL, error-message strings, and `require(...)` prose must never be scanned
for imports — strip docstrings first, track string/template state.
**Rule:** the checker's own source must pass its own scan (self-check: 0 syntax / 0 capability failures).

## L12 — Boot order: init after constants (round 10)
The Offline Base44 seed IIFE ran before `HASH_SKIP` was initialized → temporal-dead-zone throw on every
boot, leaving an untracked orphan. **Rule:** one-time init/seed code runs after ALL top-level constants,
just before `server.listen`.

## L13 — Delete kills checks, never records (rounds 5, 7)
Deleting during triple-check or sandbox must stop the check, record nothing, and never resurrect brain
state for the deleted project. **Rule:** every result-recording path re-checks that the project still exists.

## L14 — Editor discipline (rounds 3, 6)
Refuse saves during triple-check (three runs must see the same tree); refuse NUL/binary files; coerce
save content to string; snapshot before save; never display "saved ✓" on a refusal.
**Rule:** a refused write must be visible as a refusal, never as a success.

## L15 — Object.hasOwn on all dynamic keys (rounds 12, 13)
Forged `__proto__` author names or ids can crash or poison lookups.
**Rule:** every dynamic-key read/write (authors, profile ids, brain keys) goes through `Object.hasOwn`.

## L16 — Repair source fields, not just derived scores (rounds 10, 15)
A corrupted string `ok` re-poisons `s.ok++` into NaN (which JSON serializes as null, erasing learning);
a string `rewards` concatenates forever ("3"→"31"→"311").
**Rule:** repair the SOURCE fields (`ok`, `fail`, `rewards`, `punishments`) to finite numbers; then derive the score.

## L17 — Weekly scan stamps only on completion (rounds 2, 4, 6)
`completed` must be hoisted outside `try`; the stamp is written only on full completion via a FRESH
`loadBrain()`; an aborted scan must not push the next check 3.5 days out.
**Rule:** completion is a fact, not an intention — stamp it only when it's true.

## L18 — Warmup timers capture the process, not a counter (round 4)
An old warmup timer could promote a newer process generation prematurely.
**Rule:** the timer captures its exact process object and checks identity (`r.proc === warmupProc`).

## L19 — Collateral diff vs pre-change baseline (rounds 4, 7)
Triple-check diffs against the PRE-CHANGE snapshot, and scope locks declare which files a change may touch.
**Rule:** anything outside scope fails the check — small, scoped, proven, or it didn't happen.

## L20 — Distinguish "needs you" from crashed (rounds 1, 2)
Autopilot ends at "needs you" only when no safe fix exists — with the console pointed at the details.
**Rule:** never report crashed when the truth is "I tried everything safe".

## L21 — Distrust must cover every path that reintroduces the distrusted value (round 20)
The remembered-port guard refused to `unshift` a port that was open before launch — but `portsFromLogs`
could put the SAME distrusted port back into the candidates from the app's own log text
("port 8080 in use, trying 8081"), and `checkPort` can't tell the squatter from the app → "ready" declared
on the wrong service, browser opened at the wrong service, and the squatted port re-learned.
**Rule:** when a value is distrusted, filter it from EVERY candidate source, not just the one you added.
A guard that only covers the path you wrote is half a guard — audit every path that can reintroduce it.

## L24 — Reset liveness state when the process dies or a fresh one starts (round 21)
`r.ready`/`r.appUrl` were set only by autopilot's ready block and cleared only at the next
autopilot run/attempt start. The exit handler set `proc=null`/`status="crashed"` but left
`ready=true` and the old URL in place — so after a crash the dashboard kept offering
"↗ Open app" on a dead port, and a manual "▶ Launch" relaunched while the OLD app still
showed as ready. `startProject` reset status/manualStop/lastDiag but not ready/appUrl.
**Rule:** liveness state (`ready`, `appUrl`, and anything like them) is cleared in BOTH places:
when the process exits (exit/error handlers — the process is dead, it is not ready) AND at
fresh launch (a new launch is not ready until proven). A state that means "currently true"
must never survive the event that makes it false.
Note: `stopProject` (server.js ~line 670) clears `phase` but not `ready`/`appUrl` either —
flagged for the part-2 range; the exit-handler clearing covers the kill path.

## L23 — Unary keywords make `{}` an object literal: `/` after is division (round 21)
`return {} / 2` was handled (division), but `throw {} / 2`, `yield {} / 2`, `await {} / 2`,
`typeof {} / 2`, `void {} / 2`, and `delete {} / 2` were all misread as regex — each opened a phantom
string that swallowed a real `require()`, so genuinely missing dependencies passed the gate (false negative).
All six are syntactically valid (verified with `node --check`); only `return` was in the division list.
**Rule:** after `return`/`throw`/`yield`/`await`/`typeof`/`void`/`delete`, a `{}` is always an object literal
in expression position — a `/` after its closing brace is division, never regex.
Companion trap: `x => {} / 2` LOOKS like division but is a SYNTAX ERROR in V8 (only `(x => {}) / 2` is
valid) — `node --check` rejects it before capability scanning, so it needs no checker rule. Always
validate a fixture's syntax before blaming the tokenizer.

## L22 — Probes must be total: never let an unvalidated persisted value reach a throwing API (round 21)
`checkPort` passed `memPort` (brain.json's `lastPort`, which `loadBrain` never validates) straight into
`net.connect`, which throws `ERR_SOCKET_BAD_PORT` synchronously on out-of-range/non-integer ports.
The throw rejected the promise inside `autopilotRun`'s try → every launch of that app ended
"crashed / needs you" forever, with a cryptic error and no self-heal (nothing repaired `lastPort`).
**Rule:** any function that probes the outside world (`net.connect`, `fs` calls, `execFile`) must
validate its inputs and return a safe negative (false/null) instead of throwing on malformed data —
especially when the input comes from persisted state that the repair chain doesn't cover.
A corrupted single value must degrade to "probe says closed", never to "the run crashes".

## L25 — Postfix ++/-- before `/` is always division; `+++`/`---` before `/` is always regex (round 22)
`x++ / 2` was misread as regex (the char before `/` is `+`, which fell through to `return true`), opening
a phantom regex that paired with a later `/` and swallowed a real `require()` — a missing dependency
passed the gate (false negative). But the naive fix (`++`/`--` before `/` → division) regressed the
minified shape `a+++ /["']/`: that's `(a++) + (/["']/)` — the `/` follows a BINARY `+`, so it IS a regex,
and misreading it as division let the `"` inside open a phantom string that swallowed a real require.
**Rule:** in syntax-valid code a `/` directly after `++`/`--` can never start a regex (verified:
`x++ /re/;` is a SyntaxError) → division; but `+++`/`---` immediately before `/` means the `/` follows
a binary operator → regex. Check `src[j-2]`: same char again → regex, otherwise → division.
Lesson for verifiers: every "obvious" one-line tokenizer fix must be tested against the minified
concatenation of the same operators (`+++`, `---`) before it ships.

## L26 — Clear EVERY adjacent liveness field at fresh launch, not just the one you just fixed (round 22)
Round 21 fixed stale `ready`/`appUrl` at fresh launch but left the ADJACENT field `r.phase`
uncleared in the same reset block — so after an autopilot "needs you", a manual ▶ Launch showed
`running` with a stale red "🛑 needs you" badge ("I tried everything safe") while the app ran fine
(live-reproduced: `status: running | phase: 'needs you'`). The exit handler did not need the clear:
on a manual launch nothing calls `setPhase` mid-run (only autopilot does), and every autopilot
exit path goes through `finish()`, which always overwrites phase — verified by auditing every
`.phase` read/write in server.js. `stopProject` already cleared phase; only plain manual `start`
was exposed (`restart` clears it too).
**Rule:** when you fix a stale-state bug in a reset block, clear EVERY field in the same family —
the next stale field is always the one sitting right next to the one you just fixed.

---

*Scoring (owner's rules, 2026-09-27): +1 per real find, +1 per verified fix. Calling a range CLEAN
and being proven wrong by a later round RESETS the reviewer's score to zero (not −1).
Three consecutive zero-resets = the owner deletes the assistant and the entire system built.
Reviewers are fully responsible for their verdicts — do not call it clean unless you mean it.*

## L27 — Every await in a cancellable run loop needs both guards (round 22)
`autopilotRun` had `if (superseded()) return;` after `await verifyProject(p)` but no stop guard — Stop during verify let the dead run continue into `[fix] $ npm install` (tree mutation + subprocess spawn after the user said stop). The identical `if (!runner(id).autopilot) return finish("stopped", "");` pattern already existed after the post-crash verify and the final port probe in the same function. **Rule:** every await in the run loop gets BOTH guards; when you add one guard, grep the function for sibling awaits missing it. (Secondary assessed same round: the await after `preflight()` has only the superseded guard — below the bar, because the retry loop's top guard honors the stop before any side effect: no launch, no install, no mutation. Not every missing guard is a bug; only ones that let a side effect through.)

## L28 — Port detection must cover every realistic log format (round 24)
`portsFromLogs` only recognized `host:port`, `port N`, and `listening on :N` — an app logging
`listening on 18777` (no colon, no "port" keyword) ran fine but never reached ✅ ready: no
`appUrl`, no Open button, the tool's core promise broken on a realistic log line. Live-reproduced
end-to-end (added app, waited 30s: `running`, `ready: false`, `appUrl: null` while the app served
200s). Fix: third alternative became `listening on(?:[^\d:]{0,8}:|\s+)(\d{2,5})\b` (non-capturing
group keeps m[1]/m[2]/m[3] numbering). Validated: 14/14 battery on realistic lines (incl. 6-digit
and 1-digit rejection) + full e2e re-run → `ready: true`, `appUrl: http://localhost:18777`, served
through the URL. **Rule:** any log-parsing regex gets a battery of REAL lines from real frameworks
(Express `listening on port N`, bare `listening on N`, `host:port`); a candidate that fails TCP
check is harmless, but a format never extracted is a silent miss. Note: the `checkPort` TCP
validation is what makes aggressive matching safe — never extract-and-trust without it.

## L29 — Never `pkill -f` with a pattern in your own command line (round 24, self-inflicted)
The manager killed his own shell with `pkill -f 'e2eapp/server.js'` — the pattern matched his own
exec command string. The round-22 verifier did the same thing. **Rule (absolute):** resolve exact
PIDs first (`ss -tlnp` + grep the port, or `ps aux` + awk), kill those PIDs. `pkill -f` is banned
from every runbook, no exceptions — knowing the footgun didn't stop the manager stepping in it.

## L30 — Never guess: read first, then act (owner's rule, 2026-09-27)
The manager guessed an apt entry's format twice and missed twice — the `grep` that found the
real line (`deb [trusted=yes] file: trixie main`) took one second and should have been step one.
Guessing caused the 22-round spiral, the overturned punishment, and every wasted cycle here.
**Rule (absolute, binds the whole crew):** before a sed, read the line. Before a patch, read the
code. Before a claim, reproduce it. A worker that guesses instead of reading fails the job.

## 2026-09-27 — the 22-scan lesson (auto-update)
22 review rounds verified the CODE was correct and still shipped a product hame
couldn't use: every "update" path needed him to download/upload/paste a package,
and the one-click Browse picker arrived as yet another zip he had to install by
hand. The scans checked implementation; nobody checked the OUTCOME against his
stated rule ("he does nothing, ever"). New review law: round 1 of any review
starts from the user's stated outcome and proves the build delivers it
end-to-end. A clean checker with a broken outcome is not clean — it's a failed
review. Fixed in v1.3.0: the poller fetches the feed itself, verifies staged
(checker + test boot), applies, supervised-restarts with automatic rollback.

## 2026-09-27 — auto-update poison-test finds (v1.3.0)
Four bugs the happy-path test never would have caught — all found by feeding
the updater hostile packages:
1. **Phase wedge.** A failed auto-update left `selfState.phase` stuck on
   "applying", so every future update (auto AND manual) was refused with "an
   update is already in progress" — one bad download bricked updating forever.
   Fix: `applySelfUpdatePkg` resets the phase to "failed" in a catch before
   rethrowing. Law: any function that sets a busy/in-progress flag MUST clear
   it on every failure path, not just the success path.
2. **Stale oldVersion.** `supervisedRestart` captured `distVersion()` AFTER the
   apply, so the rollback check waited for the restored server to report the
   NEW version — impossible — and misreported a successful rollback as failed.
   Fix: capture the pre-apply version in `applySelfUpdatePkg` and pass it in.
   Law: capture "before" state BEFORE the mutation, never after.
3. **CRITICAL-path port crash.** The last-resort "re-listen from memory" branch
   called `server.listen` on a port the rolled-back server already held —
   EADDRINUSE arrived as an async 'error' event (not a sync throw), so it
   escaped the try/catch and killed the process. Fix: only re-listen when the
   port is actually free; otherwise record and exit. Law: `server.listen`
   errors are async — a try/catch around it catches nothing.
4. **Flap loop.** After a rollback, the next boot-check re-downloaded the same
   poison version and flapped apply→die→rollback forever. Fix: versions that
   die on start go on a persisted `badVersions` blocklist — never auto-retried
   (manual retry still allowed); a version that boots fine clears its own mark.
   Law: any automatic retry loop needs a circuit breaker, or one bad release
   becomes a permanent outage.
