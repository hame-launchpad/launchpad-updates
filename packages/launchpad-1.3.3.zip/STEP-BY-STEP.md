# Launchpad — the one-click way (do this first)

1. Extract the launchpad zip anywhere, open a terminal in that folder, run:
   ./start.sh
   A dashboard opens in your browser.
2. Paste your app's folder path **or a .zip of the app** into the Scan box, hit **Scan**.
3. Hit **✨ Add & auto-launch — handle everything**.

That's it. Launchpad will now, on its own:
- unzip the app if you gave it a zip
- install missing dependencies (`npm install` / `pip install -r requirements.txt`)
- pick the entry point (prefers `npm start`, then `start.sh`, then `server/index.js`, etc.)
- launch the app and watch it
- if it crashes, diagnose the failure, apply the fix itself (install the missing
  module, free the blocked port, start `ollama serve`, pull the missing model),
  and relaunch — up to 5 attempts
- detect when the app is actually serving (finds its port in the logs and probes it)
  and mark it **✅ ready** with an **↗ Open app** button (it also opens the app in
  your browser automatically)

You just watch the status line. If it ends on **🛑 needs you**, open the Console —
I tried everything safe and the details are there for you to paste back to me.

Manual mode still exists: expand "manual setup instead" after scanning, pick the
entry point yourself, and use ▶ Launch / Console / Editor / fix buttons as before.

## The brain (it learns while you do nothing)

Launchpad keeps a memory at `~/.launchpad/brain.json`:

- **Every crash + fix is recorded.** When a fix works, it remembers; when it fails,
  that counts double. Next time the same failure appears it tries the fix with the
  best track record first — no wasted attempts.
- **Reward & punishment.** A fix isn't called "correct" until it proves itself:
  pass the triple-check (below) and the rule is **rewarded 🏆** (+1). Fail and it's
  **punished ⚖️** (−2). Score hits −4 and the rule is **quarantined** — never tried
  again ("punished out of trust") until something resets it. Totals show in the header.
- **It remembers each app**: working command, serving port, startup time. Next
  launch goes straight to the known-good port instead of hunting.
- **Pre-flight before every launch**: makes shell scripts executable, verifies every
  dependency actually resolves (not just "node_modules exists"), syntax-checks entry
  files — so apps run first time instead of crash-looping.
- **Unknown crashes are fingerprinted.** If it sees the exact same unknown crash twice,
  it tells you instead of starting from zero.
- **Verify only when something happened** — never on a timer while you work. An app
  is re-verified when: its code changed since last launch, a launch failed, you hit
  **✓ Verify**, or the **twice-weekly health scan** runs (toggle in the header, on by
  default). The scan waits until nothing is running, then: drills its own diagnoser
  against 12 known crash signatures (score in the header), re-verifies each stored
  app, and launch-tests each changed app to prove it still runs.

## Sandbox — the app is never touched until the change proves itself

Every test happens on an **isolated copy** (own directory, own free port — it will
never kill the live app's port). The flow for any change:

1. **Snapshot** the live app (last 3 kept, one-click **restore** brings any of them back).
2. Copy to the sandbox, link `node_modules`, launch, demand a full **ready**.
3. Only a 100% launch counts. Anything less → live app untouched.

**🔍 diff** on any card shows exactly what changed vs the last snapshot — file by file,
by content, not timestamps.

## Change requests — your ideas wait in a queue

Each card has **📝 change requests**. Type what you want ("make the button blue"),
it sits in the queue until the next refresh. When it's worked on, the change gets a
**🔒 scope lock**: the list of files it's allowed to touch. After the work, the
collateral check of the triple-check proves nothing outside the scope changed —
an agent can't "see something else and change that too".

**Who wrote what:** Launchpad guesses each app's author (you, Claude, Gemini,
ChatGPT, Base44 CoPilot) from code markers and dependencies, and you can override
it. The **Who Wrote What** section aggregates apps, languages and crash history
per author.

## The checker — syntax + capability, built for your system

`tools/check.js` is part of the codebase — run it by hand any time:

```bash
node tools/check.js <app-folder>
```

It checks **syntax** (`node --check`, `py_compile`, `bash -n`, JSON parse) and
**capability** — can this code actually run *on this machine*: every `require()` /
`import` must resolve here, every `package.json` dep must be installed, shell
scripts need a shebang. The server runs it automatically in pre-flight, sandbox
tests, and every triple-check.

## Triple-check — fixes prove themselves three times

No fix or change is trusted after one lucky launch. The **3× check** (automatic
after every auto-fix, on-demand via the **3× check** button, or
`POST /api/projects/:id/triplecheck`):

1. **Run 1–3:** syntax + capability checker clean **and** isolated copy launches
   to ready — all three runs must pass.
2. **Collateral:** diff vs the pre-change snapshot — every changed file must be
   inside the scope lock. Nothing else may have moved.
3. **Verdict:** 3/3 + clean collateral → rule **rewarded**. Any failure → rule
   **punished**, and (for queued changes) the snapshot is **restored**.

## How your change requests get done (the agent protocol)

When you queue a request and I (or an agent I delegate to) pick it up:

1. Snapshot first — there's always a way back.
2. The request gets a **scope lock**: the exact files allowed to change.
3. The agent is told the file list and nothing else — it may not touch anything
   outside it.
4. **🔍 diff** proves only scoped files changed.
5. **Triple-check**: 3 clean launches + collateral check.
6. Pass → done. Fail → punished + restored, and you hear about it.

Small, scoped, proven — or it didn't happen.

---

# Running Offline Base44 — step by step (manual path, only if auto gets stuck)

## 1. Install the prerequisites

```bash
# Node.js 20+  (https://nodejs.org — grab the Linux x64 tarball or use your package manager)
node -v   # should print v20 or higher

# Ollama (local AI server)
curl -fsSL https://ollama.com/install.sh | sh

# Git (you almost certainly have it)
git --version
```

## 2. Start Ollama and pull the models

```bash
ollama serve &
sleep 3
ollama pull qwen2.5:7b        # main LLM — replaces Base44's InvokeLLM
ollama pull nomic-embed-text  # embeddings — replaces semantic search
ollama list                   # verify both are there
```

Low-RAM machine? Pull `qwen2.5:3b` instead of the 7b and set
`OLLAMA_MODEL=qwen2.5:3b` when you start the app.

## 3. Get the app files

From your Base44 **MemoryCore Hypervisor** app → Download Center →
**"Download All 16 Files (App + Screens + Model + Fixes)"**.
Extract them into one folder, e.g. `~/offline-base44/`.

You should end up with at least:
`start.sh  package.json  server/  electron/  index.html  vite.config.js  src/  Modelfile`

## 4. Install app dependencies

```bash
cd ~/offline-base44
npm install
```

## 5. Launch it

```bash
# backend (port 3001) + frontend (port 5173)
node server/index.js &
npx vite &
```

Then open **http://localhost:5173** in your browser.

If the project ships a `start.sh` (like `run-offline-base44.sh`), the
one-click version is just:

```bash
chmod +x run-offline-base44.sh
./run-offline-base44.sh
```

That script creates the project, builds the interim `offline-base44`
Ollama model from the Modelfile, and adds a desktop app-menu icon.

## 6. Package as a desktop app (optional, later)

```bash
npm i electron --save-dev
# electron/main.js loads localhost:5173
npx electron-builder --platform=linux
```

## Troubleshooting

| Symptom | Fix |
|---|---|
| `EADDRINUSE :::3001` | something's on the port: `fuser -k 3001/tcp`, then relaunch |
| `Cannot find module 'x'` | `npm install` in the project folder |
| `ECONNREFUSED 127.0.0.1:11434` | Ollama isn't running: `ollama serve &` |
| `model "qwen2.5:7b" not found` | `ollama pull qwen2.5:7b` |
| `database is locked` | a crashed copy still holds it — kill old node processes: `pkill -f "node server"` |
| blank page at :5173 | backend not up — check `node server/index.js` output |

---
*Launchpad automates every row of that table: it watches the logs,
diagnoses the crash, and offers the fix as a button.*

## Updating apps & Launchpad itself — never delete-and-redownload

**App updates (dashboard → app card → ⬆ Update):** paste the new version's folder
or .zip path. The tool builds the update in a test copy, runs the syntax checker,
launches it in the sandbox, and only then applies it to the live app — changed and
new files only. Files removed upstream are deleted, but `node_modules`, `.venv`,
`dist`, `.env`, and the other protected paths are NEVER wiped; if `package.json`
changed, dependencies refresh with a plain incremental `npm install`. A restore
point is taken first, so one click brings the old version back.

**Patch packages (tiny downloads):** when an update ships as a patch zip, it
contains only the changed files plus `update.json`:
`{kind:"launchpad-patch", target:"app"|"launchpad", version, files:{path: sha1}, removed:[...]}`.
The tool verifies every file's hash as it applies. No patch → a full
folder/zip works too; it still applies incrementally.

**Self-update (dashboard header → ⟳ Update Launchpad):** paste the new
Launchpad package's folder path, .zip path, or download URL. The tool verifies
it's a real Launchpad dist (`server.js` + `.launchpad-dist`, newer version),
backs up the current install, applies the files, stops running apps, restarts
itself, and relaunches the apps. The dashboard reconnects on its own.
