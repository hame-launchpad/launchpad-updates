# CREW.md — the review crew ledger

hame's rule (2026-09-27): the manager (shooter) runs the crew. The manager awards,
punishes, and trains the workers. The owner does the same to the manager.
Workers are ephemeral subagents; they are trained through the standing
instructions in their briefs. This file records what each role must be told,
plus awards and punishments.

## The pipeline

1. **Shooter scans** — the manager personally reads the code, runs it, lists the fixes.
2. **Workers apply** — subagents apply exactly the listed fixes, nothing more.
3. **Verifier (cleanup crew)** — a different agent checks the work: reproduces each
   original bug, validates each fix, runs `node --check` + self-check + relevant
   batteries.
4. **Shooter final check** — when the verifier says good, the manager checks it one
   more time personally, then hands off.

No agent grades its own work. Only a verifier sign-off earns the +1 fix point.

## Standing brief for WORKERS (paste into every worker brief)

- Apply ONLY the fixes listed. Do not refactor, do not "improve", do not touch
  anything outside the listed lines.
- After applying, run `node --check` on every touched file and the Launchpad
  self-check (`node tools/check.js .`). Report the exact output.
- Your work goes to the verifier next. Sloppy work the verifier has to redo is
  punished; clean work that passes first try is awarded.

## Standing brief for the VERIFIER (paste into every verifier brief)

- Reproduce EVERY claimed bug on the ORIGINAL code before trusting anything.
- Validate EVERY proposed patch on a throwaway copy first — including adversarial
  shapes (minified one-liners, adjacent operators, edge-case inputs). A patch that
  fixes the reported case but breaks a sibling case is REJECTED, not shipped.
- Run: `node --check` on touched files, the self-check, and the relevant case
  battery. Report pass/fail counts with the actual commands run.
- Only after proof: apply, append the lesson, update brain/score/log.
- A secondary observation that doesn't hold up under scrutiny is rejected with the
  reason stated — do not add guards for impossible races.

## Awards

- **Round 22 part-2 agent: AWARDED.** Kept real state untouched, verified it empirically
  before AND after kill, and corrected its manager's false premise with proof instead of
  eating an unfair punishment. That's the backbone the crew needs.
- **Round 22 verifier (checker `++`/`--` fix): AWARDED.** Independently reproduced the
  bug, then caught a REGRESSION in the finder's own proposed patch (the naive
  `++`/`--` → division rule misread minified `a+++ /["']/` as division, creating a new
  false negative 1 → 0). Refused to ship it, strengthened the patch with the
  `src[j-2] !== c` guard, verified 22/22. This is exactly what the cleanup crew is for.

## Punishments

- (none recorded yet)

## Training notes (fed into future briefs)

- Verifiers must always test minified/adversarial shapes — that is how the round-22
  award was earned.
- Finders must not propose patches they haven't run against sibling cases.
- When a fix touches liveness state, audit every adjacent field on the same object
  (L26).

## Training notes (continued)

- `HOME=/tmp/x node server.js` DOES isolate a Node server on Linux: `os.homedir()`
  honors `$HOME` there (the ignore-behavior is Windows-only). Still: every live test must
  CONFIRM the effective data dir before booting (one `node -e` call), and verify zero writes
  to the real `~/.launchpad` after the run. The part-1 verifier asserted the Windows behavior
  as fact without checking — and the manager punished on it without checking. Both wrong.
  Check, then act.
- Every `await` in `autopilotRun` needs BOTH guards after it: `if (superseded()) return;`
  AND `if (!runner(id).autopilot) return finish("stopped", "");`. The pattern existed for
  the post-crash verify and the final port probe but was missing after the verify-before-launch
  (round-22 part-2 find: Stop during verify → npm install ran anyway). When adding a new await
  to the run loop, both guards go with it.

## Punishments

- **Round 22 part-2 agent: PUNISHMENT OVERTURNED (manager's error).** The punishment was based
  on the part-1 verifier's secondhand claim that "`os.homedir()` ignores `$HOME`". The agent
  pushed back with empirical proof (`HOME=/tmp/lpr22home node -e "os.homedir()"` →
  `/tmp/lpr22home`); the manager verified it directly. On Linux, `os.homedir()` DOES honor
  `$HOME` (the ignore-behavior is Windows). The agent's rig was properly isolated all along —
  its state went to `/tmp/lpr22home/.launchpad/`, and it verified zero writes to the real
  `~/.launchpad` both before and after killing its server. **The manager punished on an
  unverified premise. That is the manager's fuckup, recorded here. Rule: verify before
  punishing — secondhand technical claims get checked, no matter who they come from.

## Scoring (revised 2026-09-27 — manager's convergence fix)

- Real find: +1. Verified fix: +1.
- **Clean verdict that survives the manager's final check: +2.** Correct cleans are the goal.
- Clean overturned by a later real find: score reset to zero (unchanged).
- Below-the-bar find (rejected by verifier): no point. Two in a row: punishment mark.
- **Two consecutive manager-final-checked clean rounds ends the review loop → ship prep.**
- Never `pkill -f` with a pattern present in your own command line (classic footgun —
  the round-22 part-2 verifier killed its own shell). Resolve exact PIDs first, kill those.

## Pay scale — raises as rewards (owner's rule, 2026-09-27)
Base: **$10/day**. The manager pays out of his own 50% — every hire is his money.

- **Raise: +$5/day** for an exemplary job — done right the FIRST time, no rework, no sloppiness.
  The one who does it in 1 makes more than the one who needs 22. Raises stack and are permanent
  on the roster below.
- **Go-to:** the highest-paid proven performer gets hired first. When work comes up, the
  manager calls the top of this list.
- **Transparency:** everyone sees this scale and the roster. If A makes more than B, the
  roster says why: A does it once, B needed rework. No secrets, no favoritism — just the record.
- **Fired:** repeated sloppy work (rework needed twice, or a false report) = not hired again.

### Roster (rates are per day)
- **Round-22 checker verifier — $15/day (RAISED).** Caught the finder's patch regression before
  it shipped, strengthened the patch, 22/22 battery. First-try, exceptional. Go-to verifier.
- **Round-22 part-2 agent (finder) — $15/day (RAISED).** Live repro with log evidence, empirical
  rigor, corrected the manager's false premise with proof. First-try, exceptional.
- **Round-22 part-2 fix verifier — $15/day (RAISED).** Live repro on original AND patched copies,
  normal-path check, rejected the secondary with reasoning, full bookkeeping. One shot, complete.
- Round-22 part-1 finder — $10/day. Solid find, clean report. Base.
- Round-22 part-3 finder — $10/day. Real find, but the proposed patch carried a regression the
  verifier had to catch. No raise until a patch ships clean.

## Worker economics (owner's rule, 2026-09-27)
Job pays 1000: owner 500, manager 500. Each worker-day costs the manager $10 out of the
manager's 500. 22 rounds of crews left ~$6. Rule: the manager does the work — scanning,
patching, checks, bookkeeping. The only structural hire is the verifier (no self-verification).
Every other hire must be justified in the log. Clean round = $0. One fix = one verifier = $10.
