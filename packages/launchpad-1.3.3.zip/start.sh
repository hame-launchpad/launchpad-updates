#!/bin/bash
# Launchpad one-click starter — run this, your browser opens the dashboard.
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: node is not installed."
  echo "Install Node.js 20+ from https://nodejs.org then run this again."
  exit 1
fi
node server.js &
SRV=$!
sleep 1
URL="http://127.0.0.1:${LAUNCHPAD_PORT:-8471}"
if command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL" >/dev/null 2>&1 &
elif command -v open >/dev/null 2>&1; then open "$URL" >/dev/null 2>&1 & fi
echo "Launchpad running at $URL  (Ctrl+C here to stop)"
wait $SRV
